﻿public class QueuedResponse
{
    public Socket Sender { get; set; }
    public List<ArraySegment<byte>> Message { get; set; }
}
