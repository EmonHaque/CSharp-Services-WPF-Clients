﻿public class NetMonthlyBalance
{
    public string Date { get; set; }
    public string Plot { get; set; }
    public string Tenant { get; set; }
    public int Due { get; set; }
    public int LastMonthDue { get; set; }
    public int Payment { get; set; }

    public List<ArraySegment<byte>> GetBytes() {
        var date = Encoding.ASCII.GetBytes(Date + '\0');
        var plot = Encoding.ASCII.GetBytes(Plot + '\0');
        var tenant = Encoding.ASCII.GetBytes(Tenant + '\0');
        var size = BitConverter.GetBytes(date.Length + plot.Length + tenant.Length + 12);
        return new List<ArraySegment<byte>>() {
            size, date, plot, tenant,
            BitConverter.GetBytes(Due),
            BitConverter.GetBytes(LastMonthDue),
            BitConverter.GetBytes(Payment),
        };
    }
    public static NetMonthlyBalance FromBytes(ReadOnlySpan<byte> bytes) {
        int start, read, index;
        start = read = index = 0;
        var segments = new string[3];
        while (read < bytes.Length) {
            if (bytes[read] != 0) {
                read++;
                continue;
            }
            segments[index++] = Encoding.ASCII.GetString(bytes.Slice(start, read - start));
            start = ++read;
            if (index == segments.Length) break;
        }
        return new NetMonthlyBalance() {
            Date = segments[0],
            Plot = segments[1],
            Tenant = segments[2],
            Due = BitConverter.ToInt32(bytes.Slice(start, 4)),
            LastMonthDue = BitConverter.ToInt32(bytes.Slice(start + 4, 4)),
            Payment = BitConverter.ToInt32(bytes.Slice(start + 8, 4)),
        };
    }
}
