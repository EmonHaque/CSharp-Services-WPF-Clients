﻿public class NetBalance
{
    public string Space { get; set; }
    public string Tenant { get; set; }
    public string DateStart { get; set; }
    public string DateEnd { get; set; }
    public int Security { get; set; }
    public int Rent { get; set; }
    public int Due { get; set; }
    public int Count { get; set; }
    public bool IsExpired { get; set; }
    
    public List<ArraySegment<byte>> GetBytes() {
        var space = Encoding.ASCII.GetBytes(Space + '\0');
        var tenant = Encoding.ASCII.GetBytes(Tenant + '\0');
        var start = Encoding.ASCII.GetBytes(DateStart + '\0');
        var end = Encoding.ASCII.GetBytes(DateEnd + '\0');
        var size = space.Length + tenant.Length + start.Length + end.Length + 16 + 1;
        return new List<ArraySegment<byte>>() {
            BitConverter.GetBytes(size), 
            space, tenant, start, end,
            BitConverter.GetBytes(Security),
            BitConverter.GetBytes(Rent),
            BitConverter.GetBytes(Due),
            BitConverter.GetBytes(Count),
            BitConverter.GetBytes(IsExpired)
        };
    }
    public static NetBalance FromBytes(ReadOnlySpan<byte> bytes) {
        int start, read, index;
        start = read = index = 0;
        var segments = new string[4];
        while (read < bytes.Length) {
            if (bytes[read] != 0) {
                read++;
                continue;
            }
            segments[index++] = Encoding.ASCII.GetString(bytes.Slice(start, read - start));
            start = ++read;
            if (index == segments.Length) break;
        }
        return new NetBalance() {
            Space = segments[0],
            Tenant = segments[1],
            DateStart = segments[2],
            DateEnd = segments[3],
            Security = BitConverter.ToInt32(bytes.Slice(start, 4)),
            Rent = BitConverter.ToInt32(bytes.Slice(start + 4, 4)),
            Due = BitConverter.ToInt32(bytes.Slice(start + 8, 4)),
            Count = BitConverter.ToInt32(bytes.Slice(start + 12, 4)),
            IsExpired = BitConverter.ToBoolean(bytes.Slice(start + 16, 1))
        };
    }
}
