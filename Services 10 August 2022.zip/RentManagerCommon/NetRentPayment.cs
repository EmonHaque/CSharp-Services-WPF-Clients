﻿public class NetRentPayment
{
    public string Date { get; set; }
    public string Plot { get; set; }
    public string Space { get; set; }
    public string Tenant { get; set; }
    public int Due { get; set; }
    public int Cash { get; set; }
    public int Mobile { get; set; }
    public int Kind { get; set; }
    public int TotalPaid { get; set; }

    public List<ArraySegment<byte>> GetBytes() {
        return new List<ArraySegment<byte>>() {
            Encoding.ASCII.GetBytes(Date + '\0'),
            Encoding.ASCII.GetBytes(Plot + '\0'),
            Encoding.ASCII.GetBytes(Space + '\0'),
            Encoding.ASCII.GetBytes(Tenant + '\0'),
            BitConverter.GetBytes(Due),
            BitConverter.GetBytes(Cash),
            BitConverter.GetBytes(Mobile),
            BitConverter.GetBytes(Kind),
            BitConverter.GetBytes(TotalPaid)
        };
    }
}
