﻿public class NetTransaction
{
    public int Id { get; set; }
    public int PlotId { get; set; }
    public int SpaceId { get; set; }
    public int TenantId { get; set; }
    public int ControlId { get; set; }
    public int HeadId { get; set; }
    public int Amount { get; set; }
    public byte IsCash { get; set; }
    public string Date { get; set; }
    public string Narration { get; set; }

    public List<ArraySegment<byte>> GetBytes() {
        var date = Encoding.ASCII.GetBytes(Date + '\0');
        var narration = Encoding.ASCII.GetBytes(Narration + '\0');
        
        return new List<ArraySegment<byte>>() {
            BitConverter.GetBytes(Id),
            BitConverter.GetBytes(PlotId),
            BitConverter.GetBytes(SpaceId),
            BitConverter.GetBytes(TenantId),
            BitConverter.GetBytes(ControlId),
            BitConverter.GetBytes(HeadId),
            BitConverter.GetBytes(Amount),
            new byte[]{ IsCash },
            date, narration
        };
    }
    public static NetTransaction FromBytes(ReadOnlySpan<byte> array) {     
        var transaction =  new NetTransaction() {
            Id = BitConverter.ToInt32(array.Slice(0, 4)),
            PlotId = BitConverter.ToInt32(array.Slice(4, 4)),
            SpaceId = BitConverter.ToInt32(array.Slice(8, 4)),
            TenantId = BitConverter.ToInt32(array.Slice(12, 4)),
            ControlId = BitConverter.ToInt32(array.Slice(16, 4)),
            HeadId = BitConverter.ToInt32(array.Slice(20, 4)),
            Amount = BitConverter.ToInt32(array.Slice(24, 4)),
            IsCash = array.Slice(28, 1)[0],
        };
        int read = 29;
        int start = 29;
        while (array[read] != 0) read++;
        transaction.Date = Encoding.ASCII.GetString(array.Slice(start, read - start));

        start = ++read;
        while (array[read] != 0) read++;
        transaction.Narration = Encoding.ASCII.GetString(array.Slice(start, read - start));
        return transaction;
    }
}