IHost host = Host.CreateDefaultBuilder(args)
    .ConfigureServices(services =>
    {
        services.AddHostedService<RentManagerWorker>();
    })
    .Build();

await host.RunAsync();
