public class LaunchWorker : BackgroundService
{
    const string repoList = @"C:\Users\Emon\Desktop\AppRepo\applist.txt";
    List<AppInfo> apps;
    Socket server;

    public LaunchWorker() {
        initializeAppVersions();
        server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        server.Bind(new IPEndPoint(IPAddress.Parse(Addresses.LaunchAddress), Addresses.LaunchPort));
        server.Listen(500);
        accept();
    }

    void initializeAppVersions() {
        apps = new List<AppInfo>();
        string line;
        var reader = new StreamReader(repoList);
        while ((line = reader.ReadLine()) != null) {
            var splits = line.Split(',');
            apps.Add(new AppInfo() {
                Name = splits[0].Trim(),
                Version = splits[1].Trim(),
                Repository = splits[2].Trim()
            });
        }
        reader.Close();
        reader.Dispose();
    }
    void accept() {
        var e = new SocketAsyncEventArgs();
        e.Completed += onAccepted;
        bool started = server.AcceptAsync(e);
        if (!started) onAccepted(null, e);
    }
    void onAccepted(object sender, SocketAsyncEventArgs e) {
        if (e.SocketError == SocketError.Success) {
            e.Completed -= onAccepted;
            e.Completed += onReceived;
            bool started = e.AcceptSocket.ReceiveAsync(e);
            if (!started) onReceived(null, e);
            accept();
        }
        else if (e.SocketError == SocketError.OperationAborted) {
            e.Completed -= onAccepted;
            e.Dispose();
            accept();
        }
    }
    void onReceived(object? sender, SocketAsyncEventArgs e) {
        e.Completed -= onReceived;
        var header = new byte[4];
        if (e.SocketError == SocketError.Success) {
            int read = e.AcceptSocket.Receive(header);
            while (read < header.Length) {
                read += e.AcceptSocket.Receive(header, read, header.Length - read, SocketFlags.None);
            }
            var packet = new byte[BitConverter.ToInt32(header)];
            read = e.AcceptSocket.Receive(packet);
            while (read < packet.Length) {
                read += e.AcceptSocket.Receive(packet, read, packet.Length - read, SocketFlags.None);
            }
            var request = LaunchArgs.FromBytes(packet);
            var app = apps.FirstOrDefault(x => x.Name.Equals(request.App));

            bool hasUpdate = false;
            if (!request.Version.Equals(app.Version)) {
                hasUpdate = true;
            }
            e.AcceptSocket.Send(BitConverter.GetBytes(hasUpdate));
            if (hasUpdate) {
                int load = 0;
                var files = getFiles(app.Repository);
                List<ArraySegment<byte>> bytes = new();
                foreach (var file in files) {
                    var fileBytes = file.GetBytes();
                    load += fileBytes.Length;
                    bytes.Add(fileBytes);
                }
                e.AcceptSocket.Send(BitConverter.GetBytes(load));
                e.AcceptSocket.Send(bytes);
            }
        }
        e.AcceptSocket.Shutdown(SocketShutdown.Both);
        e.AcceptSocket.Close();
        e.AcceptSocket.Dispose();
    }
    List<UpdatedFile> getFiles(string path) {
        var dir = Directory.GetFiles(path);
        List<UpdatedFile> files = new();
        foreach (var file in dir) {
            var content = File.ReadAllBytes(file);
            files.Add(new UpdatedFile() {
                Name = file.Substring(file.LastIndexOf("\\") + 1),
                Content = content
            });
        }
        return files;
    }

    protected override async Task ExecuteAsync(CancellationToken token) {
        while (!token.IsCancellationRequested) {
            await Task.Delay(5000);
            //Create and update another database for listing who updated/launched apps
        }
    }
}
