public class CDRMWorker : BackgroundService
{
    Database db;
    Socket server;
    List<Socket> receivers;
    BlockingCollection<RawRequest> requests;
    BlockingCollection<List<ArraySegment<byte>>> broadcasts;
    BlockingCollection<QueuedResponse> responses;

    public CDRMWorker() {
        receivers = new List<Socket>();
        requests = new BlockingCollection<RawRequest>();
        broadcasts = new BlockingCollection<List<ArraySegment<byte>>>();
        responses = new BlockingCollection<QueuedResponse>();

        db = new Database(broadcasts, responses);
        server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        server.Bind(new IPEndPoint(IPAddress.Parse(Addresses.CDRMAddress), Addresses.CDRMPort));
        server.Listen(500);
        accept();
        new Thread(processRequests) { IsBackground = true }.Start();
        new Thread(sendResponse) { IsBackground = true }.Start();
    }

    void accept() {
        var e = new SocketAsyncEventArgs();
        e.Completed += onAccepted;
        bool started = server.AcceptAsync(e);
        if (!started) onAccepted(null, e);
    }
    void onAccepted(object sender, SocketAsyncEventArgs e) {
        e.Completed -= onAccepted;
        if (e.SocketError == SocketError.Success) {
            try {
                var socketType = new byte[1];
                e.AcceptSocket.Receive(socketType);
                var isReceiver = BitConverter.ToBoolean(socketType);
                if (isReceiver) {
                    receivers.Add(e.AcceptSocket);
                    e.Completed += onReceiverDisconnected;
                    bool started = e.AcceptSocket.ReceiveAsync(e);
                    if (!started) onReceiverDisconnected(null, e);
                }
                else {
                    e.Completed += onReceived;
                    bool started = e.AcceptSocket.ReceiveAsync(e);
                    if (!started) onReceived(null, e);
                }
            }
            catch {
                e.AcceptSocket.Close();
                e.AcceptSocket.Dispose();
            }
            finally { accept(); }
        }
        else {
            e.AcceptSocket.Close();
            e.AcceptSocket.Dispose();
            accept();
        }
    }
    void onReceived(object? sender, SocketAsyncEventArgs e) {
        var header = new byte[4];
        if (e.SocketError == SocketError.Success) {
            try {
                int read = e.AcceptSocket.Receive(header);
                while (read < header.Length) {
                    read += e.AcceptSocket.Receive(header, read, header.Length - read, SocketFlags.None);
                    // when you quit app by clicking on Stop Debugging button, it's stuck here in this loop! doesn't throw exception, why?
                    // closing app by clicking on close button, taskbar right click and Alt + F4 is ok 
                }
                var packet = new byte[BitConverter.ToInt32(header)];
                read = e.AcceptSocket.Receive(packet);
                while (read < packet.Length) {
                    read += e.AcceptSocket.Receive(packet, read, packet.Length - read, SocketFlags.None);
                }
                requests.Add(new RawRequest(e.AcceptSocket, packet));
                var started = e.AcceptSocket.ReceiveAsync(e);
                if (!started) onReceived(null, e);
            }
            catch { onSenderDisConnected(e); }
        }
        else onSenderDisConnected(e);
    }
    void onSenderDisConnected(SocketAsyncEventArgs e) {
        e.Completed -= onReceived;
        e.AcceptSocket.Close();
        e.AcceptSocket.Dispose();
        Debug.WriteLine("Sender cleaned up");
    }
    void onReceiverDisconnected(object? sender, SocketAsyncEventArgs e) {
        e.Completed -= onReceiverDisconnected;
        lock (receivers) {
            var socket = receivers.First(x => x.Equals(e.AcceptSocket));
            socket.Close();
            socket.Dispose();
            receivers.Remove(socket);
            Debug.WriteLine("Receiver cleaned up");
        }
    }
    void sendStartupPackets(Socket s) {
        s.Send(BitConverter.GetBytes(db.sizes.site));
        foreach (var item in db.siteBytes) s.Send(item.Value);

        s.Send(BitConverter.GetBytes(db.sizes.party));
        foreach (var item in db.partyBytes) s.Send(item.Value);

        s.Send(BitConverter.GetBytes(db.sizes.head));
        foreach (var item in db.headBytes) s.Send(item.Value);

        s.Send(BitConverter.GetBytes(db.sizes.subHead));
        foreach (var item in db.subHeadBytes) s.Send(item.Value);

        s.Send(BitConverter.GetBytes(db.sizes.unit));
        foreach (var item in db.unitBytes) s.Send(item.Value);

        s.Send(BitConverter.GetBytes(db.sizes.noteType));
        foreach (var item in db.noteTypeBytes) s.Send(item.Value);
    }
    void processRequests() {
        while (true) {
            var raw = requests.Take();
            var request = CDRMRequest.FromBytes(raw.Packet);
            switch ((Function)request.Method) {
                case Function.GetInitialData: sendStartupPackets(raw.Sender); break;
                case Function.GetPurchaseSellByDate: db.GetPurchaseSellByDate(request, raw.Sender);break;
                case Function.GetReceiptPaymentByDate: db.GetReceiptPaymentByDate(request, raw.Sender); break;
                case Function.GetDates: db.GetDates(request, raw.Sender); break;
                case Function.GetNotes: db.GetNotes(raw.Sender); break;
                case Function.GetDues: db.GetDues(raw.Sender); break;
                case Function.GetLedger: db.GetLedger(request, raw.Sender); break;
                case Function.GetPurchaseSell: db.GetPurchaseSell(request, raw.Sender); break;
                case Function.GetReceiptPayment: db.GetReceiptPayment(request, raw.Sender); break;
                case Function.GetDetailPurchasePayable: db.GetDetailPurchasePayable(request, raw.Sender); break;
                case Function.GetAllHeadOrSitewisePurchase: db.GetAllHeadOrSitewisePurchase(request, raw.Sender); break;
                case Function.GetSingleHeadOrSitewisePurchase: db.GetSingleHeadOrSitewisePurchase(request, raw.Sender); break;
                case Function.GetAllPartyTransactions: db.GetAllPartyTransactions(request, raw.Sender); break;
                case Function.GetSinglePartyTransaction: db.GetSinglePartyTransaction(request, raw.Sender); break;
                case Function.GetPurchases: db.GetPurchases(request, raw.Sender); break;
                case Function.GetPayments: db.GetPayments(request, raw.Sender); break;

                case Function.AddSite: db.AddSite(request, raw.Sender); break;
                case Function.AddParty: db.AddParty(request, raw.Sender); break;
                case Function.AddHead: db.AddHead(request, raw.Sender); break;
                case Function.AddSubHead: db.AddSubHead(request, raw.Sender); break;
                case Function.AddUnit: db.AddUnit(request, raw.Sender); break;
                case Function.AddNoteType: db.AddNoteType(request, raw.Sender); break;
                case Function.AddNote: db.AddNote(request, raw.Sender); break;
                case Function.AddEntries: db.AddEntries(request, raw.Sender); break;

                case Function.EditSite: db.EditSite(request, raw.Sender); break;
                case Function.EditParty: db.EditParty(request, raw.Sender); break;
                case Function.EditHead: db.EditHead(request, raw.Sender); break;
                case Function.EditSubHead: db.EditSubHead(request, raw.Sender); break;
                case Function.EditUnit: db.EditUnit(request, raw.Sender); break;
                case Function.EditNoteType: db.EditNoteType(request, raw.Sender); break;
                case Function.EditNote: db.EditNote(request, raw.Sender); break;
                case Function.EditPurchaseSell: db.EditPurchaseSell(request, raw.Sender); break;
                case Function.EditReceiptPayment: db.EditReceiptPayment(request, raw.Sender); break;

                case Function.DeleteReceiptPayment: db.DeleteReceiptPayment(request, raw.Sender); break;
                case Function.DeletePurchaseSell: db.DeletePurchaseSell(request, raw.Sender); break;
                case Function.DeleteNote: db.DeleteNote(request, raw.Sender); break;
            }
        }
    }
    void sendResponse() {
        while (true) {
            //place to use ThreadPool if you have lot of requests queued
            var response = responses.Take();
            try { response.Sender.Send(response.Message); }
            catch { }
        }
    }
    protected override async Task ExecuteAsync(CancellationToken token) {
        while (!token.IsCancellationRequested) {
            var message = broadcasts.Take();
            lock (receivers) {
                foreach (var socket in receivers) {
                    try { socket.Send(message); }
                    catch {
                        Debug.WriteLine("Broadcast catch");
                    }
                }
            }
        }
    }
}
