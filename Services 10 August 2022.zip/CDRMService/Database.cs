﻿class Database
{
    public struct Totals
    {
        public int site;
        public int party;
        public int head;
        public int subHead;
        public int unit;
        public int noteType;
    }
    int maxSiteId, maxPartyId, maxHeadId, maxSubHeadId, maxUnitId, maxNoteTypeId;
    const string location = @"data source = C:\Users\Emon\Desktop\CDRM.db";
    SqliteCommand command;
    SqliteConnection connection = new(location);

    List<NetSite> sites = new();
    List<NetParty> parties = new();
    List<NetHead> heads = new();
    List<NetSubHead> subHeads = new();
    List<NetUnit> units = new();
    List<NetNoteType> noteTypes = new();

    public Totals sizes = new();
    public Dictionary<int, List<ArraySegment<byte>>> siteBytes = new();
    public Dictionary<int, List<ArraySegment<byte>>> partyBytes = new();
    public Dictionary<int, List<ArraySegment<byte>>> headBytes = new();
    public Dictionary<int, List<ArraySegment<byte>>> subHeadBytes = new();
    public Dictionary<int, List<ArraySegment<byte>>> unitBytes = new();
    public Dictionary<int, List<ArraySegment<byte>>> noteTypeBytes = new();

    BlockingCollection<List<ArraySegment<byte>>> broadcasts;
    BlockingCollection<QueuedResponse> responses;

    public Database(BlockingCollection<List<ArraySegment<byte>>> broadcasts, BlockingCollection<QueuedResponse> responses) {
        this.broadcasts = broadcasts;
        this.responses = responses;
        connection.Open();
        command = connection.CreateCommand();
        populateLists();
        populateDisctionaries();
    }

    void populateLists() {
        command.CommandText = @"SELECT * FROM Sites;
                                SELECT * FROM Heads;
                                SELECT * FROM SubHeads;
                                SELECT * FROM Parties;
                                SELECT * FROM Units;
                                SELECT * FROM NoteTypes;";
        var reader = command.ExecuteReader();
        while (reader.Read()) {
            sites.Add(new NetSite() {
                Id = reader.GetInt32(0),
                Name = reader.GetString(1),
                Address = reader.GetString(2)
            });
        }
        reader.NextResult();
        while (reader.Read()) {
            heads.Add(new NetHead() {
                Id = reader.GetInt32(0),
                Name = reader.GetString(1)
            });
        }
        reader.NextResult();
        while (reader.Read()) {
            subHeads.Add(new NetSubHead() {
                Id = reader.GetInt32(0),
                Name = reader.GetString(1)
            });
        }
        reader.NextResult();
        while (reader.Read()) {
            parties.Add(new NetParty() {
                Id = reader.GetInt32(0),
                Name = reader.GetString(1),
                Address = reader.GetString(2),
                Phone = reader.IsDBNull(3) ? "" : reader.GetString(3)
            });
        }
        reader.NextResult();
        while (reader.Read()) {
            units.Add(new NetUnit() {
                Id = reader.GetInt32(0),
                Name = reader.GetString(1)
            });
        }
        reader.NextResult();
        while (reader.Read()) {
            noteTypes.Add(new NetNoteType() {
                Id = reader.GetInt32(0),
                Name = reader.GetString(1)
            });
        }
        reader.Close();
        reader.DisposeAsync();

        maxSiteId = sites.Count == 0 ? 0 : sites.Count == 0 ? 0 : sites.Max(x => x.Id);
        maxPartyId = parties.Count == 0 ? 0 : parties.Max(x => x.Id);
        maxHeadId = heads.Count == 0 ? 0 : heads.Max(x => x.Id);
        maxSubHeadId = subHeads.Count == 0 ? 0 : subHeads.Max(x => x.Id);
        maxUnitId = units.Count == 0 ? 0 : units.Max(x => x.Id);
        maxNoteTypeId = noteTypes.Count == 0 ? 0 : noteTypes.Max(x => x.Id);
    }
    void populateDisctionaries() {
        foreach (var site in sites) {
            var bytes = site.GetBytes();
            siteBytes.Add(site.Id, bytes);
            sizes.site += bytes.Sum(x => x.Count);
        }
        foreach (var party in parties) {
            var bytes = party.GetBytes();
            partyBytes.Add(party.Id, bytes);
            sizes.party += bytes.Sum(x => x.Count);
        }
        foreach (var head in heads) {
            var bytes = head.GetBytes();
            headBytes.Add(head.Id, bytes);
            sizes.head += bytes.Sum(x => x.Count);
        }
        foreach (var subHead in subHeads) {
            var bytes = subHead.GetBytes();
            subHeadBytes.Add(subHead.Id, bytes);
            sizes.subHead += bytes.Sum(x => x.Count);
        }
        foreach (var unit in units) {
            var bytes = unit.GetBytes();
            unitBytes.Add(unit.Id, bytes);
            sizes.unit += bytes.Sum(x => x.Count);
        }
        foreach (var noteType in noteTypes) {
            var bytes = noteType.GetBytes();
            noteTypeBytes.Add(noteType.Id, bytes);
            sizes.noteType += bytes.Sum(x => x.Count);
        }
    }
    bool transaction(List<KeyValuePair<string, List<SqliteParameter>>> commands) {
        bool isOk = true;
        command.CommandText = "BEGIN TRANSACTION;";
        command.ExecuteNonQuery();
        foreach (var item in commands) {
            command.CommandText = item.Key;
            if (item.Value is not null) command.Parameters.AddRange(item.Value);
            try { command.ExecuteNonQuery(); }
            catch (Exception e) {
                command.CommandText = "ROLLBACK;";
                command.ExecuteNonQuery();
                isOk = false;
            }
            command.Parameters.Clear();
            if (!isOk) break;
        }
        if (isOk) {
            command.CommandText = "COMMIT;";
            command.ExecuteNonQuery();
        }
        return isOk;
    }
    List<ArraySegment<byte>> getBytes(int userId, Function func, List<ArraySegment<byte>> bytes) {
        var length = 4 + 4 + bytes.Sum(x => x.Count);
        var messageBytes = new List<ArraySegment<byte>>() {
            BitConverter.GetBytes(length),
            BitConverter.GetBytes((int)func),
            BitConverter.GetBytes(userId)
        };
        messageBytes.AddRange(bytes);
        return messageBytes;
    }
    void getIntoQueue(Socket s, bool isSuccess, string message) {
        var bytes = Encoding.ASCII.GetBytes(message);
        var length = 1 + bytes.Length;
        responses.Add(new QueuedResponse() {
            Sender = s,
            Message = new List<ArraySegment<byte>>() {
                BitConverter.GetBytes(length),
                BitConverter.GetBytes(isSuccess),
                bytes
            }
        });
    }
    void getIntoQueue(Socket s, bool isSuccess, int message) {
        responses.Add(new QueuedResponse() {
            Sender = s,
            Message = new List<ArraySegment<byte>>() {
                BitConverter.GetBytes(1 + 4),
                BitConverter.GetBytes(isSuccess),
                BitConverter.GetBytes(message)
            }
        });
    }

    public void AddSite(Request r, Socket s) {
        bool isSuccess = false;
        int message = 0;
        var site = (NetSite)r.Args[0];
        var match = sites.FirstOrDefault(x => x.Name.Equals(site.Name, StringComparison.InvariantCultureIgnoreCase));

        if(match is null) {
            command.CommandText = "INSERT INTO Sites(Name, Address) VALUES(@Name, @Address)";
            command.Parameters.AddWithValue("@Name", site.Name);
            command.Parameters.AddWithValue("@Address", site.Address);
            command.ExecuteNonQuery();
            command.Parameters.Clear();

            site.Id = ++maxSiteId;
            sites.Add(site);

            var newBytes = site.GetBytes();
            sizes.site += newBytes.Sum(x => x.Count);
            siteBytes.Add(site.Id, newBytes);
            broadcasts.Add(getBytes(r.UserId, Function.AddSite, newBytes));
            isSuccess = true;
            message = site.Id;
        }
        else message = match.Id;
        getIntoQueue(s, isSuccess, message);
    }
    public void AddParty(Request r, Socket s) {
        bool isSuccess = false;
        int message = 0;
        var party = (NetParty)r.Args[0];
        var match = parties.FirstOrDefault(x => x.Name.Equals(party.Name, StringComparison.InvariantCultureIgnoreCase));

        if(match is null) {
            command.CommandText = "INSERT INTO Parties(Name, Address, Phone) VALUES(@Name, @Address, @Phone)";
            command.Parameters.AddWithValue("@Name", party.Name);
            command.Parameters.AddWithValue("@Address", party.Address);
            command.Parameters.AddWithValue("@Phone", string.IsNullOrWhiteSpace(party.Phone) ? DBNull.Value : party.Phone);
            command.ExecuteNonQuery();
            command.Parameters.Clear();

            party.Id = ++maxPartyId;
            parties.Add(party);

            var newBytes = party.GetBytes();
            sizes.party += newBytes.Sum(x => x.Count);
            partyBytes.Add(party.Id, newBytes);
            broadcasts.Add(getBytes(r.UserId, Function.AddParty, newBytes));
            isSuccess = true;
            message = party.Id;
        }
        else message = match.Id;
        getIntoQueue(s, isSuccess, message);
    }
    public void AddHead(Request r, Socket s) {
        bool isSuccess = false;
        int message = 0;
        var head = (NetHead)r.Args[0];
        var match = heads.FirstOrDefault(x => x.Name.Equals(head.Name, StringComparison.InvariantCultureIgnoreCase));

        if (match is null) {
            command.CommandText = "INSERT INTO Heads(Name) VALUES(@Name)";
            command.Parameters.AddWithValue("@Name", head);
            command.ExecuteNonQuery();
            command.Parameters.Clear();

            head.Id = ++maxHeadId;
            heads.Add(head);

            var newBytes = head.GetBytes();
            sizes.head += newBytes.Sum(x => x.Count);
            headBytes.Add(head.Id, newBytes);
            broadcasts.Add(getBytes(r.UserId, Function.AddHead, newBytes));
            isSuccess = true;
            message = head.Id;
        }
        else message = match.Id;
        getIntoQueue(s, isSuccess, message);
    }
    public void AddSubHead(Request r, Socket s) {
        bool isSuccess = false;
        int message = 0;
        var subHead = (NetSubHead)r.Args[0];
        var match = subHeads.FirstOrDefault(x => x.Name.Equals(subHead.Name, StringComparison.InvariantCultureIgnoreCase));

        if (match is null) {
            command.CommandText = "INSERT INTO SubHeads(Name) VALUES(@Name)";
            command.Parameters.AddWithValue("@Name", subHead.Name);
            command.ExecuteNonQuery();
            command.Parameters.Clear();

            subHead.Id = ++maxSubHeadId;
            subHeads.Add(subHead);

            var newBytes = subHead.GetBytes();
            sizes.subHead += newBytes.Sum(x => x.Count);
            subHeadBytes.Add(subHead.Id, newBytes);
            broadcasts.Add(getBytes(r.UserId, Function.AddSubHead, newBytes));
            isSuccess = true;
            message = subHead.Id;
        }
        else message = match.Id;
        getIntoQueue(s, isSuccess, message);
    }
    public void AddUnit(Request r, Socket s) {
        bool isSuccess = false;
        int message = 0;
        var unit = (NetUnit)r.Args[0];
        var match = units.FirstOrDefault(x => x.Name.Equals(unit.Name, StringComparison.InvariantCultureIgnoreCase));

        if(match is null) {
            command.CommandText = "INSERT INTO Units(Name) VALUES(@Name)";
            command.Parameters.AddWithValue("@Name", unit.Name);
            command.ExecuteNonQuery();
            command.Parameters.Clear();

            unit.Id = ++maxUnitId;
            units.Add(unit);

            var newBytes = unit.GetBytes();
            sizes.unit += newBytes.Sum(x => x.Count);
            unitBytes.Add(unit.Id, newBytes);
            broadcasts.Add(getBytes(r.UserId, Function.AddUnit, newBytes));
            isSuccess = true;
            message = unit.Id;
        }
        else message = match.Id;
        getIntoQueue(s, isSuccess, message);
    }
    public void AddNoteType(Request r, Socket s) {
        bool isSuccess = false;
        int message = 0;
        var noteType = (NetNoteType)r.Args[0];
        var match = noteTypes.FirstOrDefault(x => x.Name.Equals(noteType.Name, StringComparison.InvariantCultureIgnoreCase));

        if(match is null) {
            command.CommandText = "INSERT INTO NoteTypes(Name) VALUES(@Name)";
            command.Parameters.AddWithValue("@Name", noteType.Name);
            command.ExecuteNonQuery();
            command.Parameters.Clear();

            noteType.Id = ++maxNoteTypeId;
            noteTypes.Add(noteType);

            var newBytes = noteType.GetBytes();
            sizes.noteType += newBytes.Sum(x => x.Count);
            noteTypeBytes.Add(noteType.Id, newBytes);
            broadcasts.Add(getBytes(r.UserId, Function.AddNoteType, newBytes));
            isSuccess = true;
            message = noteType.Id;
        }
        else message = match.Id;
        getIntoQueue(s, isSuccess, message);
    }
    public void AddNote(Request r, Socket s) {
        var note = (NetNote)r.Args[0];
        command.CommandText = $@"INSERT INTO Notes(SiteId, NoteTypeId, Date, Entry) 
                                 VALUES({note.SiteId}, {note.NoteTypeId}, '{note.Date}', @Entry)";
        command.Parameters.AddWithValue("@Entry", note.Entry);
        command.ExecuteNonQuery();
        command.Parameters.Clear();

        command.CommandText = $"SELECT last_insert_rowid()";
        var id = (long)command.ExecuteScalar();

        note.Id = (int)id;
        broadcasts.Add(getBytes(r.UserId, Function.AddNote, note.GetBytes()));

        getIntoQueue(s, true, "");
    }
    public void AddEntries(Request r, Socket s) {
        var entries = (List<NetEntryInsert>)r.Args[0];
        List<KeyValuePair<string, List<SqliteParameter>>> commands = new();
        foreach (var e in entries) {
            if (e.IsPS) {
                object subHead = e.SubHeadId > 0 ? e.SubHeadId : DBNull.Value;
                object unit = e.UnitId > 0 ? e.UnitId : DBNull.Value;
                object quantity = e.Quantity > 0 ? e.Quantity : DBNull.Value;
                object narration = string.IsNullOrWhiteSpace(e.Narration) ? DBNull.Value : e.Narration;

                var command = $@"INSERT INTO Dues(Date, Amount, IsSell, IsConstruction, SiteId, PartyId, HeadId, SubHeadId, 
                                                            UnitId, Quantity, Narration)
                                        VALUES(@Date, {e.Amount}, {e.IsSell}, {e.IsConstruction}, {e.SiteId}, {e.PartyId}, {e.HeadId}, @SubHead, 
                                                            @Unit, @Quantity,  @Narration)";
                var para = new List<SqliteParameter>() {
                                new SqliteParameter(@"Date", e.Date),
                                new SqliteParameter(@"SubHead", subHead),
                                new SqliteParameter(@"Unit", unit),
                                new SqliteParameter(@"Quantity", quantity),
                                new SqliteParameter(@"Narration", narration)
                            };
                commands.Add(new KeyValuePair<string, List<SqliteParameter>>(command, para));
            }
            else {
                object narration = string.IsNullOrWhiteSpace(e.Narration) ? DBNull.Value : e.Narration;
                var command = $@"INSERT INTO ReceiptPayments(Date, Amount, PartyId, HeadId, IsReceipt, IsCash, Narration)
                                            VALUES(@Date, {e.Amount}, {e.PartyId}, {e.HeadId}, {e.IsReceipt}, {e.IsCash}, @Narration)";
                var para = new List<SqliteParameter>() {
                                    new SqliteParameter(@"Date", e.Date),
                                    new SqliteParameter(@"Narration", narration)
                                };
                commands.Add(new KeyValuePair<string, List<SqliteParameter>>(command, para));
            }
        }
        transaction(commands);

        getIntoQueue(s, true, "");
    }

    public void EditSite(Request r, Socket s) {
        bool isSuccess = false;
        string message = "";
        var edited = (NetSite)r.Args[0];
        var original = sites.First(x => x.Id == edited.Id);
        var isEqual = edited.Name.Equals(original.Name) && edited.Address.Equals(original.Address);

        if (!isEqual) {

            command.CommandText = $"UPDATE Sites SET Name = @Name, Address = @Address WHERE Id = {edited.Id}";
            command.Parameters.AddWithValue("@Name", edited.Name);
            command.Parameters.AddWithValue("@Address", edited.Address);
            command.ExecuteNonQuery();
            command.Parameters.Clear();

            original.Name = edited.Name;
            original.Address = edited.Address;

            var bytes = siteBytes.First(x => x.Key == edited.Id);
            var newBytes = edited.GetBytes();
            sizes.site -= bytes.Value.Sum(x => x.Count);
            sizes.site += newBytes.Sum(x => x.Count);
            bytes.Value.RemoveRange(0, bytes.Value.Count);
            bytes.Value.AddRange(newBytes);

            broadcasts.Add(getBytes(r.UserId, Function.EditSite, newBytes));
            isSuccess = true;
        }
        else message = "Already been edited";
        getIntoQueue(s, isSuccess, message);
    }
    public void EditParty(Request r, Socket s) {
        bool isSuccess = false;
        string message = "";
        var edited = (NetParty)r.Args[0];
        var original = parties.First(x => x.Id == edited.Id);
        var isEqual = edited.Name.Equals(original.Name)
            && edited.Address.Equals(original.Address)
            && edited.Phone.Equals(original.Phone);

        if (!isEqual) {
            command.CommandText = $"UPDATE Parties SET Name = @Name, Address = @Address, Phone = @Phone WHERE Id = {edited.Id}";
            command.Parameters.AddWithValue("@Name", edited.Name);
            command.Parameters.AddWithValue("@Address", edited.Address);
            command.Parameters.AddWithValue("@Phone", string.IsNullOrWhiteSpace(edited.Phone) ? DBNull.Value : edited.Phone);
            command.ExecuteNonQuery();
            command.Parameters.Clear();

            original.Name = edited.Name;
            original.Address = edited.Address;
            original.Phone = edited.Phone;

            var bytes = partyBytes.First(x => x.Key == edited.Id);
            var newBytes = edited.GetBytes();
            sizes.party -= bytes.Value.Sum(x => x.Count);
            sizes.party += newBytes.Sum(x => x.Count);
            bytes.Value.RemoveRange(0, bytes.Value.Count);
            bytes.Value.AddRange(newBytes);

            broadcasts.Add(getBytes(r.UserId, Function.EditParty, newBytes));
            isSuccess = true;
        }
        else message = "Already been edited";
        getIntoQueue(s, isSuccess, message);
    }
    public void EditHead(Request r, Socket s) {
        bool isSuccess = false;
        string message = "";
        var edited = (NetHead)r.Args[0];
        var original = heads.First(x => x.Id == edited.Id);
        var isEqual = edited.Name.Equals(original.Name);

        if (!isEqual) {
            command.CommandText = $"UPDATE Heads SET Name = @Name WHERE Id = {edited.Id}";
            command.Parameters.AddWithValue("@Name", edited.Name);
            command.ExecuteNonQuery();
            command.Parameters.Clear();

            original.Name = edited.Name;

            var bytes = headBytes.First(x => x.Key == edited.Id);
            var newBytes = edited.GetBytes();
            sizes.head -= bytes.Value.Sum(x => x.Count);
            sizes.head += newBytes.Sum(x => x.Count);
            bytes.Value.RemoveRange(0, bytes.Value.Count);
            bytes.Value.AddRange(newBytes);

            broadcasts.Add(getBytes(r.UserId, Function.EditHead, newBytes));
            isSuccess = true;
        }
        else message = "Already been edited";
        getIntoQueue(s, isSuccess, message);
    }
    public void EditSubHead(Request r, Socket s) {
        bool isSuccess = false;
        string message = "";
        var edited = (NetSubHead)r.Args[0];
        var original = subHeads.First(x => x.Id == edited.Id);
        var isEqual = edited.Name.Equals(original.Name);

        if (!isEqual) {
            command.CommandText = $"UPDATE SubHeads SET Name = @Name WHERE Id = {edited.Id}";
            command.Parameters.AddWithValue("@Name", edited.Name);
            command.ExecuteNonQuery();
            command.Parameters.Clear();

            original.Name = edited.Name;

            var bytes = subHeadBytes.First(x => x.Key == edited.Id);
            var newBytes = edited.GetBytes();
            sizes.subHead -= bytes.Value.Sum(x => x.Count);
            sizes.subHead += newBytes.Sum(x => x.Count);
            bytes.Value.RemoveRange(0, bytes.Value.Count);
            bytes.Value.AddRange(newBytes);

            broadcasts.Add(getBytes(r.UserId, Function.EditSubHead, newBytes));
            isSuccess = true;
        }
        else message = "Already been edited";
        getIntoQueue(s, isSuccess, message);
    }
    public void EditUnit(Request r, Socket s) {
        bool isSuccess = false;
        string message = "";
        var edited = (NetUnit)r.Args[0];
        var original = units.First(x => x.Id == edited.Id);
        var isEqual = edited.Name.Equals(original.Name);

        if (!isEqual) {
            command.CommandText = $"UPDATE Units SET Name = @Name WHERE Id = {edited.Id}";
            command.Parameters.AddWithValue("@Name", edited.Name);
            command.ExecuteNonQuery();
            command.Parameters.Clear();

            original.Name = edited.Name;

            var bytes = unitBytes.First(x => x.Key == edited.Id);
            var newBytes = edited.GetBytes();
            sizes.unit -= bytes.Value.Sum(x => x.Count);
            sizes.unit += newBytes.Sum(x => x.Count);
            bytes.Value.RemoveRange(0, bytes.Value.Count);
            bytes.Value.AddRange(newBytes);

            broadcasts.Add(getBytes(r.UserId, Function.EditUnit, newBytes));
            isSuccess = true;
        }
        else message = "Already been edited";
        getIntoQueue(s, isSuccess, message);
    }
    public void EditNoteType(Request r, Socket s) {
        bool isSuccess = false;
        string message = "";
        var edited = (NetNoteType)r.Args[0];
        var original = noteTypes.First(x => x.Id == edited.Id);
        var isEqual = edited.Name.Equals(original.Name);

        if (!isEqual) {
            //database functionality

            original.Name = edited.Name;

            var bytes = noteTypeBytes.First(x => x.Key == edited.Id);
            var newBytes = edited.GetBytes();
            sizes.noteType -= bytes.Value.Sum(x => x.Count);
            sizes.noteType += newBytes.Sum(x => x.Count);
            bytes.Value.RemoveRange(0, bytes.Value.Count);
            bytes.Value.AddRange(newBytes);

            broadcasts.Add(getBytes(r.UserId, Function.EditNoteType, newBytes));
            isSuccess = true;
        }
        else message = "Already been edited";
        getIntoQueue(s, isSuccess, message);
    }
    public void EditNote(Request r, Socket s) {
        var note = (NetNote)r.Args[0];
        command.CommandText = $@"UPDATE Notes SET SiteId = {note.SiteId}, NoteTypeId = {note.NoteTypeId}, 
                                    Date = '{note.Date}', Entry = @Entry WHERE Id = {note.Id}";
        command.Parameters.AddWithValue("@Entry", note.Entry);
        command.ExecuteNonQuery();
        command.Parameters.Clear();

        broadcasts.Add(getBytes(r.UserId, Function.EditNote, note.GetBytes()));
        getIntoQueue(s, true, "");
    }
    public void EditReceiptPayment(Request r, Socket s) {
        var edited = (NetEntryReceiptPayment)r.Args[0];
        object narration = string.IsNullOrWhiteSpace(edited.Narration) ? DBNull.Value : edited.Narration;
        command.CommandText = $@"UPDATE ReceiptPayments SET Date = @Date, Amount = {edited.Amount}, PartyId = {edited.PartyId},
                                HeadId = {edited.HeadId}, IsReceipt = {edited.IsReceipt}, IsCash = {edited.IsCash}, Narration = @Narration
                                WHERE Id = @Id";
        command.Parameters.AddWithValue(@"Date", edited.Date);
        command.Parameters.AddWithValue(@"Narration", narration);
        command.Parameters.AddWithValue(@"Id", edited.Id);
        command.ExecuteNonQuery();
        command.Parameters.Clear();
        getIntoQueue(s, true, "");
    }
    public void EditPurchaseSell(Request r, Socket s) {
        var edited = (NetPurchaseSell)r.Args[0];
        object subHead = edited.SubHeadId > 0 ? edited.SubHeadId : DBNull.Value;
        object unit = edited.UnitId > 0 ? edited.UnitId : DBNull.Value;
        object quantity = edited.Quantity > 0 ? edited.Quantity : DBNull.Value;
        object narration = string.IsNullOrWhiteSpace(edited.Narration) ? DBNull.Value : edited.Narration;

        command.CommandText = $@"UPDATE Dues SET Date = @Date, Amount = {edited.Amount}, IsSell = {edited.IsSell}, 
                                    IsConstruction = {edited.IsConstruction}, SiteId = {edited.SiteId}, PartyId = {edited.PartyId}, 
                                    HeadId = {edited.HeadId}, SubHeadId = @SubHead, UnitId = @Unit, Quantity = @Quantity, 
                                    Narration = @Narration WHERE Id = @Id";
        command.Parameters.AddWithValue(@"Date", edited.Date);
        command.Parameters.AddWithValue(@"SubHead", subHead);
        command.Parameters.AddWithValue(@"Unit", unit);
        command.Parameters.AddWithValue(@"Quantity", quantity);
        command.Parameters.AddWithValue(@"Narration", narration);
        command.Parameters.AddWithValue(@"Id", edited.Id);
        command.ExecuteNonQuery();
        command.Parameters.Clear();
        getIntoQueue(s, true, "");
    }

    public void DeleteReceiptPayment(Request r, Socket s) {
        var id = (int)r.Args[0];
        command.CommandText = $"DELETE From ReceiptPayments WHERE Id = {id}";
        command.ExecuteNonQuery();
        getIntoQueue(s, true, "");
    }
    public void DeletePurchaseSell(Request r, Socket s) {
        var id = (int)r.Args[0];
        command.CommandText = $"DELETE From Dues WHERE Id = {id}";
        command.ExecuteNonQuery();
        getIntoQueue(s, true, "");
    }
    public void DeleteNote(Request r, Socket s) {
        var id = (int)r.Args[0];
        command.CommandText = $"DELETE FROM Notes WHERE Id = {id}";
        command.ExecuteNonQuery();
        broadcasts.Add(getBytes(r.UserId, Function.DeleteNote, new List<ArraySegment<byte>>() { BitConverter.GetBytes(id) }));
        getIntoQueue(s, true, "");
    }
 
    public void GetNotes(Socket s) {
        var list = new List<NetEntryNoteText>();
        command.CommandText = @"SELECT Date, nt.Name, si.Name, Entry, n.Id FROM Notes n
                                LEFT JOIN Sites si ON si.Id = n.SiteId
                                LEFT JOIN NoteTypes nt ON nt.Id = n.NoteTypeId
                                ORDER BY Date DESC;";
        var reader = command.ExecuteReader();
        while (reader.Read()) {
            list.Add(new NetEntryNoteText() {
                Date = reader.GetString(0),
                NoteType = reader.GetString(1),
                Site = reader.GetString(2),
                Entry = reader.GetString(3),
                Id = reader.GetInt32(4)
            });
        }
        reader.Close();
        reader.DisposeAsync();

        var bytes = new List<ArraySegment<byte>>();
        int size = 0;
        foreach (var item in list) {
            var b = item.GetBytes();
            size += b.Sum(x => x.Count);
            bytes.AddRange(b);
        }
        bytes.Insert(0, BitConverter.GetBytes(size));
        responses.Add(new QueuedResponse() {
            Sender = s,
            Message = bytes
        });
    }
    public void GetLedger(Request r, Socket s) {
        int id = (int)r.Args[0];
        var list = new List<NetReportEntry>();
        command.CommandText = $@"WITH t1(Date, Particulars, Receivable, Payable) AS(
                                 	SELECT Date, si.Name || ' - ' || he.Name || coalesce( ' - ' || sh.Name, '') || 
                                 		coalesce( ' - ' || Quantity, '') || coalesce( ' ' || un.Name, '') || 
                                 		coalesce( ' - ' || Narration, ''),
                                 		CASE WHEN IsSell = 1 THEN Amount ELSE 0 END,
                                 		CASE WHEN IsSell = 0 THEN Amount ELSE 0 END
                                 	FROM Dues t
                                 	LEFT JOIN Sites si ON t.SiteId = si.Id
                                 	LEFT JOIN Heads he ON t.HeadId = he.Id
                                 	LEFT JOIN SubHeads sh ON t.SubHeadId = sh.Id
                                 	LEFT JOIN Units un ON t.UnitId = un.Id
                                 	WHERE PartyId = {id}
                                 ),
                                 t2(Date, Particulars, Receivable, Payable) AS(
                                 	SELECT Date, he.Name || ' - ' || 
                                 		CASE IsCash WHEN 0 THEN 'Cash' WHEN 1 THEN 'Mobile' WHEN 2 THEN 'Discount' END,
                                         CASE WHEN IsReceipt = 0 THEN Amount ELSE 0 END,
                                 		CASE WHEN IsReceipt = 1 THEN Amount ELSE 0 END
                                     FROM ReceiptPayments t
                                     LEFT JOIN Heads he ON t.HeadId = he.Id
                                     WHERE PartyId = {id}
                                 ),
                                 t3 AS (SELECT * FROM t1 UNION ALL SELECT * FROM t2)
                                 SELECT * FROM t3 ORDER BY Date";
        var reader = command.ExecuteReader();
        while (reader.Read()) {
            list.Add(new NetReportEntry() {
                Date = reader.GetString(0),
                Particulars = reader.GetString(1),
                ReceivablePayment = reader.GetInt32(2),
                PayableReceipt = reader.GetInt32(3)
            });
        }
        reader.Close();
        reader.DisposeAsync();

        var bytes = new List<ArraySegment<byte>>();
        int size = 0;
        foreach (var item in list) {
            var b = item.GetBytes();
            size += b.Sum(x => x.Count);
            bytes.AddRange(b);
        }
        bytes.Insert(0, BitConverter.GetBytes(size));
        responses.Add(new QueuedResponse() {
            Sender = s,
            Message = bytes
        });
    }
    public void GetDates(Request r, Socket s) {
        command.CommandText = @"WITH t(StartDate, EndDate) AS(
                                        	SELECT MIN(Date), MAX(Date) FROM Dues
                                        	UNION 
                                        	SELECT MIN(Date), MAX(Date) FROM ReceiptPayments
                                        )
                                        SELECT MIN(StartDate), MAX(EndDate) FROM t";
        var reader = command.ExecuteReader();
        var dates = new NetDates() { From = DateTime.Today.AddYears(-1).ToString("yyyy-MM-dd") };
        while (reader.Read()) {
            if (!reader.IsDBNull(0)) {
                dates.Start = reader.GetString(0);
                dates.To = dates.End = reader.GetString(1);
            }
            else dates.To = DateTime.Today.ToString("yyyy-MM-dd");
        }
        reader.Close();
        reader.DisposeAsync();

        var dateBytes = dates.GetBytes();
        var length = dateBytes.Sum(x => x.Count);
        var bytes = new List<ArraySegment<byte>>() {
            BitConverter.GetBytes(length)
        };
        bytes.AddRange(dateBytes);
        responses.Add(new QueuedResponse() {
            Sender = s,
            Message = bytes
        });
    }
    public void GetDues(Socket s) {
        var list = new List<NetSumTransaction>();
        command.CommandText = @"WITH t1(PartyId, Head, Purchase, Sell) AS(
									SELECT PartyId, CASE IsSell WHEN 0 THEN 'Purchase' ELSE 'Sell' END Head,
										SUM(CASE WHEN IsSell = 0 THEN Amount ELSE 0 END),
										SUM(CASE WHEN IsSell = 1 THEN Amount ELSE 0 END)
									FROM Dues
									GROUP BY PartyId, Head
								),
								t2(PartyId, Head, Receipt, Payment) AS(
									SELECT PartyId, he.Name Head,
										SUM(CASE WHEN IsReceipt = 1 THEN Amount ELSE 0 END),
										SUM(CASE WHEN IsReceipt = 0 THEN Amount ELSE 0 END)
									FROM ReceiptPayments rp
									LEFT JOIN Heads he ON he.Id = rp.HeadId
									GROUP BY PartyId, Head
								),
								t3 (PartyId, Head, PurRec, SelPay) AS(
									SELECT * FROM t1 UNION ALL 
									SELECT PartyId, CASE Head 
										WHEN 'Payable' THEN 'Paid'
										WHEN 'Receivable' THEN 'Received'
										ELSE Head END Head,
									Receipt, Payment
									FROM t2
								)
								SELECT * FROM t3";
        var reader = command.ExecuteReader();
        while (reader.Read()) {
            list.Add(new NetSumTransaction() {
                PartyId = reader.GetInt32(0),
                Head = reader.GetString(1),
                PurchaseReceipt = reader.GetInt32(2),
                SellPayment = reader.GetInt32(3)
            });
        }
        reader.Close();
        reader.DisposeAsync();

        var bytes = new List<ArraySegment<byte>>();
        int size = 0;
        foreach (var item in list) {
            var b = item.GetBytes();
            size += b.Sum(x => x.Count);
            bytes.AddRange(b);
        }
        bytes.Insert(0, BitConverter.GetBytes(size));
        responses.Add(new QueuedResponse() {
            Sender = s,
            Message = bytes
        });
    }   
    public void GetPurchaseSell(Request r, Socket s) {
        var from = r.Args[0].ToString();
        var to = r.Args[1].ToString();
        command.CommandText = $@"SELECT Date, si.Name, pa.Name, he.Name, coalesce(sh.Name, ''), coalesce(Quantity, 0), 
                                 coalesce(un.Name, ''), coalesce(Narration, ''), IsSell, IsConstruction,
                                    CASE IsSell WHEN 0 THEN Amount ELSE 0 END,
                                    CASE IsSell WHEN 1 THEN Amount ELSE 0 END
                                 FROM Dues d
                                 LEFT JOIN Sites si ON d.SiteId = si.Id
                                 LEFT JOIN Parties pa ON d.PartyId = pa.Id
                                 LEFT JOIN Heads he ON d.HeadId = he.Id
                                 LEFT JOIN SubHeads sh ON d.SubHeadId = sh.Id
                                 LEFT JOIN Units un ON d.UnitId = un.Id 
                                 WHERE Date BETWEEN '{from}' AND '{to}'";
        var list = new List<NetDue>();
        var reader = command.ExecuteReader();
        while (reader.Read()) {
            list.Add(new NetDue() {
                Date = reader.GetString(0),
                Site = reader.GetString(1),
                Party = reader.GetString(2),
                Head = reader.GetString(3),
                SubHead = reader.GetString(4),
                Quantity = reader.GetDouble(5),
                Unit = reader.GetString(6),
                Narration = reader.GetString(7),
                IsSell = reader.GetByte(8),
                IsConstruction = reader.GetByte(9),
                Purchase = reader.GetInt32(10),
                Sell = reader.GetInt32(11)
            });
        }
        reader.Close();
        reader.DisposeAsync();

        var bytes = new List<ArraySegment<byte>>();
        int size = 0;
        foreach (var item in list) {
            var b = item.GetBytes();
            size += b.Sum(x => x.Count);
            bytes.AddRange(b);
        }
        bytes.Insert(0, BitConverter.GetBytes(size));
        responses.Add(new QueuedResponse() {
            Sender = s,
            Message = bytes
        });
    }
    public void GetReceiptPayment(Request r, Socket s) {
        var from = r.Args[0].ToString();
        var to = r.Args[1].ToString();
        var list = new List<NetReceiptPayment>();
        command.CommandText = $@"SELECT Date, pa.Name, he.Name, coalesce(Narration, ''), strftime('%Y - %m', Date),
                                 	CASE WHEN IsReceipt=0 THEN Amount ELSE 0 END,
                                 	CASE WHEN IsReceipt=1 THEN Amount ELSE 0 END,
                                 IsCash
                                 FROM ReceiptPayments rp
                                 LEFT JOIN Parties pa ON pa.Id = rp.PartyId
                                 LEFT JOIN Heads he ON he.Id = rp.HeadId
                                 WHERE Date BETWEEN '{from}' AND '{to}'";
        var reader = command.ExecuteReader();
        while (reader.Read()) {
            list.Add(new NetReceiptPayment() {
                Date = reader.GetString(0),
                Party = reader.GetString(1),
                Head = reader.GetString(2),
                Narration = reader.GetString(3),
                Month = reader.GetString(4),
                Payment = reader.GetInt32(5),
                Receipt = reader.GetInt32(6),
                IsCash = reader.GetByte(7)
            });
        }
        reader.Close();
        reader.DisposeAsync();

        var bytes = new List<ArraySegment<byte>>();
        int size = 0;
        foreach (var item in list) {
            var b = item.GetBytes();
            size += b.Sum(x => x.Count);
            bytes.AddRange(b);
        }
        bytes.Insert(0, BitConverter.GetBytes(size));
        responses.Add(new QueuedResponse() {
            Sender = s,
            Message = bytes
        });
    }
    public void GetDetailPurchasePayable(Request r, Socket s) {
        string type = r.Args[0].ToString();
        var from = r.Args[1].ToString();
        var to = r.Args[2].ToString();
        var state = (byte)r.Args[3];
        var id = (int)r.Args[4];

        string query = "";

        switch (type) {
            case "Site":
                switch (state) {
                    case 0: // Head
                        query = $@"SELECT Heads.Name, SUM(Amount), 0, 0 FROM Dues
								LEFT JOIN Heads ON Heads.Id = Dues.HeadId
								WHERE IsSell = 0 AND SiteId = {id} AND
								Date BETWEEN '{from}' AND '{to}'
								GROUP BY Heads.Name";
                        break;
                    case 1: // Party
                        query = $@"SELECT Parties.Name, SUM(Amount), 0, 0 FROM Dues
								LEFT JOIN Parties ON Parties.Id = Dues.PartyId
								WHERE IsSell = 0 AND SiteId = {id} AND
								Date BETWEEN '{from}' AND '{to}'
								GROUP BY Parties.Name";
                        break;
                }
                break;
            case "Head":
                switch (state) {
                    case 0: // Site
                        query = $@"SELECT Sites.Name, SUM(Amount), 0, 0 FROM Dues
								LEFT JOIN Sites ON Sites.Id = Dues.SiteId
								WHERE IsSell = 0 AND HeadId = {id} AND
								Date BETWEEN '{from}' AND '{to}'
								GROUP BY Sites.Name";
                        break;
                    case 1: //Party
                        query = $@"SELECT Parties.Name, SUM(Amount), 0, 0 FROM Dues
								LEFT JOIN Parties ON Parties.Id = Dues.PartyId
								WHERE IsSell = 0 AND HeadId = {id} AND
								Date BETWEEN '{from}' AND '{to}'
								GROUP BY Parties.Name";
                        break;
                }
                break;
            case "Party":
                switch (state) {
                    case 0: // Site
                        query = $@"SELECT Sites.Name, SUM(Amount), 0, 0 FROM Dues
								LEFT JOIN Sites ON Sites.Id = Dues.SiteId
								WHERE IsSell = 0 AND PartyId = {id} AND
								Date BETWEEN '{from}' AND '{to}'
								GROUP BY Sites.Name";
                        break;
                    case 1: // Head
                        query = $@"SELECT Heads.Name, SUM(Amount), 0, 0 FROM Dues
								LEFT JOIN Heads ON Heads.Id = Dues.HeadId
								WHERE IsSell = 0 AND PartyId = {id} AND
								Date BETWEEN '{from}' AND '{to}'
								GROUP BY Heads.Name";
                        break;
                }
                break;
        }
        var list = new List<NetKeyValueSeries>();
        command.CommandText = query;
        var reader = command.ExecuteReader();
        while (reader.Read()) {
            list.Add(new NetKeyValueSeries() {
                Key = reader.GetString(0),
                Value = reader.GetInt32(1)
            });
        }
        reader.Close();
        reader.DisposeAsync();

        var bytes = new List<ArraySegment<byte>>();
        int size = 0;
        foreach (var item in list) {
            var b = item.GetBytes();
            size += b.Sum(x => x.Count);
            bytes.AddRange(b);
        }
        bytes.Insert(0, BitConverter.GetBytes(size));
        responses.Add(new QueuedResponse() {
            Sender = s,
            Message = bytes
        });
    }
    public void GetSingleHeadOrSitewisePurchase(Request r, Socket s) {
        var state = (byte)r.Args[0];
        var id = (int)r.Args[1];
        var max = (int)r.Args[2];
        var type = r.Args[3].ToString();
        string query = "";

        switch (state) {
            case 0:
                if (type.Equals("Head")) {
                    query = $@"WITH t AS(
                               	SELECT Date, SUM(Amount) FROM Dues WHERE HeadId = {id} AND IsSell = 0
                               	GROUP BY Date
                               	ORDER BY Date DESC
                               	LIMIT {max}
                               )
                               SELECT * FROM t ORDER BY Date";
                }
                else {
                    query = $@"WITH t AS(
                               	SELECT Date, SUM(Amount) FROM Dues WHERE SiteId = {id} AND IsSell = 0
                               	GROUP BY Date
                               	ORDER BY Date DESC
                               	LIMIT {max}
                               )
                               SELECT * FROM t ORDER BY Date";
                }
                break;
            case 1:
                if (type.Equals("Head")) {
                    query = $@"WITH t AS(
                               	SELECT strftime('%Y - %m', Date) Month, SUM(Amount) FROM Dues
                               	WHERE HeadId = {id} AND IsSell = 0
                               	GROUP BY Month
                               	ORDER BY Month DESC
                               	LIMIT {max}
                               )
                               SELECT * FROM t ORDER BY Month";
                }
                else {
                    query = $@"WITH t AS(
                               	SELECT strftime('%Y - %m', Date) Month, SUM(Amount) FROM Dues
                               	WHERE SiteId = {id} AND IsSell = 0
                               	GROUP BY Month
                               	ORDER BY Month DESC
                               	LIMIT {max}
                               )
                               SELECT * FROM t ORDER BY Month";
                }
                break;
        }
        var list = new List<NetKeyValueSeries>();
        command.CommandText = query;
        var reader = command.ExecuteReader();
        while (reader.Read()) {
            list.Add(new NetKeyValueSeries() {
                Key = reader.GetString(0),
                Value = reader.GetInt32(1)
            });
        }
        reader.Close();
        reader.DisposeAsync();

        var bytes = new List<ArraySegment<byte>>();
        int size = 0;
        foreach (var item in list) {
            var b = item.GetBytes();
            size += b.Sum(x => x.Count);
            bytes.AddRange(b);
        }
        bytes.Insert(0, BitConverter.GetBytes(size));
        responses.Add(new QueuedResponse() {
            Sender = s,
            Message = bytes
        });
    }
    public void GetAllHeadOrSitewisePurchase(Request r, Socket s) {
        var type = r.Args[0].ToString();
        var from = r.Args[1].ToString();
        var to = r.Args[2].ToString();
        string query = "";
        if (type.Equals("Head")) {
            query = $@"SELECT Heads.Name, SUM(Amount) FROM Dues
                       LEFT JOIN Heads ON Heads.Id = Dues.HeadId
                       WHERE IsSell = 0 AND 
                       Date BETWEEN '{from}' AND '{to}'
                       GROUP BY Heads.Name";
        }
        else {
            query = $@"SELECT Sites.Name, SUM(Amount) FROM Dues
                       LEFT JOIN Sites ON Sites.Id = Dues.SiteId
                       WHERE IsSell = 0 AND
                       Date BETWEEN '{from}' AND '{to}'
                       GROUP BY Sites.Name";
        }
        var list = new List<NetKeyValueSeries>();
        command.CommandText = query;
        var reader = command.ExecuteReader();
        while (reader.Read()) {
            list.Add(new NetKeyValueSeries() {
                Key = reader.GetString(0),
                Value = reader.GetInt32(1)
            });
        }
        reader.Close();
        reader.DisposeAsync();

        var bytes = new List<ArraySegment<byte>>();
        int size = 0;
        foreach (var item in list) {
            var b = item.GetBytes();
            size += b.Sum(x => x.Count);
            bytes.AddRange(b);
        }
        bytes.Insert(0, BitConverter.GetBytes(size));
        responses.Add(new QueuedResponse() {
            Sender = s,
            Message = bytes
        });
    }
    public void GetAllPartyTransactions(Request r, Socket s) {
        var from = r.Args[1].ToString();
        var to = r.Args[2].ToString();
        var list = new List<NetKeyTrippleValueSeries>();
        command.CommandText = $@"WITH t1 (Party, Purchase, Payment, Due) AS(
									SELECT Parties.Name, SUM(Amount), 0, 0 FROM Dues
									LEFT JOIN Parties ON Parties.Id = Dues.PartyId
									WHERE IsSell = 0 AND
									Date BETWEEN '{from}' AND '{to}'
									GROUP BY Parties.Name
								),
								t2(Party, Purchase, Payment, Due) AS(
									SELECT Parties.Name, 0, SUM(Amount), 0 FROM ReceiptPayments rp
									LEFT JOIN Parties ON Parties.Id = rp.PartyId
									WHERE IsReceipt = 0 AND
									Date BETWEEN '{from}' AND '{to}'
									GROUP BY Parties.Name
								),
								t3(Party, Purchase, Payment, Due) AS(
									SELECT * FROM t1
									UNION ALL
									SELECT * FROM t2
								),
								t4(Party, Purchase, Payment, Due) AS(
									SELECT Party, SUM(Purchase), SUM(Payment), SUM(Purchase - Payment)
									FROM t3
									GROUP BY Party
								)
								SELECT * FROM t4";

        var reader = command.ExecuteReader();
        while (reader.Read()) {
            list.Add(new NetKeyTrippleValueSeries() {
                Key = reader.GetString(0),
                Value1 = reader.GetInt32(1),
                Value2 = reader.GetInt32(2),
                Value3 = reader.GetInt32(3)
            });
        }
        reader.Close();
        reader.DisposeAsync();

        var bytes = new List<ArraySegment<byte>>();
        int size = 0;
        foreach (var item in list) {
            var b = item.GetBytes();
            size += b.Sum(x => x.Count);
            bytes.AddRange(b);
        }
        bytes.Insert(0, BitConverter.GetBytes(size));
        responses.Add(new QueuedResponse() {
            Sender = s,
            Message = bytes
        });
    }
    public void GetSinglePartyTransaction(Request r, Socket s) {
        var state = (byte)r.Args[0];
        var id = (int)r.Args[1];
        var max = (int)r.Args[2];
        string query = "";

        if (state == 0) {
            query = $@"WITH t1(Date, Puchase, Payment, Due) AS(
                       	SELECT Date, SUM(Amount),0,0 FROM Dues WHERE PartyId = {id} AND IsSell = 0
                       	GROUP BY Date
                       	ORDER BY Date DESC
                       	LIMIT {max}
                       ),
                       t2(Date, Puchase, Payment, Due) AS(
                       	SELECT (SELECT MIN(Date) FROM t1), 0, 0, 
                       	(SELECT SUM(Amount) FROM Dues WHERE Date <= (SELECT MIN(Date) FROM t1) AND PartyId = {id} AND IsSell = 0)
                       	- (SELECT SUM(Amount) FROM ReceiptPayments WHERE Date <= (SELECT MIN(Date) FROM t1) AND PartyId = {id} AND IsReceipt = 0)
                       ),
                       t3(Date, Puchase, Payment, Due) AS(
                       	SELECT Date, 0, SUM(Amount),0 FROM ReceiptPayments WHERE PartyId = {id} AND IsReceipt = 0
                       	AND Date >= (SELECT MIN(Date) FROM t1)
                       	GROUP BY Date
                       ),
                       t4(Date, Puchase, Payment, Due) AS(
                       	SELECT * FROM t1
                       	UNION ALL
                       	SELECT * FROM t2
                       	UNION ALL
                       	SELECT * FROM t3
                       ),
                       t5(Date, Puchase, Payment, Due) AS(
                       	SELECT Date, SUM(Puchase), SUM(Payment), SUM(Due) FROM t4
                       	GROUP BY Date
                       ),
                       t6(RowNum, Date, Puchase, Payment, Due) AS(
                       	SELECT ROW_NUMBER() OVER(), * FROM t5 ORDER BY Date
                       )
                       SELECT Date, Puchase, Payment, 
                       	CASE RowNum WHEN 1 THEN Due ELSE
                       	SUM(Due + Puchase - Payment) OVER (ORDER BY RowNum) END Due 
                       FROM t6 LIMIT {max}";
        }
        else {
            query = $@"WITH t1(Month, Puchase, Payment, Due) AS(
                       	SELECT strftime('%Y - %m', Date) Month, SUM(Amount),0,0 FROM Dues WHERE PartyId = {id} AND IsSell = 0
                       	GROUP BY Month
                       	ORDER BY Month DESC
                       	LIMIT {max}
                       ),
                       t2(Month, Puchase, Payment, Due) AS(
                       	SELECT (SELECT MIN(Month) FROM t1), 0, 0, 
                       	(SELECT SUM(Amount) FROM Dues WHERE strftime('%Y - %m', Date) <= (SELECT MIN(Month) FROM t1) AND PartyId = {id} AND IsSell = 0)
                       	- (SELECT SUM(Amount) FROM ReceiptPayments WHERE strftime('%Y - %m', Date) <= (SELECT MIN(Month) FROM t1) AND PartyId = {id} AND IsReceipt = 0)
                       ),
                       t3(Month, Puchase, Payment, Due) AS(
                       	SELECT strftime('%Y - %m', Date) Month, 0, SUM(Amount),0 FROM ReceiptPayments WHERE PartyId = {id} AND IsReceipt = 0
                       	AND Month >= (SELECT MIN(Month) FROM t1)
                       	GROUP BY Month
                       ),
                       t4(Month, Puchase, Payment, Due) AS(
                       	SELECT * FROM t1
                       	UNION ALL
                       	SELECT * FROM t2
                       	UNION ALL
                       	SELECT * FROM t3
                       ),
                       t5(Month, Puchase, Payment, Due) AS(
                       	SELECT Month, SUM(Puchase), SUM(Payment), SUM(Due) FROM t4
                       	GROUP BY Month
                       ),
                       t6(RowNum, Month, Puchase, Payment, Due) AS(
                       	SELECT ROW_NUMBER() OVER(), * FROM t5 ORDER BY Month
                       )
                       SELECT Month, Puchase, Payment, 
                       	CASE RowNum WHEN 1 THEN Due ELSE
                       	SUM(Due + Puchase - Payment) OVER (ORDER BY RowNum) END Due 
                       FROM t6 LIMIT {max}";
        }
        var list = new List<NetKeyTrippleValueSeries>();
        command.CommandText = query;
        var reader = command.ExecuteReader();
        while (reader.Read()) {
            list.Add(new NetKeyTrippleValueSeries() {
                Key = reader.GetString(0),
                Value1 = reader.GetInt32(1),
                Value2 = reader.GetInt32(2),
                Value3 = reader.GetInt32(3)
            });
        }
        reader.Close();
        reader.DisposeAsync();

        var bytes = new List<ArraySegment<byte>>();
        int size = 0;
        foreach (var item in list) {
            var b = item.GetBytes();
            size += b.Sum(x => x.Count);
            bytes.AddRange(b);
        }
        bytes.Insert(0, BitConverter.GetBytes(size));
        responses.Add(new QueuedResponse() {
            Sender = s,
            Message = bytes
        });

    }
    public void GetPurchases(Request r, Socket s) {
        var state = (byte)r.Args[0];
        var from = r.Args[1].ToString();
        var to = r.Args[2].ToString();
        string query = "";

        if (state == 4 /*All*/) query = $@"SELECT Sites.Name, SUM(Amount) FROM Dues
                                        LEFT JOIN Sites ON Sites.Id = SiteId
                                        WHERE IsSell = 0 AND Date BETWEEN '{from}' AND '{to}'
                                        GROUP BY Sites.Name";
        else query = @$"SELECT Sites.Name, SUM(Amount) FROM Dues
                        LEFT JOIN Sites ON Sites.Id = SiteId
                        WHERE IsSell = 0 AND IsConstruction = {state} AND 
                        Date BETWEEN '{from}' AND '{to}'
                        GROUP BY Sites.Name";

        var list = new List<NetKeyValueSeries>();
        command.CommandText = query;
        var reader = command.ExecuteReader();
        while (reader.Read()) {
            list.Add(new NetKeyValueSeries() {
                Key = reader.GetString(0),
                Value = reader.GetInt32(1)
            });
        }
        reader.Close();
        reader.DisposeAsync();

        var bytes = new List<ArraySegment<byte>>();
        int size = 0;
        foreach (var item in list) {
            var b = item.GetBytes();
            size += b.Sum(x => x.Count);
            bytes.AddRange(b);
        }
        bytes.Insert(0, BitConverter.GetBytes(size));
        responses.Add(new QueuedResponse() {
            Sender = s,
            Message = bytes
        });
    }
    public void GetPayments(Request r, Socket s) {
        var from = r.Args[0].ToString();
        var to = r.Args[1].ToString();
        command.CommandText = $@"SELECT CASE IsCash WHEN 0 THEN 'Cash' WHEN 1 THEN 'Mobile' ELSE 'Discount' END Mode, 
                                 SUM(Amount) FROM ReceiptPayments WHERE IsReceipt = 0 AND 
                                 Date BETWEEN '{from}' AND '{to}'
                                 GROUP BY Mode";
        var list = new List<NetKeyValueSeries>();
        var reader = command.ExecuteReader();
        while (reader.Read()) {
            list.Add(new NetKeyValueSeries() {
                Key = reader.GetString(0),
                Value = reader.GetInt32(1)
            });
        }
        reader.Close();
        reader.DisposeAsync();

        var bytes = new List<ArraySegment<byte>>();
        int size = 0;
        foreach (var item in list) {
            var b = item.GetBytes();
            size += b.Sum(x => x.Count);
            bytes.AddRange(b);
        }
        bytes.Insert(0, BitConverter.GetBytes(size));
        responses.Add(new QueuedResponse() {
            Sender = s,
            Message = bytes
        });
    }
    public void GetReceiptPaymentByDate(Request r, Socket s) {
        var date = r.Args[0].ToString();
        var list = new List<NetReceiptPaymentText>();
        command.CommandText = $@"SELECT Date, Amount, pa.Name, he.Name, IsReceipt, IsCash, coalesce(Narration, ''), d.Id FROM ReceiptPayments d
                                 LEFT JOIN Parties pa ON pa.Id = d.PartyId
                                 LEFT JOIN Heads he ON he.Id = d.HeadId
                                 WHERE Date = '{date}'";
        var reader = command.ExecuteReader();
        while (reader.Read()) {
            list.Add(new NetReceiptPaymentText() {
                Date = reader.GetString(0),
                Amount = reader.GetInt32(1).ToString(),
                Party = reader.GetString(2),
                Head = reader.GetString(3),
                IsReceipt = reader.GetByte(4),
                IsCash = reader.GetByte(5),
                Narration = reader.GetString(6),
                Id = reader.GetInt32(7)
            });
        }
        reader.Close();
        reader.DisposeAsync();

        int total = 0;
        var bytes = new List<ArraySegment<byte>>();
        foreach (var e in list) {
            var b = e.GetBytes();
            total += b.Sum(x => x.Count);
            bytes.AddRange(b);
        }
        bytes.Insert(0, BitConverter.GetBytes(total));
        responses.Add(new QueuedResponse() {
            Sender = s,
            Message = bytes
        });
    }
    public void GetPurchaseSellByDate(Request r, Socket s) {
        var date = r.Args[0].ToString();
        var list = new List<NetPurchaseSellText>();
        command.CommandText = $@"SELECT Date, Amount, IsSell, IsConstruction, si.Name, pa.Name, he.Name, 
                                 coalesce(sh.Name, ''), coalesce(Quantity, ''), coalesce(un.Name, ''), coalesce(Narration, ''), d.Id FROM Dues d
                                 LEFT JOIN Sites si ON si.Id = d.SiteId
                                 LEFT JOIN Parties pa ON pa.Id = d.PartyId
                                 LEFT JOIN Heads he ON he.Id = d.HeadId
                                 LEFT JOIN SubHeads sh ON sh.Id = d.SubHeadId
                                 LEFT JOIN Units un ON un.Id = d.UnitId
                                 WHERE Date = '{date}'";
        var reader = command.ExecuteReader();
        while (reader.Read()) {
            list.Add(new NetPurchaseSellText() {
                Date = reader.GetString(0),
                Amount = reader.GetInt32(1).ToString("N0"),
                IsSell = reader.GetByte(2),
                IsConstruction = reader.GetByte(3),
                Site = reader.GetString(4),
                Party = reader.GetString(5),
                Head = reader.GetString(6),
                SubHead = reader.GetString(7),
                Quantity = reader.GetString(8),
                Unit = reader.GetString(9),
                Narration = reader.GetString(10),
                Id = reader.GetInt32(11)
            });
        }
        reader.Close();
        reader.DisposeAsync();

        int total = 0;
        var bytes = new List<ArraySegment<byte>>();
        foreach (var e in list) {
            var b = e.GetBytes();
            total += b.Sum(x => x.Count);
            bytes.AddRange(b);
        }
        bytes.Insert(0, BitConverter.GetBytes(total));
        responses.Add(new QueuedResponse() {
            Sender = s,
            Message = bytes
        });
    }
}