﻿public class NetPurchaseSell
{
    public byte IsSell { get; set; }
    public byte IsConstruction { get; set; }
    public int Id { get; set; }
    public int SiteId { get; set; }
    public int PartyId { get; set; }
    public int HeadId { get; set; }
    public int SubHeadId { get; set; }
    public int UnitId { get; set; }
    public int Amount { get; set; }
    public double Quantity { get; set; }
    public string Date { get; set; }
    public string Narration { get; set; }

    public List<ArraySegment<byte>> GetBytes() {
        return new List<ArraySegment<byte>>() {
            new byte[1]{ IsSell },
            new byte[1]{ IsConstruction },
            BitConverter.GetBytes(Id),
            BitConverter.GetBytes(SiteId),
            BitConverter.GetBytes(PartyId),
            BitConverter.GetBytes(HeadId),
            BitConverter.GetBytes(SubHeadId),
            BitConverter.GetBytes(UnitId),
            BitConverter.GetBytes(Amount),
            BitConverter.GetBytes(Quantity),
            Encoding.ASCII.GetBytes(Date + '\0'),
            Encoding.ASCII.GetBytes(Narration + '\0')
        };
    }
    public static NetPurchaseSell FromBytes(ReadOnlySpan<byte> array) {
        int start, read, index;
        start = read = 38;
        index = 0;
        var segments = new string[2];
        while (read < array.Length) {
            if (array[read] != 0) {
                read++;
                continue;
            }
            segments[index++] = Encoding.ASCII.GetString(array.Slice(start, read - start));
            start = ++read;
            if (index == segments.Length) break;
        }
        return new NetPurchaseSell() {
            IsSell = array.Slice(0, 1)[0],
            IsConstruction = array.Slice(1, 1)[0],
            Id = BitConverter.ToInt32(array.Slice(2, 4)),
            SiteId = BitConverter.ToInt32(array.Slice(6, 4)),
            PartyId = BitConverter.ToInt32(array.Slice(10, 4)),
            HeadId = BitConverter.ToInt32(array.Slice(14, 4)),
            SubHeadId = BitConverter.ToInt32(array.Slice(18, 4)),
            UnitId = BitConverter.ToInt32(array.Slice(22, 4)),
            Amount = BitConverter.ToInt32(array.Slice(26, 4)),
            Quantity = BitConverter.ToDouble(array.Slice(30, 8)),
            Date = segments[0],
            Narration = segments[1]
        };
    }
}
