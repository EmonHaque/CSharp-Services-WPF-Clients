﻿public class NetReportEntry
{
    public string Date { get; set; }
    public string Particulars { get; set; }
    public int ReceivablePayment { get; set; }
    public int PayableReceipt { get; set; }

    public List<ArraySegment<byte>> GetBytes() {
        return new List<ArraySegment<byte>>() {
            Encoding.ASCII.GetBytes(Date + '\0'),
            Encoding.ASCII.GetBytes(Particulars + '\0'),
            BitConverter.GetBytes(ReceivablePayment),
            BitConverter.GetBytes(PayableReceipt)
        };
    }

}
