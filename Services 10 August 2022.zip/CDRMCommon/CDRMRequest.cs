﻿public class CDRMRequest : Request
{
    protected override List<ArraySegment<byte>> getArgBytes() {
        switch ((Function)Method) {
            case Function.GetInitialData:
            case Function.GetDues:
            case Function.GetDates: return new List<ArraySegment<byte>>();
            case Function.GetLedger: return new List<ArraySegment<byte>>() { BitConverter.GetBytes((int)Args[0]) };
            case Function.GetPurchaseSellByDate:
            case Function.GetReceiptPaymentByDate: return new List<ArraySegment<byte>>() {
                Encoding.ASCII.GetBytes(Args[0].ToString())
            };
            case Function.GetAllHeadOrSitewisePurchase:
            case Function.GetAllPartyTransactions: {
                    return new List<ArraySegment<byte>>() {
                        Encoding.ASCII.GetBytes(Args[0].ToString() + '\0'),
                        Encoding.ASCII.GetBytes(Args[1].ToString() + '\0'),
                        Encoding.ASCII.GetBytes(Args[2].ToString() + '\0'),
                    };
                }
            case Function.GetSingleHeadOrSitewisePurchase:
            case Function.GetSinglePartyTransaction: {
                    return new List<ArraySegment<byte>>() {
                        new byte[1]{ (byte)Args[0] },
                        BitConverter.GetBytes((int)Args[1]),
                        BitConverter.GetBytes((int)Args[2]),
                        Encoding.ASCII.GetBytes(Args[3].ToString())
                    };
                }
            case Function.GetPurchaseSell:
            case Function.GetReceiptPayment:
            case Function.GetPayments: return new List<ArraySegment<byte>>() {
                Encoding.ASCII.GetBytes(Args[0].ToString() + '\0'),
                Encoding.ASCII.GetBytes(Args[1].ToString() + '\0'),
            };
            case Function.GetPurchases:  return new List<ArraySegment<byte>>() {
                new byte[1]{ (byte)Args[0] },
                Encoding.ASCII.GetBytes(Args[1].ToString() + '\0'),
                Encoding.ASCII.GetBytes(Args[2].ToString() + '\0'),
            };
            case Function.GetDetailPurchasePayable: return new List<ArraySegment<byte>>() {
                Encoding.ASCII.GetBytes(Args[0].ToString() + '\0'),
                Encoding.ASCII.GetBytes(Args[1].ToString() + '\0'),
                Encoding.ASCII.GetBytes(Args[2].ToString() + '\0'),
                new byte[1]{ (byte)Args[3] },
                BitConverter.GetBytes((int)Args[4])
            };

            case Function.AddSite:
            case Function.EditSite: return ((NetSite)Args[0]).GetBytes();
            case Function.AddParty:
            case Function.EditParty: return ((NetParty)Args[0]).GetBytes();
            case Function.AddHead:
            case Function.EditHead: return ((NetHead)Args[0]).GetBytes();
            case Function.AddSubHead:
            case Function.EditSubHead: return ((NetSubHead)Args[0]).GetBytes();
            case Function.AddUnit:
            case Function.EditUnit: return ((NetUnit)Args[0]).GetBytes();
            case Function.AddNoteType:
            case Function.EditNoteType: return ((NetNoteType)Args[0]).GetBytes();
            case Function.AddNote:
            case Function.EditNote: return ((NetNote)Args[0]).GetBytes();
            case Function.AddEntries: {
                    var entries = (List<NetEntryInsert>)Args[0];
                    var bytes = new List<ArraySegment<byte>>();
                    foreach (var e in entries) bytes.AddRange(e.GetBytes());
                    return bytes;
                }
            case Function.EditPurchaseSell: return ((NetPurchaseSell)Args[0]).GetBytes();
            case Function.EditReceiptPayment: return ((NetEntryReceiptPayment)Args[0]).GetBytes();
            case Function.DeletePurchaseSell: 
            case Function.DeleteReceiptPayment:
            case Function.DeleteNote: return new List<ArraySegment<byte>>() { BitConverter.GetBytes((int)Args[0]) };
            default: return new List<ArraySegment<byte>>();
        }
    }
    public static CDRMRequest FromBytes(byte[] array) {
        var span = new ReadOnlySpan<byte>(array);
        var user = BitConverter.ToInt32(span.Slice(0, 4));
        var method = BitConverter.ToInt32(span.Slice(4, 4));
        var args = getArgs(method, span.Slice(8, array.Length - 8));
        return new CDRMRequest() {
            UserId = user,
            Method = method,
            Args = args
        };
    }
    static object[] getArgs(int method, ReadOnlySpan<byte> bytes) {
        switch ((Function)method) {
            case Function.GetInitialData:
            case Function.GetDues:
            case Function.GetDates: return new object[] { "" };
            case Function.GetLedger: return new object[] { BitConverter.ToInt32(bytes) };
            case Function.GetPurchaseSellByDate:
            case Function.GetReceiptPaymentByDate: return new object[] { Encoding.ASCII.GetString(bytes) };
            case Function.GetAllHeadOrSitewisePurchase:
            case Function.GetAllPartyTransactions: {
                    int read, start, index;
                    start = read = index = 0;
                    var segments = new string[3];
                    while (read < bytes.Length) {
                        if (bytes[read] != 0) {
                            read++;
                            continue;
                        }
                        segments[index++] = Encoding.ASCII.GetString(bytes.Slice(start, read - start));
                        if (index == segments.Length) break;
                        start = ++read;
                    }
                    return segments;
                }
            case Function.GetSingleHeadOrSitewisePurchase:
            case Function.GetSinglePartyTransaction: {
                    return new object[] {
                        bytes.Slice(0, 1)[0],
                        BitConverter.ToInt32(bytes.Slice(1, 4)),
                        BitConverter.ToInt32(bytes.Slice(5, 4)),
                        Encoding.ASCII.GetString(bytes.Slice(9))
                    };

                }
            case Function.GetPurchaseSell:
            case Function.GetReceiptPayment:
            case Function.GetPayments: {
                    int read, start, index;
                    start = read = index = 0;
                    var segments = new string[2];
                    while (read < bytes.Length) {
                        if (bytes[read] != 0) {
                            read++;
                            continue;
                        }
                        segments[index++] = Encoding.ASCII.GetString(bytes.Slice(start, read - start));
                        if (index == segments.Length) break;
                        start = ++read;
                    }
                    return segments;
                }
            case Function.GetPurchases: {
                    int read, start, index;
                    start = read = 1;
                    index = 0;
                    var segments = new string[2];
                    while (read < bytes.Length) {
                        if (bytes[read] != 0) {
                            read++;
                            continue;
                        }
                        segments[index++] = Encoding.ASCII.GetString(bytes.Slice(start, read - start));
                        if (index == segments.Length) break;
                        start = ++read;
                    }
                    return new object[] {
                        bytes.Slice(0, 1)[0],
                        segments[0],
                        segments[1]
                    };
                }
            case Function.GetDetailPurchasePayable: {
                    int read, start, index;
                    start = read = index = 0;
                    var segments = new string[3];
                    while (read < bytes.Length) {
                        if (bytes[read] != 0) {
                            read++;
                            continue;
                        }
                        segments[index++] = Encoding.ASCII.GetString(bytes.Slice(start, read - start));
                        if (index == segments.Length) break;
                        start = ++read;
                    }
                    return new object[] {
                        segments[0],
                        segments[1],
                        segments[2],
                        bytes.Slice(read + 1, 1)[0],
                        BitConverter.ToInt32(bytes.Slice(read + 2))
                    };
                }

            case Function.AddSite:
            case Function.EditSite: return new object[] { NetSite.FromBytes(bytes) };
            case Function.AddParty:
            case Function.EditParty: return new object[] { NetParty.FromBytes(bytes) };
            case Function.AddHead:
            case Function.EditHead: return new object[] { NetHead.FromBytes(bytes) };
            case Function.AddSubHead:
            case Function.EditSubHead: return new object[] { NetSubHead.FromBytes(bytes) };
            case Function.AddUnit:
            case Function.EditUnit: return new object[] { NetUnit.FromBytes(bytes) };
            case Function.AddNoteType:
            case Function.EditNoteType: return new object[] { NetNoteType.FromBytes(bytes) };
            case Function.AddNote:
            case Function.EditNote: return new object[] { NetNote.FromBytes(bytes) };
            case Function.AddEntries: {
                    var entries = new List<NetEntryInsert>();
                    int read, start;
                    read = start = 0;
                    while (read < bytes.Length) {
                        var e = new NetEntryInsert() {
                            IsPS = BitConverter.ToBoolean(bytes.Slice(start)),
                            IsCash = bytes.Slice(start + 1, 1)[0],
                            IsSell = bytes.Slice(start + 2, 1)[0],
                            IsConstruction = bytes.Slice(start + 3, 1)[0],
                            IsReceipt = bytes.Slice(start + 4, 1)[0],
                            Amount = BitConverter.ToInt32(bytes.Slice(start + 5)),
                            SiteId = BitConverter.ToInt32(bytes.Slice(start + 9)),
                            PartyId = BitConverter.ToInt32(bytes.Slice(start + 13)),
                            HeadId = BitConverter.ToInt32(bytes.Slice(start + 17)),
                            SubHeadId = BitConverter.ToInt32(bytes.Slice(start + 21)),
                            UnitId = BitConverter.ToInt32(bytes.Slice(start + 25)),
                            Quantity = BitConverter.ToDouble(bytes.Slice(start + 29)),
                        };
                        read += 37;
                        start = read;
                        while (bytes[read] != 0) read++;
                        e.Date = Encoding.ASCII.GetString(bytes.Slice(start, read - start));
                        start = ++read;
                        while (bytes[read] != 0) read++;
                        e.Narration = Encoding.ASCII.GetString(bytes.Slice(start, read - start));
                        entries.Add(e);
                        start = ++read;
                    }
                    return new object[] { entries };
                }
            case Function.EditPurchaseSell: return new object[] { NetPurchaseSell.FromBytes(bytes) };
            case Function.EditReceiptPayment: return new object[] { NetEntryReceiptPayment.FromBytes(bytes) };
            case Function.DeletePurchaseSell:
            case Function.DeleteReceiptPayment:  
            case Function.DeleteNote: return new object[] { BitConverter.ToInt32(bytes) };
            default: return new object[0];
        }
    }
}
