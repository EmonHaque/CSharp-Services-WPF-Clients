﻿public class NetHead
{
    public int Id { get; set; }
    public string Name { get; set; }

    public List<ArraySegment<byte>> GetBytes() {
        return new List<ArraySegment<byte>>() {
            BitConverter.GetBytes(Id),
            Encoding.ASCII.GetBytes(Name + '\0')
        };
    }
    public static NetHead FromBytes(ReadOnlySpan<byte> array) {
        return new NetHead() {
            Id = BitConverter.ToInt32(array.Slice(0, 4)),
            Name = Encoding.ASCII.GetString(array.Slice(4, array.Length - 5))
        };
    }
}
