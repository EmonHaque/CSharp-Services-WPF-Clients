﻿public class NetSumTransaction
{
    public int PartyId { get; set; }  
    public int PurchaseReceipt { get; set; }
    public int SellPayment { get; set; }
    public string Head { get; set; }

    public List<ArraySegment<byte>> GetBytes() {
        return new List<ArraySegment<byte>>() {
            BitConverter.GetBytes(PartyId),
            BitConverter.GetBytes(PurchaseReceipt),
            BitConverter.GetBytes(SellPayment),
            Encoding.ASCII.GetBytes(Head + '\0')
        };
    }
}
