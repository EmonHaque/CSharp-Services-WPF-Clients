﻿public class NetEntryNoteText
{
    public int Id { get; set; }
    public string Date { get; set; }
    public string NoteType { get; set; }
    public string Site { get; set; }
    public string Entry { get; set; }

    public List<ArraySegment<byte>> GetBytes() {
        return new List<ArraySegment<byte>>() {
            BitConverter.GetBytes(Id),
            Encoding.ASCII.GetBytes(Date + '\0'),
            Encoding.ASCII.GetBytes(NoteType + '\0'),
            Encoding.ASCII.GetBytes(Site + '\0'),
            Encoding.ASCII.GetBytes(Entry + '\0')
        };
    }
}
