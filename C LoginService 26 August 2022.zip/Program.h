#include <ws2tcpip.h>
#include <tchar.h>
#include "Messenger.h"
#include "Database.h"

extern wchar_t SERVICE_NAME[10];
extern SERVICE_STATUS g_ServiceStatus;
extern SERVICE_STATUS_HANDLE g_StatusHandle;
extern HANDLE g_ServiceStopEvent;

extern SOCKET server;
extern byte isRunning;
extern List clients, onlines;
extern BlockingQueue attempts, logouts;
extern CRITICAL_SECTION criticalClient;
extern HANDLE serviceThread, acceptClientThread;

void ServiceMain(ulong, ulong*);
void ServiceCtrlHandler(ulong);
ulong ServiceWorker(void*);
ulong HandleAttempt(void*);

void OnStarting();
void Initialize();
void OnStarted();
void AcceptClient();
void Cleanup();
void OnStopping();
void onStopped();