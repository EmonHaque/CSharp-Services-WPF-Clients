#define _CRT_SECURE_NO_WARNINGS
#include "Database.h"

#pragma region variables
CRITICAL_SECTION criticalDatabase;
HANDLE addAttemptThread, updateLogoutThread;
List apps, logins, addresses;
BlockingQueue attempts, logouts;
sqlite3* connection;
sqlite3_stmt* command;
int maxAttemptId;
time_t currentTime;
struct tm tmStruct;
#pragma endregion

void initializeDatabase() {
	char* database = "C:/Users/Emon/Desktop/Logins.db";
	sqlite3_open(database, &connection);
	InitializeCriticalSection(&criticalDatabase);

	attempts.count = logouts.count = 0;
	attempts.capacity = logouts.capacity = 5;

	attempts.data = malloc(attempts.capacity * POINTER_SIZE);
	attempts.manualResetEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	InitializeCriticalSection(&attempts.section);
	logouts.data = malloc(logouts.capacity * POINTER_SIZE);
	logouts.manualResetEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	InitializeCriticalSection(&logouts.section);

	logins.count = apps.count = addresses.count = 0;
	logins.capacity = apps.capacity = addresses.capacity = 5;
	
	logins.data = malloc(5 * POINTER_SIZE);
	apps.data = malloc(5 * POINTER_SIZE);
	addresses.data = malloc(5 * POINTER_SIZE);

	addAttemptThread = CreateThread(NULL, 0, addAttempt, 0, 0, NULL);
	updateLogoutThread = CreateThread(NULL, 0, updateLogout, 0, 0, NULL);

	char* tail, * sql =
		"SELECT * FROM Logins; "
		"SELECT * FROM Apps; "
		"SELECT * From Addresses; "
		"SELECT MAX(Id) FROM Attempts";

	sqlite3_prepare_v2(connection, sql, -1, &command, &tail);
	while (sqlite3_step(command) == SQLITE_ROW) {
		Login* log = malloc(LOGIN_SIZE);
		log->id = sqlite3_column_int(command, 0);
		mallocate(sqlite3_column_text(command, 1), &log->name);
		mallocate(sqlite3_column_text(command, 2), &log->userName);
		mallocate(sqlite3_column_text(command, 3), &log->password);
		log->role = sqlite3_column_int(command, 4);
		log->isActive = sqlite3_column_int(command, 5);
		addToList(&logins, log);
	}
	sqlite3_finalize(command);

	sqlite3_prepare_v2(connection, tail, -1, &command, &tail);
	while (sqlite3_step(command) == SQLITE_ROW) {
		App* app = malloc(APP_SIZE);
		app->id = sqlite3_column_int(command, 0);
		mallocate(sqlite3_column_text(command, 1), &app->name);
		addToList(&apps, app);
	}
	sqlite3_finalize(command);

	sqlite3_prepare_v2(connection, tail, -1, &command, &tail);
	while (sqlite3_step(command) == SQLITE_ROW) {
		Address* add = malloc(ADDRESS_SIZE);
		add->id = sqlite3_column_int(command, 0);
		mallocate(sqlite3_column_text(command, 1), &add->IP);
		addToList(&addresses, add);
	}
	sqlite3_finalize(command);

	sqlite3_prepare_v2(connection, tail, -1, &command, &tail);
	sqlite3_step(command);
	maxAttemptId = sqlite3_column_type(command, 0) == SQLITE_NULL ? 0
		: sqlite3_column_int(command, 0);
	sqlite3_finalize(command);
}
ulong addAttempt(void* p) {
	char* sql = "INSERT INTO Attempts(UserId, AppId, AddressId, Port, UserName, Password, DateIn, TimeIn, IsSucccess) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)";
	while (isRunning) {
		Attempt* attempt = takeOutFrom(&attempts);
		EnterCriticalSection(&criticalDatabase);
		sqlite3_prepare_v2(connection, sql, -1, &command, 0);
		sqlite3_bind_int(command, 1, attempt->userId);
		sqlite3_bind_int(command, 2, attempt->appId);
		sqlite3_bind_int(command, 3, attempt->addressId);
		sqlite3_bind_int(command, 4, attempt->port);
		sqlite3_bind_text(command, 7, attempt->dateIn, -1, SQLITE_STATIC);
		sqlite3_bind_text(command, 8, attempt->timeIn, -1, SQLITE_STATIC);
		sqlite3_bind_int(command, 9, attempt->isSuccess);
		if (attempt->isSuccess) {
			sqlite3_bind_null(command, 5);
			sqlite3_bind_null(command, 6);
		}
		else {
			sqlite3_bind_text(command, 5, attempt->userName, -1, SQLITE_STATIC);
			sqlite3_bind_text(command, 6, attempt->password, -1, SQLITE_STATIC);
		}
		sqlite3_step(command);
		sqlite3_finalize(command);
		LeaveCriticalSection(&criticalDatabase);

		free(attempt->timeIn);
		free(attempt->dateIn);
		free(attempt);
	}
}
ulong updateLogout(void* p) {
	char* sql = "UPDATE Attempts SET DateOut = ?, TimeOut = ? WHERE Id = ?";
	while (isRunning) {
		Online* online = takeOutFrom(&logouts);
		EnterCriticalSection(&criticalDatabase);
		sqlite3_prepare_v2(connection, sql, -1, &command, 0);
		sqlite3_bind_text(command, 1, online->dateOut, -1, SQLITE_STATIC);
		sqlite3_bind_text(command, 2, online->timeOut, -1, SQLITE_STATIC);
		sqlite3_bind_int(command, 3, online->Id);
		sqlite3_step(command);
		sqlite3_finalize(command);
		LeaveCriticalSection(&criticalDatabase);

		free(online->dateIn);
		free(online->dateOut);
		free(online->timeIn);
		free(online->timeOut);
		free(online);
	}
}
int mallocate(char* src, char** dst) {
	int length = strlen(src) + 1;
	*dst = malloc(length);
	memcpy(*dst, src, length - 1);
	(*dst)[length - 1] = 0;
	return length;
}
char* getTime() {
	currentTime = time(0);
	localtime_s(&tmStruct, &currentTime);

	char* timeBuff = malloc(9);
	//char timeBuff[9];
	char hour[3], min[3], sec[3];
	if (tmStruct.tm_hour < 10) sprintf(hour, "0%d", tmStruct.tm_hour);
	else sprintf(hour, "%d", tmStruct.tm_hour);
	if (tmStruct.tm_min < 9) sprintf(min, "0%d", tmStruct.tm_min + 1);
	else sprintf(min, "%d", tmStruct.tm_min + 1);
	if (tmStruct.tm_sec < 9) sprintf(sec, "0%d", tmStruct.tm_sec + 1);
	else sprintf(sec, "%d", tmStruct.tm_sec + 1);

	sprintf(timeBuff, "%s:%s:%s", hour, min, sec);
	return timeBuff;
}
char* getDate() {
	//char date[11];
	char* date = malloc(11);
	char mon[3], day[3];
	if (tmStruct.tm_mon < 9) sprintf(mon, "0%d", tmStruct.tm_mon + 1);
	else sprintf(mon, "%d", tmStruct.tm_mon + 1);
	if (tmStruct.tm_mday < 10) sprintf(day, "0%d", tmStruct.tm_mday);
	else sprintf(day, "%d", tmStruct.tm_mday);

	sprintf(date, "%d:%s:%s", tmStruct.tm_year + 1900, mon, day);
	return date;
}
Login* getLogin(char* user, char* pass) {
	Login** loginList = logins.data;
	Login* login = { 0 };
	for (int i = 0; i < logins.count; i++) {
		if (strcmp(loginList[i]->userName, user) == 0
			&& strcmp(loginList[i]->password, pass) == 0) {
			login = loginList[i];
			break;
		}
	}
	return login;
}
int getAppId(char* appName) {
	App** appList = apps.data;
	int id = 0;
	for (int i = 0; i < apps.count; i++) {
		if (strcmp(appList[i]->name, appName) == 0) {
			id = appList[i]->id;
			break;
		}
	}
	if (!id) {
		App* newApp = malloc(APP_SIZE);
		newApp->id = apps.count + 1;
		mallocate(appName, &newApp->name);

		EnterCriticalSection(&criticalDatabase);
		char* sql = "INSERT INTO Apps(Name) VALUES(?)";
		sqlite3_prepare_v2(connection, sql, -1, &command, 0);
		sqlite3_bind_text(command, 1, newApp->name, -1, SQLITE_STATIC);
		int result = sqlite3_step(command);
		sqlite3_finalize(command);
		LeaveCriticalSection(&criticalDatabase);

		if (result == SQLITE_DONE) {
			addToList(&apps, newApp);
			id = newApp->id;
		}
		else {
			free(newApp->name);
			free(newApp);
		}
	}
	return id;
}
int getAddressId(char* ip4) {
	Address** addressList = addresses.data;
	int id;
	for (int i = 0; i < addresses.count; i++) {
		if (strcmp(addressList[i]->IP, ip4) == 0) {
			id = addressList[i]->id;
			break;
		}
	}
	if (!id) {
		Address* newAddress = malloc(ADDRESS_SIZE);
		newAddress->id = addresses.count + 1;
		mallocate(ip4, &newAddress->IP);

		EnterCriticalSection(&criticalDatabase);
		char* sql = "INSERT INTO Addresses(IP) VALUES(?)";
		sqlite3_prepare_v2(connection, sql, -1, &command, 0);
		sqlite3_bind_text(command, 1, newAddress->IP, -1, SQLITE_STATIC);
		int result = sqlite3_step(command);
		sqlite3_finalize(command);
		LeaveCriticalSection(&criticalDatabase);

		if (result == SQLITE_DONE) {
			addToList(&addresses, newAddress);
			id = newAddress->id;
		}
		else {
			free(newAddress->IP);
			free(newAddress);
		}
	}
	return id;
}
Client* getClient(SOCKET s) {
	Client** clientList = clients.data;
	Client* client = 0;
	for (int i = 0; i < clients.count; i++) {
		if (clientList[i]->socket == s) {
			client = clientList[i];
			break;
		}
	}
	return client;
}