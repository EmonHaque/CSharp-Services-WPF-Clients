#pragma once
#include <time.h>
#include <stdio.h>
#include "List.h"
#include "BlockingQueue.h"
#include "Structures.h"
#include "sqlite3.h"

extern List clients, apps, logins, addresses;
extern BlockingQueue attempts, logouts;
extern sqlite3* connection;
extern sqlite3_stmt* command;
extern int maxAttemptId;
extern byte isRunning;
extern CRITICAL_SECTION criticalDatabase;
extern HANDLE addAttemptThread, updateLogoutThread;
extern time_t currentTime;
extern struct tm tmStruct;

void initializeDatabase();
ulong addAttempt(void*);
ulong updateLogout(void*);
int mallocate(char*, char**);
Login* getLogin(char*, char*);
int getAppId(char*);
int getAddressId(char*);
Client* getClient(SOCKET);
char* getTime();
char* getDate();
