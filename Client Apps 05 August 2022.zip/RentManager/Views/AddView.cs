﻿class AddView : View
{
    override public string Icon => Icons.Add;
    public override FrameworkElement container => grid;
    Grid grid;
    public AddView() {
        var plot = new AddPlot();
        var space = new AddSpace();
        var tenant = new AddTenant();
        var head = new AddHead();
        var lease = new AddLease();
        Grid.SetColumn(space, 1);
        Grid.SetColumn(lease, 2);
        Grid.SetRowSpan(lease, 2);
        Grid.SetRow(tenant, 1);
        Grid.SetRow(head, 1);
        Grid.SetColumn(head, 1);
        grid = new Grid() {
            RowDefinitions = {
                    new RowDefinition(),
                    new RowDefinition()
                },
            ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(),
                    new ColumnDefinition()
                },
            Children = { plot, space, lease, tenant, head }
        };
        AddVisualChild(grid);
    }
}
