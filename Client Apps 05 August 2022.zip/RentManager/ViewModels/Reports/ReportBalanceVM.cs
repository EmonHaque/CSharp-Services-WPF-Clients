﻿class ReportBalanceVM : Notifiable
{
    List<Balance> summary;
    public ICollectionView Plots { get; set; }
    public ICollectionView Balances { get; set; }
    public Tuple<int, int, int> Totals { get; set; }
    public bool IsPrintOrExportValid { get; set; }
    public bool IsRefreshValid { get; set; }
    public Action Refresh { get; set; }
    public Action PrintReport { get; set; }
    public Action ExportCSV { get; set; }
    public string ErrorPlotId { get; set; }
    bool hasLeft;
    public bool HasLeft {
        get { return hasLeft; }
        set {
            if (hasLeft != value) {
                hasLeft = value;
                getData();
            }
        }
    }
    int? plotId;
    public int? PlotId {
        get { return plotId; }
        set {
            if (plotId != value) {
                plotId = value;
                validate();
                IsRefreshValid = value == null ? false : true;
                OnPropertyChanged(nameof(IsRefreshValid));
            }
        }
    }
    string plotQuery;
    public string PlotQuery {
        get { return plotQuery; }
        set {
            if (plotQuery != value) {
                plotQuery = value?.Trim().ToLower();
                Plots.Refresh();
            }
        }
    }
    string tenantQuery;
    public string TenantQuery {
        get { return tenantQuery; }
        set {
            if (tenantQuery != value) {
                tenantQuery = value?.Trim().ToLower();
                Balances.Refresh();
            }
        }
    }
    string status;
    public string Status {
        get { return status; }
        set { status = value; OnPropertyChanged(nameof(Status)); }
    }

    public ReportBalanceVM() {
        Refresh = refresh;
        PrintReport = printReport;
        ExportCSV = exportCSV;
        Plots = new CollectionViewSource() { Source = AppData.plots }.View;
        Plots.Filter = filterPlots;
    }

    bool filterPlots(object o) {
        if (string.IsNullOrWhiteSpace(PlotQuery)) return true;
        return ((Plot)o).Name.ToLower().Contains(PlotQuery);
    }
    bool filterTenants(object o) {
        if (string.IsNullOrWhiteSpace(TenantQuery)) return true;
        return ((Balance)o).Tenant.ToLower().Contains(TenantQuery);
    }
    void validate() {
        ErrorPlotId = string.Empty;
        if (PlotId == null) {
            ErrorPlotId = " is required";
            summary = null;
            Balances = null;
            Totals = new Tuple<int, int, int>(0, 0, 0);
            IsPrintOrExportValid = false;
            OnPropertyChanged(nameof(Balances));
            OnPropertyChanged(nameof(Totals));
            OnPropertyChanged(nameof(IsPrintOrExportValid));
        }
        else getData();
        OnPropertyChanged(nameof(ErrorPlotId));
    }

    #region Command
    void refresh() {
        //BusyWindow.Activate(ReportBalance.Left, ReportBalance.Top, ReportBalance.Width, ReportBalance.Height, "Printing ...");
        getData();
        //BusyWindow.Terminate();
    }
    void printReport() {
        var dialog = new PrintDialog();
        if (dialog.ShowDialog() != true) return;
        BusyWindow.Activate(ReportBalance.Left, ReportBalance.Top, ReportBalance.Width, ReportBalance.Height, "Printing ...");
        var size = new Size(dialog.PrintableAreaWidth, dialog.PrintableAreaHeight);
        var document = new FixedDocument();
        document.DocumentPaginator.PageSize = size;

        List<object> list = new();
        int totalSecurity, totalRent, totalDue, index;
        totalSecurity = totalRent = totalDue = 0;
        for (int i = 0; i < summary.Count; i += index) {
            int sumSecurity, sumRent, sumDue;
            sumSecurity = sumRent = sumDue = 0;
            var indexIncrement = summary[i].Count;
            if (summary[i].Count > 1) {
                #region include all entries even if there's no outstanding for expired lease
                //list.Add(summary[i].Tenant);
                //for (int j = i; j < i + summary[i].Count; j++) {
                //    list.Add(summary[j]);
                //    sumSecurity += summary[j].Security;
                //    sumRent += summary[j].Rent;
                //    sumDue += summary[j].Due;
                //}
                //list.Add(new Tuple<int, int, int>(sumSecurity, sumRent, sumDue));
                //totalSecurity += sumSecurity;
                //totalRent += sumRent;
                //totalDue += sumDue;
                #endregion

                #region eliminate entries where there's no outstanding for expired lease
                var internalList = new List<Balance>();
                for (int j = i; j < i + summary[i].Count; j++) {
                    if (!summary[j].IsExpired) internalList.Add(summary[j]);
                    else if (summary[j].Security != summary[j].Due)
                        internalList.Add(summary[j]);
                }
                if (internalList.Count > 1) {
                    list.Add(summary[i].Tenant);
                    foreach (var item in internalList) {
                        list.Add(item);
                        sumSecurity += item.Security;
                        sumRent += item.Rent;
                        sumDue += item.Due;
                    }
                    list.Add(new Tuple<int, int, int>(sumSecurity, sumRent, sumDue));
                    totalSecurity += sumSecurity;
                    totalRent += sumRent;
                    totalDue += sumDue;
                }
                else {
                    var item = internalList.First();
                    item.Count = 1;
                    list.Add(item);
                    totalSecurity += item.Security;
                    totalRent += item.Rent;
                    totalDue += item.Due;
                }
                #endregion
            }
            else {
                list.Add(summary[i]);
                totalSecurity += summary[i].Security;
                totalRent += summary[i].Rent;
                totalDue += summary[i].Due;
            }
            index = indexIncrement;
        }
        var pages = new List<BalancePage>();
        var page = getPage(document, null);
        pages.Add(page);
        for (int i = 0; i < list.Count; i++) {
            if (!page.AddEntry(list[i])) {
                page.IsComplete = true;
                page = getPage(document, page);
                page.AddEntry(list[i]);
                pages.Add(page);
            }
        }
        page.IsComplete = true;
        foreach (var p in pages) {
            p.NumberOfPage = document.Pages.Count;
        }
        dialog.PrintDocument(document.DocumentPaginator, "");
        BusyWindow.Terminate();
    }
    void exportCSV() {
        var dialog = new SaveFileDialog() {
            FileName = "Balance",
            Filter = "CSV files (.csv)|*.csv"
        };
        if (dialog.ShowDialog() != true) return;
        BusyWindow.Activate(ReportBalance.Left, ReportBalance.Top, ReportBalance.Width, ReportBalance.Height, "Printing ...");

        var builder = new StringBuilder();
        builder.Append("Name and Space, Date, Security, Rent, Due").AppendLine();
        foreach (var item in summary) {
            var nameAndSpace = item.Count > 1 ? item.Tenant + " - " + item.Space : item.Space;
            builder
                .Append("\"").Append(nameAndSpace).Append("\"").Append(",")
                .Append(item.DateStart).Append(",")
                .Append(item.Security).Append(",")
                .Append(item.Rent).Append(",")
                .Append(item.Due).AppendLine();
        }
        System.IO.File.WriteAllText(System.IO.Path.GetFullPath(dialog.FileName), builder.ToString());
        BusyWindow.Terminate();
    }
    BalancePage getPage(FixedDocument doc, BalancePage previousPage) {
        BalancePage page;
        if (previousPage == null) {
            var plot = AppData.plots.First(x => x.Id == PlotId);
            var date = DateTime.Now;
            page = new BalancePage(doc.DocumentPaginator.PageSize) {
                Title = plot.Name,
                SubTitle = plot.Description,
                AsAt = "as at " + date.ToString("dd MMMM yyyy"),
                FootNote = $"Generated on {date.ToString("dd MMMM, yyyy | hh:mm:ss tt")}",
            };
        }
        else page = new BalancePage(previousPage);
        doc.Pages.Add(new PageContent() { Child = page.Page });
        return page;
    }
    #endregion

    async void getData() {
        Status = "requesting data";
        var request = new RentManagerRequest() {
            UserId = App.service.UserId,
            Method = (int)Function.GetBalance,
            Args = new object[] { PlotId, Convert.ToInt32(HasLeft) }
        };
        var response = await App.service.GetResponse(request);
        await Task.Delay(500);
        if (!response.IsSuccess) {
            return;
        }

        Status = $"received {response.Packet.Length.ToString("N0")} bytes";
        await Task.Delay(500);
        summary = await getEntries(response.Packet);

        Balances = new CollectionViewSource() {
            Source = summary,
            GroupDescriptions = {
                new PropertyGroupDescription(nameof(Balance.Tenant))
            }
        }.View;
        Balances.Filter = filterTenants;
        int totalSecurity, totalRent, totalDue;
        totalSecurity = totalRent = totalDue = 0;
        for (int i = 0; i < summary.Count; i++) {
            totalSecurity += summary[i].Security;
            totalRent += summary[i].Rent;
            totalDue += summary[i].Due;
        }
        Totals = new Tuple<int, int, int>(totalSecurity, totalRent, totalDue);
        IsPrintOrExportValid = summary.Count > 0;

        OnPropertyChanged(nameof(Balances));
        OnPropertyChanged(nameof(Totals));
        OnPropertyChanged(nameof(IsPrintOrExportValid));
    }

    Task<List<Balance>> getEntries(byte[] packet) {
        summary = new List<Balance>();
        var span = new ReadOnlySpan<byte>(packet);
        int read = 0;
        while (read < span.Length) {
            var size = BitConverter.ToInt32(span.Slice(read, 4));
            read += 4;
            var e = NetBalance.FromBytes(span.Slice(read, size));
            read += size;

            summary.Add(new Balance() {
                Tenant = e.Tenant,
                Space = e.Space,
                DateStart = e.DateStart,
                DateEnd = e.DateEnd,
                Security = e.Security,
                Rent = e.Rent,
                Due = e.Due,
                IsExpired = e.IsExpired,
                Count = e.Count
            });
        }
        return Task.FromResult(summary);
    }
}
