﻿abstract class EditBase<T> : Notifiable where T : Notifiable, new()
{
    bool isOnEdit;
    public bool IsOnEdit {
        get { return isOnEdit; }
        set { isOnEdit = value; OnPropertyChanged(nameof(IsOnEdit)); }
    }
    T selected;
    public T Selected {
        get { return selected; }
        set {
            selected = value;
            OnPropertyChanged(nameof(Selected));
            if (IsOnEdit) resetIsOnEdit();
        }
    }
    T edited;
    public T Edited {
        get { return edited; }
        set { edited = value; OnPropertyChanged(nameof(Edited)); }
    }
    public ICollectionView Editables { get; set; }
    public Action SetIsOnEdit { get; set; }
    public Action ResetIsOnEdit { get; set; }
    public Action Save { get; set; }

    public EditBase() {
        SetIsOnEdit = setOnEdit;
        ResetIsOnEdit = resetIsOnEdit;
        Save = saveAndUpdate;
    }
    
    protected abstract T clone();
    protected abstract void validate(object sender, PropertyChangedEventArgs e);
    protected abstract void setValidationProperties();
    protected abstract void save();
    protected virtual void setStatesOnClone() { }
    void setOnEdit() {
        if (Selected != null) {
            Edited = clone();
            setStatesOnClone();
            setValidationProperties();
            Edited.PropertyChanged += validate;
            IsOnEdit = true;
        }
    }
    protected void resetIsOnEdit() {
        Edited.PropertyChanged -= validate;
        setValidationProperties();
        IsOnEdit = false;
    }
    void saveAndUpdate() {
        save();
        resetIsOnEdit();
    }
}
