IHost host = Host.CreateDefaultBuilder(args)
    .UseWindowsService()
    .ConfigureServices(services =>
    {
        services.AddHostedService<LaunchWorker>();
    })
    .Build();

await host.RunAsync();
