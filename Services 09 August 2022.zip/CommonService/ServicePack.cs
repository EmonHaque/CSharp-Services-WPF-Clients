﻿public class ServicePack
{
    public Socket Signatory { get; set; } // for connecting to login service
    public Socket Receiver { get; set; } // for receiving initial data and broadcast
    public Socket Sender { get; set; } // for request and response
    public IPAddress Address { get; set; }
    public int Port { get; set; }
    public Role Role { get; set; }
    public int UserId { get; set; }

    public Task<Response> GetResponse(Request request /*, IProgress<string> message*/) {
        /* IProgress<string> doesn't update UI without await
         * if you make it async, you've to use SemaphoreSlim and call WaitAsync at the beginning and Release in the finally block
         * because in Balances of ReportView, there're two View and both call Send and Receive
         * in these half duplex Sockets you cannot Send/Receive simultaneously, you've to Ping Pong */
        try {
            Sender.Send(request.GetBytes());
            var header = new byte[4];
            int read = Sender.Receive(header);
            while (read < header.Length) {
                read += Sender.Receive(header, read, header.Length - read, SocketFlags.None);
            }
            var size = BitConverter.ToInt32(header);
            if (size == 0) return Task.FromResult(new Response(true, new byte[0]));
            
            var packet = new byte[size];
            read = Sender.Receive(packet);
            while (read < packet.Length) {
                read += Sender.Receive(packet, read, packet.Length - read, SocketFlags.None);
            }
            return Task.FromResult(new Response(true, packet));
        }
        catch {
            return Task.FromResult(new Response(false, new byte[0])); 
        }
    }
}
    