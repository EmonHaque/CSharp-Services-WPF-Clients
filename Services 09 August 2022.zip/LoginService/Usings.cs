﻿global using System;
global using System.Net;
global using System.Text;
global using System.Net.Sockets;
global using Microsoft.Data.Sqlite;
global using System.Collections.Concurrent;