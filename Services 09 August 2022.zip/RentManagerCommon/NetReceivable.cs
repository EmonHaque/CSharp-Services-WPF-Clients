﻿public class NetReceivable
{
    public int LeaseId { get; set; }
    public int HeadId { get; set; }
    public int Amount { get; set; }

    public List<ArraySegment<byte>> GetBytes() {
        return new List<ArraySegment<byte>>() {
            BitConverter.GetBytes(LeaseId),
            BitConverter.GetBytes(HeadId),
            BitConverter.GetBytes(Amount)
        };
    }
    public static NetReceivable FromBytes(ReadOnlySpan<byte> bytes) {
        return new NetReceivable() {
            LeaseId = BitConverter.ToInt32(bytes.Slice(0, 4)),
            HeadId = BitConverter.ToInt32(bytes.Slice(4, 4)),
            Amount = BitConverter.ToInt32(bytes.Slice(8, 4)),
        };
    }
}
