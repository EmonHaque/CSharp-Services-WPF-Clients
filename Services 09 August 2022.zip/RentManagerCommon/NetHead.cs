﻿public class NetHead
{
    public int Id { get; set; }
    public int ControlId { get; set; }
    public string Name { get; set; }
    public string Description { get; set; }

    public List<ArraySegment<byte>> GetBytes() {
        return new List<ArraySegment<byte>>() {
            BitConverter.GetBytes(Id),
            BitConverter.GetBytes(ControlId),
            Encoding.ASCII.GetBytes(Name + '\0'),
            Encoding.ASCII.GetBytes(Description + '\0')
        };
    }
    public static NetHead FromBytes(ReadOnlySpan<byte> array) {
        int read = 0;
        int start = 0;
        int id = BitConverter.ToInt32(array.Slice(start, 4));
        int controlId = BitConverter.ToInt32(array.Slice(start + 4, 4));
        read += 8;
        start = read;
        while (array[read] != 0) read++;
        var name = Encoding.ASCII.GetString(array.Slice(start, read - start));

        start = ++read;
        while (array[read] != 0) read++;
        var description = Encoding.ASCII.GetString(array.Slice(start, read - start));

        return new NetHead() {
            Id = id,
            ControlId = controlId,
            Name = name,
            Description = description
        };
    }
}
