﻿public class NetPlotWiseRent
{
    public string Plot { get; set; }
    public string Tenant { get; set; }
    public string Month { get; set; }
    public int Rent { get; set; }
    public int Cash { get; set; }
    public int Mobile { get; set; }
    public int Kind { get; set; }
    public int Total { get; set; }
    public int PlotId { get; set; }

    public List<ArraySegment<byte>> GetBytes() {
        return new List<ArraySegment<byte>>() {
            Encoding.ASCII.GetBytes(Plot + '\0'),
            Encoding.ASCII.GetBytes(Tenant + '\0'),
            Encoding.ASCII.GetBytes(Month + '\0'),
            BitConverter.GetBytes(Rent),
            BitConverter.GetBytes(Cash),
            BitConverter.GetBytes(Mobile),
            BitConverter.GetBytes(Kind),
            BitConverter.GetBytes(Total),
            BitConverter.GetBytes(PlotId)
        };
    }
}
