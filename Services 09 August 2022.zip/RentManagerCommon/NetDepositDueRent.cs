﻿public class NetDepositDueRent
{
    public byte State { get; set; }
    public int PlotId { get; set; }
    public int SpaceId { get; set; }
    public int TenantId { get; set; }
    public int Amount { get; set; }

    public List<ArraySegment<byte>> GetBytes() {
        return new List<ArraySegment<byte>>() {
            new byte[1]{ State },
            BitConverter.GetBytes(PlotId),
            BitConverter.GetBytes(SpaceId),
            BitConverter.GetBytes(TenantId),
            BitConverter.GetBytes(Amount)
        };
    }
}
