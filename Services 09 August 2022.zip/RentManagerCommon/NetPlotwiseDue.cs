﻿public class NetPlotWiseDue
{
    public string Month { get; set; }
    public string Tenant { get; set; }
    public int Due { get; set; }

    public List<ArraySegment<byte>> GetBytes() {
        return new List<ArraySegment<byte>>() {
            Encoding.ASCII.GetBytes(Month + "\0"),
            Encoding.ASCII.GetBytes(Tenant + "\0"),
            BitConverter.GetBytes(Due)
        };
    }
}
