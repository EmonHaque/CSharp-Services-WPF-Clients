﻿class Database
{
    public struct Totals
    {
        public int plot;
        public int space;
        public int tenants;
        public int controlHeads;
        public int heads;
        public int leases;
        public int receivables;
    }
    const string location = @"data source = C:\Users\Emon\Desktop\data.db";
    SqliteCommand command;
    SqliteConnection connection = new(location);

    List<NetPlot> plots = new();
    List<NetSpace> spaces = new();
    List<NetTenant> tenants = new();
    List<NetControlHead> controlHeads = new();
    List<NetHead> heads = new();
    List<NetLease> leases = new();
    List<NetReceivable> receivables = new();

    public Totals sizes = new();
    public Dictionary<int, List<ArraySegment<byte>>> plotBytes = new();
    public Dictionary<int, List<ArraySegment<byte>>> spaceBytes = new();
    public Dictionary<int, List<ArraySegment<byte>>> tenantBytes = new();
    public Dictionary<int, List<ArraySegment<byte>>> controlHeadBytes = new();
    public Dictionary<int, List<ArraySegment<byte>>> headBytes = new();
    public Dictionary<int, List<ArraySegment<byte>>> leaseBytes = new();
    public List<KeyValuePair<int, List<ArraySegment<byte>>>> receivableBytes = new();

    BlockingCollection<List<ArraySegment<byte>>> broadcasts;
    BlockingCollection<QueuedResponse> responses;

    public Database(BlockingCollection<List<ArraySegment<byte>>> broadcasts, BlockingCollection<QueuedResponse> responses) {
        this.broadcasts = broadcasts;
        this.responses = responses;
        connection.Open();
        command = connection.CreateCommand();
        populateLists();
        populateDisctionaries();
    }

    void populateLists() {
        command.CommandText = @"SELECT * FROM Plots;
                                    SELECT * FROM Spaces;
                                    SELECT Id, Name, Father, coalesce(Mother, ''), coalesce(Husband, ''), Address, coalesce(NID, ''), ContactNo, HasLeft FROM Tenants;
                                    SELECT Id, PlotId, SpaceId, TenantId, DateStart, coalesce(DateEnd, ''), Business, IsExpired FROM Leases;
                                    SELECT * FROM Receivables;
                                    SELECT * FROM ControlHeads;
                                    SELECT * FROM Heads";
        var reader = command.ExecuteReader();
        while (reader.Read()) {
            plots.Add(new NetPlot() {
                Id = reader.GetInt32(0),
                Name = reader.GetString(1),
                Description = reader.GetString(2)
            });
        }
        reader.NextResult();
        while (reader.Read()) {
            spaces.Add(new NetSpace() {
                Id = reader.GetInt32(0),
                PlotId = reader.GetInt32(1),
                Name = reader.GetString(2),
                Description = reader.GetString(3),
                IsVacant = reader.GetBoolean(4)
            });
        }
        reader.NextResult();
        while (reader.Read()) {
            tenants.Add(new NetTenant() {
                Id = reader.GetInt32(0),
                Name = reader.GetString(1),
                Father = reader.GetString(2),
                Mother = reader.GetString(3),
                Husband = reader.GetString(4),
                Address = reader.GetString(5),
                NID = reader.GetString(6),
                ContactNo = reader.GetString(7),
                HasLeft = reader.GetBoolean(8)
            });
        }
        reader.NextResult();
        while (reader.Read()) {
            leases.Add(new NetLease() {
                Id = reader.GetInt32(0),
                PlotId = reader.GetInt32(1),
                SpaceId = reader.GetInt32(2),
                TenantId = reader.GetInt32(3),
                DateStart = reader.GetString(4),
                DateEnd = reader.GetString(5),
                Business = reader.GetString(6),
                IsExpired = reader.GetBoolean(7)
            });
        }
        reader.NextResult();
        while (reader.Read()) {
            receivables.Add(new NetReceivable() {
                LeaseId = reader.GetInt32(0),
                HeadId = reader.GetInt32(1),
                Amount = reader.GetInt32(2)
            });
        }
        reader.NextResult();
        while (reader.Read()) {
            controlHeads.Add(new NetControlHead() {
                Id = reader.GetInt32(0),
                Name = reader.GetString(1)
            });
        }
        reader.NextResult();
        while (reader.Read()) {
            heads.Add(new NetHead() {
                Id = reader.GetInt32(0),
                ControlId = reader.GetInt32(1),
                Name = reader.GetString(2),
                Description = reader.GetString(3)
            });
        }

        reader.Close();
        reader.DisposeAsync();
    }
    void populateDisctionaries() {
        foreach (var plot in plots) {
            var bytes = plot.GetBytes();
            plotBytes.Add(plot.Id, bytes);
            sizes.plot += bytes.Sum(x => x.Count);
        }
        foreach (var space in spaces) {
            var bytes = space.GetBytes();
            spaceBytes.Add(space.Id, bytes);
            sizes.space += bytes.Sum(x => x.Count);
        }
        foreach (var tenant in tenants) {
            var bytes = tenant.GetBytes();
            tenantBytes.Add(tenant.Id, bytes);
            sizes.tenants += bytes.Sum(x => x.Count);
        }
        foreach (var lease in leases) {
            var bytes = lease.GetBytes();
            leaseBytes.Add(lease.Id, bytes);
            sizes.leases += bytes.Sum(x => x.Count);
        }
        foreach (var receivable in receivables) {
            var bytes = receivable.GetBytes();
            receivableBytes.Add(new KeyValuePair<int, List<ArraySegment<byte>>>(receivable.LeaseId, bytes));
            sizes.receivables += bytes.Sum(x => x.Count);
        }
        foreach (var head in controlHeads) {
            var bytes = head.GetBytes();
            controlHeadBytes.Add(head.Id, bytes);
            sizes.controlHeads += bytes.Sum(x => x.Count);
        }
        foreach (var head in heads) {
            var bytes = head.GetBytes();
            headBytes.Add(head.Id, bytes);
            sizes.heads += bytes.Sum(x => x.Count);
        }
    }
    bool transaction(List<KeyValuePair<string, List<SqliteParameter>>> commands) {
        bool isOk = true;
        command.CommandText = "BEGIN TRANSACTION;";
        command.ExecuteNonQuery();
        foreach (var item in commands) {
            command.CommandText = item.Key;
            if (item.Value is not null) command.Parameters.AddRange(item.Value);
            try { command.ExecuteNonQuery(); }
            catch (Exception e) {
                command.CommandText = "ROLLBACK;";
                command.ExecuteNonQuery();
                isOk = false;
            }
            command.Parameters.Clear();
            if (!isOk) break;
        }
        if (isOk) {
            command.CommandText = "COMMIT;";
            command.ExecuteNonQuery();
        }
        return isOk;
    }
    List<ArraySegment<byte>> getBytes(int userId, Function func, List<ArraySegment<byte>> bytes) {
        var length = 4 + 4 + bytes.Sum(x => x.Count);
        var messageBytes = new List<ArraySegment<byte>>() {
            BitConverter.GetBytes(length),
            BitConverter.GetBytes((int)func),
            BitConverter.GetBytes(userId)
        };
        messageBytes.AddRange(bytes);
        return messageBytes;
    }
    void getIntoQueue(Socket s, bool isSuccess, string message) {
        var bytes = Encoding.ASCII.GetBytes(message);
        var length = 1 + bytes.Length;
        responses.Add(new QueuedResponse() {
            Sender = s,
            Message = new List<ArraySegment<byte>>() {
                BitConverter.GetBytes(length),
                BitConverter.GetBytes(isSuccess),
                bytes
            }
        });
    }

    public void AddPlot(Request r, Socket s) {
        bool isSuccess = false;
        string message = "";
        var plot = (NetPlot)r.Args[0];
        var match = plots.FirstOrDefault(x => x.Name.Equals(plot.Name, StringComparison.InvariantCultureIgnoreCase));
        if (match is null) {
            int id = plots.Max(x => x.Id);
            command.CommandText = "INSERT INTO Plots (Name, Description) VALUES(@Name, @Description)";
            command.Parameters.AddWithValue("@Name", plot.Name);
            command.Parameters.AddWithValue("@Description", plot.Description);
            command.ExecuteNonQuery();
            command.Parameters.Clear();

            plot.Id = ++id;
            var newBytes = plot.GetBytes();
            var length = newBytes.Sum(x => x.Count);

            sizes.plot += length;
            plotBytes.Add(plot.Id, newBytes);
            plots.Add(plot);
            broadcasts.Add(getBytes(r.UserId, Function.AddPlot, newBytes));
            isSuccess = true;
        }
        else message = "Plot exists";
        getIntoQueue(s, isSuccess, message);
    }
    public void AddSpace(Request r, Socket s) {
        bool isSuccess = false;
        string message = "";
        var space = (NetSpace)r.Args[0];
        var match = spaces.FirstOrDefault(x => x.PlotId == space.PlotId &&
        x.Name.Equals(space.Name, StringComparison.InvariantCultureIgnoreCase));
        if (match is null) {
            int id = spaces.Max(x => x.Id);
            command.CommandText = "INSERT INTO Spaces (PlotId, Name, Description, IsVacant) VALUES(@PlotId, @Name, @Description, 1)";
            command.Parameters.AddWithValue("@PlotId", space.PlotId);
            command.Parameters.AddWithValue("@Name", space.Name);
            command.Parameters.AddWithValue("@Description", space.Description);
            command.ExecuteNonQuery();
            command.Parameters.Clear();

            space.Id = ++id;
            space.IsVacant = true;
            var newBytes = space.GetBytes();
            var length = newBytes.Sum(x => x.Count);

            sizes.space += length;
            spaceBytes.Add(space.Id, newBytes);
            spaces.Add(space);
            broadcasts.Add(getBytes(r.UserId, Function.AddSpace, newBytes));
            isSuccess = true;
        }
        else message = "Space exists";
        getIntoQueue(s, isSuccess, message);
    }
    public void AddTenant(Request r, Socket s) {
        bool isSuccess = false;
        string message = "";
        var tenant = (NetTenant)r.Args[0];
        var match = tenants.FirstOrDefault(x => x.Name.Equals(tenant.Name, StringComparison.InvariantCultureIgnoreCase));
        if (match == null) {
            int id = tenants.Max(x => x.Id);
            object mother = string.IsNullOrWhiteSpace(tenant.Mother) ? DBNull.Value : tenant.Mother;
            object husband = string.IsNullOrWhiteSpace(tenant.Husband) ? DBNull.Value : tenant.Husband;
            object nid = string.IsNullOrWhiteSpace(tenant.NID) ? DBNull.Value : tenant.NID;
            command.CommandText = @"INSERT INTO Tenants (Name, Father, Mother, Husband, Address, NID, ContactNo, HasLeft) 
                            VALUES(@Name, @Father, @Mother, @Husband, @Address, @NID, @ContactNo, 0)";
            command.Parameters.AddWithValue("@Name", tenant.Name);
            command.Parameters.AddWithValue("@Father", tenant.Father);
            command.Parameters.AddWithValue("@Mother", mother);
            command.Parameters.AddWithValue("@Husband", husband);
            command.Parameters.AddWithValue("@Address", tenant.Address);
            command.Parameters.AddWithValue("@NID", nid);
            command.Parameters.AddWithValue("@ContactNo", tenant.ContactNo);
            command.ExecuteNonQuery();
            command.Parameters.Clear();

            tenant.Id = ++id;
            var newBytes = tenant.GetBytes();
            var length = newBytes.Sum(x => x.Count);

            sizes.tenants += length;
            tenantBytes.Add(tenant.Id, newBytes);
            tenants.Add(tenant);
            broadcasts.Add(getBytes(r.UserId, Function.AddTenant, newBytes));
            isSuccess = true;
        }
        else message = "Tenant exists";
        getIntoQueue(s, isSuccess, message);
    }
    public void AddHead(Request r, Socket s) {
        bool isSuccess = false;
        string message = "";
        var head = (NetHead)r.Args[0];
        var match = heads.FirstOrDefault(x => x.ControlId == head.ControlId
        && x.Name.Equals(head.Name, StringComparison.InvariantCultureIgnoreCase));
        if (match is null) {
            var id = heads.Max(x => x.Id);
            command.CommandText = "INSERT INTO Heads (ControlId, Name, Description) VALUES(@ControlId, @Name, @Description)";
            command.Parameters.AddWithValue("@ControlId", head.ControlId);
            command.Parameters.AddWithValue("@Name", head.Name);
            command.Parameters.AddWithValue("@Description", head.Description);
            command.ExecuteNonQuery();
            command.Parameters.Clear();

            head.Id = ++id;
            var newBytes = head.GetBytes();
            var length = newBytes.Sum(x => x.Count);

            sizes.heads += length;
            headBytes.Add(head.Id, newBytes);
            heads.Add(head);
            broadcasts.Add(getBytes(r.UserId, Function.AddHead, newBytes));
        }
        else message = "Head exists";
        getIntoQueue(s, isSuccess, message);
    }
    public void AddLease(Request r, Socket s) {
        bool isSuccess = false;
        string message = "";
        var lease = (NetLease)r.Args[0];
        var newReceivables = (List<NetReceivable>)r.Args[1];
        var match = spaces.FirstOrDefault(x => x.Id == lease.SpaceId && !x.IsVacant);
        // you could check more for match 
        if (match is null) {
            int id = leases.Max(x => x.Id);
            lease.Id = ++id;
            var newReceivableBytes = new List<ArraySegment<byte>>();
            var commands = new List<KeyValuePair<string, List<SqliteParameter>>>();
            var cmd = @"INSERT INTO Leases(PlotId, SpaceId, TenantId, DateStart, Business, IsExpired)
                                          VALUES(@PlotId, @SpaceId, @TenantId, @Date, @Business, 0);
                        UPDATE Spaces SET IsVacant = 0 WHERE Id = @Id;";
            var paras = new List<SqliteParameter>() {
                    new SqliteParameter("@PlotId", lease.PlotId),
                    new SqliteParameter("@SpaceId", lease.SpaceId),
                    new SqliteParameter("@TenantId", lease.TenantId),
                    new SqliteParameter("@Date", lease.DateStart),
                    new SqliteParameter("@Business", lease.Business),
                    new SqliteParameter("@Id", lease.SpaceId)
                };
            commands.Add(new KeyValuePair<string, List<SqliteParameter>>(cmd, paras));
            foreach (var item in newReceivables) {
                var rec = $"INSERT INTO Receivables VALUES({lease.Id}, {item.HeadId}, {item.Amount})";
                commands.Add(new KeyValuePair<string, List<SqliteParameter>>(rec, null));

                item.LeaseId = id;
                var recBytes = item.GetBytes();
                newReceivableBytes.AddRange(recBytes);
                receivableBytes.Add(new KeyValuePair<int, List<ArraySegment<byte>>>(lease.Id, recBytes));
                receivables.Add(item);
            }
            transaction(commands);

            var newLeaseBytes = lease.GetBytes();
            var leaseLength = newLeaseBytes.Sum(x => x.Count);
            var receivableLength = newReceivableBytes.Sum(x => x.Count);

            sizes.leases += leaseLength;
            sizes.receivables += receivableLength;
            leaseBytes.Add(lease.Id, newLeaseBytes);
            leases.Add(lease);

            #region replace OldSpaceBytes with new
            var oldSpace = spaces.First(x => x.Id == lease.SpaceId);
            var oldSpaceBytes = spaceBytes.First(x => x.Key == oldSpace.Id);
            oldSpaceBytes.Value.RemoveRange(0, oldSpaceBytes.Value.Count);

            oldSpace.IsVacant = false;
            oldSpaceBytes.Value.AddRange(oldSpace.GetBytes());
            #endregion

            var newBytes = new List<ArraySegment<byte>>();
            newBytes.AddRange(newLeaseBytes);
            newBytes.AddRange(newReceivableBytes);
            broadcasts.Add(getBytes(r.UserId, Function.AddLease, newBytes));
        }
        else message = "Space is let out";
        getIntoQueue(s, isSuccess, message);
    }
    public void AddTransactionsRegular(Request r, Socket s) {
        var transactions = (List<NetTransaction>)r.Args[0];
        var commands = new List<KeyValuePair<string, List<SqliteParameter>>>();
        foreach (var t in transactions) {
            var command = @$"INSERT INTO Transactions (Date, PlotId, SpaceId, TenantId, ControlId, HeadId, Amount, IsCash, Narration) 
                  VALUES('{t.Date}', {t.PlotId}, {t.SpaceId}, {t.TenantId}, {t.ControlId}, {t.HeadId}, {t.Amount}, {t.IsCash}, '{t.Narration}')";
            commands.Add(new KeyValuePair<string, List<SqliteParameter>>(command, null));
        }
        transaction(commands);
        broadcasts.Add(getBytes(r.UserId, Function.AddTransactionsRegular, new List<ArraySegment<byte>>()));
        getIntoQueue(s, true, "");
    }
    public void AddTransactionsIrregular(Request r, Socket s) {
        var transactions = (List<NetTransaction>)r.Args[0];
        var commands = new List<KeyValuePair<string, List<SqliteParameter>>>();
        foreach (var t in transactions) {
            var command = @$"INSERT INTO Transactions (Date, PlotId, SpaceId, TenantId, ControlId, HeadId, Amount, IsCash, Narration) 
                  VALUES('{t.Date}', {t.PlotId}, {t.SpaceId}, {t.TenantId}, {t.ControlId}, {t.HeadId}, {t.Amount}, {t.IsCash}, '{t.Narration}')";
            commands.Add(new KeyValuePair<string, List<SqliteParameter>>(command, null));
        }
        transaction(commands);
        broadcasts.Add(getBytes(r.UserId, Function.AddTransactionsIrregular, new List<ArraySegment<byte>>()));
        getIntoQueue(s, true, "");
    }
    public void AddBulkRent(Request r, Socket s) {
        var transactions = (List<NetTransaction>)r.Args[0];
        var commands = new List<KeyValuePair<string, List<SqliteParameter>>>();
        foreach (var t in transactions) {
            var command = @$"INSERT INTO Transactions (Date, PlotId, SpaceId, TenantId, ControlId, HeadId, Amount, IsCash, Narration) 
                  VALUES('{t.Date}', {t.PlotId}, {t.SpaceId}, {t.TenantId}, {t.ControlId}, {t.HeadId}, {t.Amount}, 0, '{t.Narration}')";
            commands.Add(new KeyValuePair<string, List<SqliteParameter>>(command, null));
        }
        transaction(commands);
        broadcasts.Add(getBytes(r.UserId, Function.AddBulkRent, new List<ArraySegment<byte>>()));
        getIntoQueue(s, true, "");
    }

    public void EditPlot(Request r, Socket s) {
        bool isSuccess = false;
        string message = "";
        var plot = (NetPlot)r.Args[0];
        var match = plots.FirstOrDefault(x => x.Name.Equals(plot.Name, StringComparison.InvariantCultureIgnoreCase));
        if (match is null) {
            command.CommandText = "UPDATE Plots SET Name = @Name, Description = @Description WHERE Id = @Id";
            command.Parameters.AddWithValue("@Name", plot.Name);
            command.Parameters.AddWithValue("@Description", plot.Description);
            command.Parameters.AddWithValue("@Id", plot.Id);
            command.ExecuteNonQuery();
            command.Parameters.Clear();

            var original = plots.First(x => x.Id == plot.Id);
            original.Name = plot.Name;
            original.Description = plot.Description;

            var oldBytes = plotBytes.First(x => x.Key == plot.Id);
            var oldLength = oldBytes.Value.Sum(x => x.Count);
            sizes.plot -= oldLength;

            var newBytes = plot.GetBytes();
            var newLength = newBytes.Sum(x => x.Count);
            sizes.plot += newLength;

            oldBytes.Value.RemoveRange(0, oldBytes.Value.Count);
            oldBytes.Value.AddRange(newBytes);

            broadcasts.Add(getBytes(r.UserId, Function.EditPlot, newBytes));
            isSuccess = true;
        }
        else message = "Already been edited";
        getIntoQueue(s, isSuccess, message);
    }
    public void EditSpace(Request r, Socket s) {
        bool isSuccess = false;
        string message = "";
        var vaccatedOn = r.Args[0].ToString();
        var edited = (NetSpace)r.Args[1];

        var match = spaces.FirstOrDefault(x => x.Id == edited.Id
            && x.PlotId == edited.PlotId
            && x.Name.Equals(edited.Name)
            && x.IsVacant == edited.IsVacant);

        if (match is null) {
            var original = spaces.First(x => x.Id == edited.Id);
            var commands = new List<KeyValuePair<string, List<SqliteParameter>>>();
            int leaseId = 0;
            if (edited.IsVacant && !original.IsVacant) {
                var lease = leases.First(x => !x.IsExpired && x.SpaceId == edited.Id);
                var leaseCommand = $"UPDATE Leases SET DateEnd = '{vaccatedOn}', IsExpired = 1 WHERE Id = {lease.Id}";
                commands.Add(new KeyValuePair<string, List<SqliteParameter>>(leaseCommand, null));
                lease.DateEnd = vaccatedOn;
                lease.IsExpired = true;
                original.IsVacant = true;
                leaseId = lease.Id;

                #region replace oldLeaseBytes with new
                var oldLeaseBytes = leaseBytes.First(x => x.Key == lease.Id);
                var oldLeaseLength = oldLeaseBytes.Value.Sum(x => x.Count);
                sizes.leases -= oldLeaseLength;

                var newLeaseBytes = lease.GetBytes();
                var newLeaseLength = newLeaseBytes.Sum(x => x.Count);
                sizes.leases += newLeaseLength;

                oldLeaseBytes.Value.RemoveRange(0, oldLeaseBytes.Value.Count);
                oldLeaseBytes.Value.AddRange(newLeaseBytes);
                #endregion
            }
            var cmd = "UPDATE Spaces SET PlotId = @PlotId, Name = @Name, Description = @Description, IsVacant = @IsVacant WHERE Id = @Id";
            var paras = new List<SqliteParameter>() {
                    new SqliteParameter("@PlotId", edited.PlotId),
                    new SqliteParameter("@Name", edited.Name),
                    new SqliteParameter("@Description", edited.Description),
                    new SqliteParameter("@IsVacant", edited.IsVacant),
                    new SqliteParameter("@Id", edited.Id)
                };
            commands.Add(new KeyValuePair<string, List<SqliteParameter>>(cmd, paras));
            transaction(commands);

            original.PlotId = edited.PlotId;
            original.Name = edited.Name;
            original.Description = edited.Description;

            var oldBytes = spaceBytes.First(x => x.Key == edited.Id);
            var oldLength = oldBytes.Value.Sum(x => x.Count);
            sizes.space -= oldLength;

            var newBytes = edited.GetBytes();
            var newLength = newBytes.Sum(x => x.Count);
            sizes.space += newLength;

            oldBytes.Value.RemoveRange(0, oldBytes.Value.Count);
            oldBytes.Value.AddRange(newBytes);

            var date = Encoding.ASCII.GetBytes(vaccatedOn + '\0');
            var bytes = new List<ArraySegment<byte>>() {
                BitConverter.GetBytes(leaseId),
                date
            };
            bytes.AddRange(newBytes);
            broadcasts.Add(getBytes(r.UserId, Function.EditSpace, bytes));
            isSuccess = true;
        }
        else message = "Already been edited";
        getIntoQueue(s, isSuccess, message);
    }
    public void EditTenant(Request r, Socket s) {
        bool isSuccess = false;
        string message = "";
        var leftOn = r.Args[0].ToString();
        var edited = (NetTenant)r.Args[1];
        var original = tenants.First(x => x.Id == edited.Id);
        var isEqual = edited.Name.Equals(original.Name)
            && edited.Father.Equals(original.Father)
            && edited.Mother.Equals(original.Mother)
            && edited.Husband.Equals(original.Husband)
            && edited.Address.Equals(original.Address)
            && edited.ContactNo.Equals(original.ContactNo)
            && edited.Name.Equals(original.NID)
            && edited.HasLeft == original.HasLeft;
        if (!isEqual) {
            var commands = new List<KeyValuePair<string, List<SqliteParameter>>>();
            if (edited.HasLeft && !original.HasLeft) {
                var leaseList = leases.Where(x => !x.IsExpired && x.TenantId == edited.Id).ToList();
                if (leaseList.Count > 0) {
                    foreach (var lease in leaseList) {
                        var space = spaces.FirstOrDefault(x => x.Id == lease.SpaceId);
                        var leaseCommand = $"UPDATE Leases SET DateEnd = '{leftOn}', IsExpired = 1 WHERE Id = {lease.Id}";
                        var spaceCommand = $"UPDATE Spaces SET IsVacant = 1 WHERE Id = {space.Id}";

                        commands.Add(new KeyValuePair<string, List<SqliteParameter>>(leaseCommand, null));
                        commands.Add(new KeyValuePair<string, List<SqliteParameter>>(spaceCommand, null));

                        space.IsVacant = true;
                        lease.IsExpired = true;
                        lease.DateEnd = leftOn;

                        #region replace oldLeaseBytes with new
                        var oldLeaseBytes = leaseBytes.First(x => x.Key == lease.Id);
                        var oldLeaseLength = oldLeaseBytes.Value.Sum(x => x.Count);
                        sizes.leases -= oldLeaseLength;

                        var newLeaseBytes = lease.GetBytes();
                        var newLeaseLength = newLeaseBytes.Sum(x => x.Count);
                        sizes.leases += newLeaseLength;

                        oldLeaseBytes.Value.RemoveRange(0, oldLeaseBytes.Value.Count);
                        oldLeaseBytes.Value.AddRange(newLeaseBytes);
                        #endregion

                        #region replace oldSpaceBytes with new
                        var oldSpaceBytes = spaceBytes.First(x => x.Key == space.Id);
                        oldSpaceBytes.Value.RemoveRange(0, oldSpaceBytes.Value.Count);
                        oldSpaceBytes.Value.AddRange(space.GetBytes());
                        #endregion
                    }
                }
            }
            var tenantCommand = @"UPDATE Tenants SET Name = @Name, Father = @Father, Mother = @Mother, Husband = @Husband,
                            Address = @Address, NID = @NID, ContactNo = @ContactNo, HasLeft = @HasLeft WHERE Id = @Id";
            var paras = new List<SqliteParameter>() {
                 new SqliteParameter("@Name", edited.Name),
                 new SqliteParameter("@Father", edited.Father),
                 new SqliteParameter("@Mother", string.IsNullOrWhiteSpace(edited.Mother) ? DBNull.Value : edited.Mother),
                 new SqliteParameter("@Husband", string.IsNullOrWhiteSpace(edited.Husband) ? DBNull.Value : edited.Husband),
                 new SqliteParameter("@Address", edited.Address),
                 new SqliteParameter("@NID", string.IsNullOrWhiteSpace(edited.NID) ? DBNull.Value : edited.NID),
                 new SqliteParameter("@ContactNo", edited.ContactNo),
                 new SqliteParameter("@HasLeft", edited.HasLeft),
                 new SqliteParameter("@Id", edited.Id)
             };
            commands.Add(new KeyValuePair<string, List<SqliteParameter>>(tenantCommand, paras));
            transaction(commands);

            original.Name = edited.Name;
            original.Father = edited.Father;
            original.Mother = edited.Mother;
            original.Husband = edited.Husband;
            original.Address = edited.Address;
            original.ContactNo = edited.ContactNo;
            original.NID = edited.NID;
            original.HasLeft = edited.HasLeft;

            var oldBytes = tenantBytes.First(x => x.Key == edited.Id);
            var oldLength = oldBytes.Value.Sum(x => x.Count);
            sizes.tenants -= oldLength;

            var newBytes = edited.GetBytes();
            var newLength = newBytes.Sum(x => x.Count);
            sizes.tenants += newLength;

            oldBytes.Value.RemoveRange(0, oldBytes.Value.Count);
            oldBytes.Value.AddRange(newBytes);

            var date = Encoding.ASCII.GetBytes(leftOn + '\0');
            var bytes = new List<ArraySegment<byte>>() { date };
            bytes.AddRange(newBytes);
            broadcasts.Add(getBytes(r.UserId, Function.EditTenant, bytes));
            isSuccess = true;
        }
        else message = "Already been edited";
        getIntoQueue(s, isSuccess, message);
    }
    public void EditHead(Request r, Socket s) {
        bool isSuccess = false;
        string message = "";
        var head = (NetHead)r.Args[0];
        var match = heads.FirstOrDefault(x => x.ControlId == head.ControlId
        && x.Name.Equals(head.Name, StringComparison.InvariantCultureIgnoreCase));
        if (match is null) {
            command.CommandText = "UPDATE Heads SET Name = @Name, Description = @Description WHERE Id = @Id";
            command.Parameters.AddWithValue("@Name", head.Name);
            command.Parameters.AddWithValue("@Description", head.Description);
            command.Parameters.AddWithValue("@Id", head.Id);
            command.ExecuteNonQuery();
            command.Parameters.Clear();

            var original = heads.First(x => x.Id == head.Id);
            original.ControlId = head.ControlId;
            original.Name = head.Name;
            original.Description = head.Description;

            var oldBytes = headBytes.First(x => x.Key == head.Id);
            var oldLength = oldBytes.Value.Sum(x => x.Count);
            sizes.heads -= oldLength;

            var newBytes = head.GetBytes();
            var newLength = newBytes.Sum(x => x.Count);
            sizes.heads += newLength;

            oldBytes.Value.RemoveRange(0, oldBytes.Value.Count);
            oldBytes.Value.AddRange(newBytes);

            broadcasts.Add(getBytes(r.UserId, Function.EditHead, newBytes));
            isSuccess = true;
        }
        else message = "Already been edited";
        getIntoQueue(s, isSuccess, message);
    }
    public void EditLease(Request r, Socket s) {
        bool isSuccess = false;
        string message = "";
        var edited = (NetLease)r.Args[0];
        var editedReceivables = (List<NetReceivable>)r.Args[1];
        var original = leases.First(x => x.Id == edited.Id);
        var originalReceivables = receivables.Where(x => x.LeaseId == edited.Id).ToList();

        var match = leases.FirstOrDefault(x => x.PlotId == edited.PlotId
        && x.SpaceId == edited.SpaceId
        && x.TenantId == edited.TenantId
        && x.IsExpired == edited.IsExpired
        && x.DateStart.Equals(edited.DateStart)
        && x.DateEnd.Equals(edited.DateEnd)
        && x.Business.Equals(edited.Business));

        bool areReceivablesEqual = true;
        if (match is not null) {
            foreach (var item in editedReceivables) {
                var rec = originalReceivables.FirstOrDefault(x => x.HeadId == item.HeadId && x.Amount == item.Amount);
                if (rec is null) {
                    areReceivablesEqual = false;
                    break;
                }
            }
        }

        if (match is null || !areReceivablesEqual) {
            object dateExpired = DBNull.Value;
            var commands = new List<KeyValuePair<string, List<SqliteParameter>>>();

            if (edited.IsExpired && !original.IsExpired) {
                var spaceCommand = $"UPDATE Spaces SET IsVacant = 1 WHERE Id = {edited.SpaceId}";
                commands.Add(new KeyValuePair<string, List<SqliteParameter>>(spaceCommand, null));
                dateExpired = DateTime.Now.ToString("yyyy-MM-dd");

                #region replace OldSpaceBytes with new
                var space = spaces.First(x => x.Id == original.SpaceId);
                space.IsVacant = true;

                var oldSpaceBytes = spaceBytes.First(x => x.Key == space.Id);
                oldSpaceBytes.Value.RemoveRange(0, oldSpaceBytes.Value.Count);
                oldSpaceBytes.Value.AddRange(space.GetBytes());
                #endregion
            }
            else {
                if (edited.IsExpired && original.IsExpired) dateExpired = edited.DateEnd;

                var deleteRecCommand = $"DELETE FROM Receivables WHERE LeaseId = {edited.Id}";
                commands.Add(new KeyValuePair<string, List<SqliteParameter>>(deleteRecCommand, null));
                foreach (var item in editedReceivables) {
                    var insertRecCommand = $"INSERT INTO Receivables VALUES({item.LeaseId}, {item.HeadId}, {item.Amount})";
                    commands.Add(new KeyValuePair<string, List<SqliteParameter>>(insertRecCommand, null));
                }
            }

            if (edited.SpaceId != original.SpaceId) {
                var spaceCmd1 = $"UPDATE Spaces SET IsVacant = 1 WHERE Id = {original.SpaceId}";
                var spaceCmd2 = $"UPDATE Spaces SET IsVacant = 0 WHERE Id = {edited.SpaceId}";

                commands.Add(new KeyValuePair<string, List<SqliteParameter>>(spaceCmd1, null));
                commands.Add(new KeyValuePair<string, List<SqliteParameter>>(spaceCmd2, null));

                var spaceOld = spaces.FirstOrDefault(x => x.Id == original.SpaceId);
                spaceOld.IsVacant = true;

                var spaceNew = spaces.FirstOrDefault(x => x.Id == edited.SpaceId);
                spaceNew.IsVacant = false;

                #region replace OldSpaceBytes with new
                var oldSpaceBytes = spaceBytes.First(x => x.Key == spaceOld.Id);
                var newSpaceBytes = spaceBytes.First(x => x.Key == spaceNew.Id);

                oldSpaceBytes.Value.RemoveRange(0, oldSpaceBytes.Value.Count);
                newSpaceBytes.Value.RemoveRange(0, newSpaceBytes.Value.Count);

                oldSpaceBytes.Value.AddRange(spaceOld.GetBytes());
                newSpaceBytes.Value.AddRange(spaceNew.GetBytes());
                #endregion
            }
            var cmd = @"UPDATE Leases SET PlotId = @PlotId, SpaceId = @SpaceId, TenantId = @TenantId, 
                       DateStart = @DateStart, DateEnd = @DateEnd, Business = @Business, IsExpired = @IsExpired WHERE Id = @Id";
            var paras = new List<SqliteParameter>() {
                    new SqliteParameter("@PlotId", edited.PlotId),
                    new SqliteParameter("@SpaceId", edited.SpaceId),
                    new SqliteParameter("@TenantId", edited.TenantId),
                    new SqliteParameter("@DateStart", edited.DateStart),
                    new SqliteParameter("@DateEnd", dateExpired),
                    new SqliteParameter("@Business", edited.Business),
                    new SqliteParameter("@IsExpired", edited.IsExpired),
                    new SqliteParameter("@Id", edited.Id)
                };

            commands.Add(new KeyValuePair<string, List<SqliteParameter>>(cmd, paras));
            transaction(commands);

            var newReceivableBytes = new List<ArraySegment<byte>>();
            int newReceivableLength = 0;
            #region replace OldReceivableBytes with new
            var oldReceivables = receivableBytes.Where(x => x.Key == edited.Id).ToList();
            var oldReceivableLength = oldReceivables.Sum(x => x.Value.Sum(x => x.Count));
            sizes.receivables -= oldReceivableLength;

            foreach (var item in oldReceivables) receivableBytes.Remove(item);
            foreach (var item in editedReceivables) {
                var newBytes = item.GetBytes();
                newReceivableLength += newBytes.Sum(x => x.Count);
                receivableBytes.Add(new KeyValuePair<int, List<ArraySegment<byte>>>(item.LeaseId, newBytes));
                newReceivableBytes.AddRange(newBytes);
            }
            sizes.receivables += newReceivableLength;
            #endregion

            var newLeaseBytes = edited.GetBytes();
            var oldLeaseBytes = original.GetBytes();

            var newLeaseLength = newLeaseBytes.Sum(x => x.Count);
            var oldLeaseLength = oldLeaseBytes.Sum(x => x.Count);

            sizes.leases -= oldLeaseLength;
            sizes.leases += newLeaseLength;

            leaseBytes.Remove(original.Id);
            leaseBytes.Add(edited.Id, newLeaseBytes);

            leases.Remove(original);
            leases.Add(edited);

            var bytes = new List<ArraySegment<byte>>();
            bytes.AddRange(newLeaseBytes);
            bytes.AddRange(newReceivableBytes);
            broadcasts.Add(getBytes(r.UserId, Function.EditLease, bytes));
            isSuccess = true;
        }
        else message = "Already been edited";
        getIntoQueue(s, isSuccess, message);
    }
    public void EditTransaction(Request r, Socket s) {
        //validate whether exists
        var edited = (NetTransaction)r.Args[0];
        var narration = edited.Narration == null ? (object)DBNull.Value : edited.Narration;
        command.CommandText = @$"UPDATE Transactions SET Date = '{edited.Date}', PlotId = {edited.PlotId}, SpaceId ={edited.SpaceId},
                                     TenantId ={edited.TenantId}, ControlId = {edited.ControlId}, HeadId = {edited.HeadId}, IsCash = {edited.IsCash}, 
                                        Narration = @Narration, Amount = {edited.Amount} WHERE Id = {edited.Id}";
        command.Parameters.AddWithValue("@Narration", narration);
        command.ExecuteNonQuery();
        command.Parameters.Clear();
        broadcasts.Add(getBytes(r.UserId, Function.EditTransaction, edited.GetBytes()));
        getIntoQueue(s, true, "");
    }

    public void DeleteTransaction(Request r, Socket s) {
        //validate whether exists
        var transaction = (NetTransaction)r.Args[0];
        command.CommandText = $"DELETE FROM Transactions WHERE Id = {transaction.Id}";
        command.ExecuteNonQuery();
        broadcasts.Add(getBytes(r.UserId, Function.EditTransaction, transaction.GetBytes()));
        getIntoQueue(s, true, "");
    }

    public void GetTransactions(Request r, Socket s) {
        var date = r.Args[0].ToString();
        var list = new List<NetTransaction>();
        var bytes = new List<ArraySegment<byte>>();

        command.CommandText = $"SELECT * FROM Transactions WHERE Date = '{date}'";
        var reader = command.ExecuteReader();
        while (reader.Read()) {
            list.Add(new NetTransaction() {
                Id = reader.GetInt32(0),
                Date = reader.GetString(1),
                PlotId = reader.GetInt32(2),
                SpaceId = reader.GetInt32(3),
                TenantId = reader.GetInt32(4),
                ControlId = reader.GetInt32(5),
                HeadId = reader.GetInt32(6),
                Amount = reader.GetInt32(7),
                IsCash = reader.GetByte(8),
                Narration = reader.IsDBNull(9) ? "" : reader.GetString(9)
            });
        }
        reader.Close();
        reader.DisposeAsync();

        int total = 0;
        foreach (var transaction in list) {
            var array = transaction.GetBytes();
            bytes.AddRange(array);
            total += array.Sum(x => x.Count);
        }
        bytes.Insert(0, BitConverter.GetBytes(total));
        responses.Add(new QueuedResponse() {
            Sender = s,
            Message = bytes
        });
    }
    public void GetBalance(Request r, Socket s) {
        int plotId = (int)r.Args[0];
        int hasLeft = (int)r.Args[1];
        var segments = new List<ArraySegment<byte>>();
        var list = new List<NetBalance>();
        command.CommandText = $@"WITH t0(Space, Tenant, Amount, ControlId, HeadId, TenantId, SpaceId) AS(
									SELECT s.Name, t.Name, SUM(tn.Amount), tn.ControlId, tn.HeadId, tn.TenantId, tn.SpaceId FROM Transactions tn
									LEFT JOIN Plots p ON p.Id = tn.PlotId
									LEFT JOIN Spaces s ON s.Id = tn.SpaceId
									LEFT JOIN Tenants t ON t.Id = tn.TenantId
									WHERE tn.PlotId = {plotId} AND TenantId IN (SELECT Id FROM Tenants WHERE HasLeft = {hasLeft})
									GROUP BY t.Name, s.Name, tn.HeadId
									ORDER BY s.Name
								),
								t1(Space, Tenant, Security, Receivable, Receipt, TenantId, SpaceId) AS(
									SELECT Space, Tenant, 
									SUM(CASE HeadId WHEN 4 THEN 1 WHEN 6 THEN -1 ELSE 0 END * Amount) Security,
									SUM(CASE ControlId WHEN 1 THEN Amount ELSE 0 END) Receivable,
									SUM(CASE WHEN HeadId=5 THEN Amount ELSE 0 END) Receipt,
									TenantId, SpaceId FROM t0
									GROUP BY Tenant, Space
								),
								t2 (Space, Tenant, Security, Due, TenantId, SpaceId) AS (
									SELECT Space, Tenant, Security, (Receivable - Receipt) Due, TenantId, SpaceId FROM t1
								),
								t3(Space, Tenant, Security, Due, LeaseId, DateStart, DateEnd, IsExpired) AS(
									SELECT Space, Tenant, Security, Due, l.Id, l.DateStart, l.DateEnd, l.IsExpired FROM t2 tn
									LEFT JOIN Leases l ON l.TenantId = tn.TenantId AND l.SpaceId = tn.SpaceId
								),
								t4(Space, Tenant, Security, Rent, Due, DateStart, DateEnd, IsExpired) AS(
									SELECT Space, Tenant, Security, COALESCE(SUM(r.Amount), 0), Due, DateStart, DateEnd, IsExpired FROM t3 tn
									LEFT JOIN Receivables r ON r.LeaseId = tn.LeaseId
									GROUP BY tn.Tenant, tn.LeaseId
								),
								t5(Space, Tenant, Security, Rent, Due, DateStart, DateEnd, IsExpired, Counts) AS (
                                	SELECT *, COUNT(Tenant)
                                	FROM t4 GROUP BY Tenant
                                ),
                                t6(Space, Tenant, Security, Rent, Due, DateStart, DateEnd, IsExpired, Counts, SCount) AS(
                                    SELECT t1.Space, t1.Tenant, t1.Security, t1.Rent, t1.Due, t1.DateStart, t1.DateEnd, t1.IsExpired, t2.Counts,
                                    COUNT(t1.Space) OVER(PARTITION BY t1.Tenant, t1.Space) SCount FROM t4 t1
                                    LEFT JOIN t5 t2 ON t1.Tenant = t2.Tenant
                                    ORDER BY t2.Counts DESC, t1.Tenant ASC
                                )
                                SELECT Space, Tenant, Security, Rent, 
                                CASE WHEN SCount > 1 AND IsExpired = 1 THEN 0 ELSE Due END AS Due,
                                COALESCE(DateStart, ''), COALESCE(DateEnd, ''), COALESCE(IsExpired, 0), Counts FROM t6";
        var reader = command.ExecuteReader();
        while (reader.Read()) {
            list.Add(new NetBalance() {
                Space = reader.GetString(0),
                Tenant = reader.GetString(1),
                Security = reader.GetInt32(2),
                Rent = reader.GetInt32(3),
                Due = reader.GetInt32(4),
                DateStart = reader.GetString(5),
                DateEnd = reader.GetString(6),
                IsExpired = reader.GetBoolean(7),
                Count = reader.GetInt32(8)
            });
        }
        reader.Close();
        reader.DisposeAsync();
        int total = 0;
        foreach (var item in list) {
            var bytes = item.GetBytes();
            segments.AddRange(bytes);
            total += bytes.Sum(x => x.Count);
        }
        segments.Insert(0, BitConverter.GetBytes(total));
        responses.Add(new QueuedResponse() {
            Sender = s,
            Message = segments
        });
    }
    public void GetMonthlyBalance(Request r, Socket s) {
        string firstDayOfPreviousMonth = r.Args[0].ToString();
        string lastDayOfPreviousMonth = r.Args[1].ToString();
        string lastDayOfSelectedMonth = r.Args[2].ToString();

        var segments = new List<ArraySegment<byte>>();
        var list = new List<NetMonthlyBalance>();
        command.CommandText = $@"WITH t1 AS(
        			SELECT PlotId, SpaceId, TenantId, SUM(Amount) Amount FROM Transactions
        			WHERE Date BETWEEN '{firstDayOfPreviousMonth}' AND '{lastDayOfPreviousMonth}' AND ControlId = 1	
        			GROUP BY PlotId, TenantId, SpaceId
        		), 
        		t2 AS(
        			SELECT Date, Transactions.PlotId, Transactions.TenantId, SUM(t1.Amount) CurrentDue, SUM(Transactions.Amount) Paid FROM Transactions
        			LEFT JOIN t1 ON t1.SpaceId = Transactions.SpaceId AND t1.TenantId = Transactions.TenantId
        			WHERE ControlId = 2 AND HeadId = 5
        			AND (Date > '{lastDayOfPreviousMonth}' AND Date <= '{lastDayOfSelectedMonth}')
        			GROUP BY Transactions.PlotId, Transactions.TenantId
        		),
        		t3 AS(
        			SELECT PlotId, SpaceId, TenantId,
        			SUM(CASE WHEN ControlId = 1 THEN Amount ELSE 0 END) -
        			SUM(CASE WHEN ControlId = 2 AND HeadId = 5 THEN Amount ELSE 0 END) Amount
        			FROM Transactions
        			WHERE Date <= '{lastDayOfPreviousMonth}' AND TenantId IN(SELECT TenantId FROM t1)
        			GROUP BY PlotId, TenantId
        		),
        		t4 AS(
        			SELECT PlotId, SpaceId, TenantId, SUM(Amount) CurrentDue FROM t1 GROUP BY PlotId, TenantId
        		)
        		SELECT COALESCE(t2.Date, ''), Plots.Name, Tenants.Name, t3.Amount Due, COALESCE(t4.CurrentDue, 0), COALESCE(t2.Paid, 0) Paid FROM t3
        		LEFT JOIN t2 ON t2.PlotId = t3.PlotId AND t2.TenantId = t3.TenantId
        		LEFT JOIN t4 ON t4.PlotId = t3.PlotId AND t4.TenantId = t3.TenantId
        		LEFT JOIN Plots ON Plots.Id = t3.PlotId
        		LEFT JOIN Tenants ON Tenants.Id = t3.TenantId
        		WHERE Due <> 0 OR t4.CurrentDue <> 0 OR Paid <> 0";
        var reader = command.ExecuteReader();
        while (reader.Read()) {
            var e = new NetMonthlyBalance() {
                Date = reader.GetString(0),
                Plot = reader.GetString(1),
                Tenant = reader.GetString(2),
                Due = reader.GetInt32(3),
                LastMonthDue = reader.GetInt32(4),
                Payment = reader.GetInt32(5)
            };
            list.Add(e);
        }
        reader.Close();
        reader.DisposeAsync();

        int total = 0;
        foreach (var item in list) {
            var bytes = item.GetBytes();
            segments.AddRange(bytes);
            total += bytes.Sum(x => x.Count);
        }
        segments.Insert(0, BitConverter.GetBytes(total));
        responses.Add(new QueuedResponse() {
            Sender = s,
            Message = segments
        });
    }
    public void GetLedger(Request r, Socket s) {
        int id = (int)r.Args[0];
        string where = r.Args[1].ToString();

        var segments = new List<ArraySegment<byte>>();
        var list = new List<NetReportEntry>();
        string particulars = "";
        string join = "";

        switch (where) {
            case "PlotId":
                particulars = "s.Name || ' -> ' || t.Name";
                join = @"LEFT JOIN Spaces s ON s.Id = tn.SpaceId
                         LEFT JOIN Tenants t ON t.Id = tn.TenantId";
                break;
            case "SpaceId":
                particulars = "p.Name || ' -> ' || t.Name";
                join = @"LEFT JOIN Plots p ON p.Id = tn.PlotId
                         LEFT JOIN Tenants t ON t.Id = tn.TenantId";
                break;
            case "TenantId":
                particulars = "p.Name || ' -> ' || s.Name";
                join = @"LEFT JOIN Plots p ON p.Id = tn.PlotId
                         LEFT JOIN Spaces s ON s.Id = tn.SpaceId";
                break;
        }
        command.CommandText = $@"SELECT tn.Date, {particulars} ||' -> '|| c.Name ||' - '|| h.Name ||' - '|| tn.Narration, 
                                     tn.Amount, tn.ControlId FROM Transactions tn {join}
                                     LEFT JOIN Heads h ON h.Id = tn.HeadId
                                     LEFT JOIN ControlHeads c ON c.Id = tn.ControlId
                                     WHERE tn.{where}={id} ORDER by tn.Date";
        var reader = command.ExecuteReader();
        while (reader.Read()) {
            list.Add(new NetReportEntry() {
                Date = reader.GetString(0),
                Particulars = reader.GetString(1),
                Amount = reader.GetInt32(2),
                ControlId = reader.GetInt32(3)
            });
        }
        reader.Close();
        reader.DisposeAsync();

        int total = 0;
        foreach (var item in list) {
            var bytes = item.GetBytes();
            segments.AddRange(bytes);
            total += bytes.Sum(x => x.Count);
        }
        segments.Insert(0, BitConverter.GetBytes(total));
        responses.Add(new QueuedResponse() {
            Sender = s,
            Message = segments
        });
    }
    public void GetReceiptPayment(Request r, Socket s) {
        string from = r.Args[0].ToString();
        string to = r.Args[1].ToString();

        var segments = new List<ArraySegment<byte>>();
        var list = new List<NetReceiptPayment>();
        command.CommandText = $@"WITH t0(Plot, Space, Tenant, Control, Head, InCash, Mobile, InKind) AS (
                                 	SELECT PlotId, SpaceId, TenantId, ControlId, HeadId,
                                 	SUM(coalesce(CASE WHEN IsCash=0 THEN Amount END, 0)),
                                    SUM(coalesce(CASE WHEN IsCash=2 THEN Amount END, 0)),
                                 	SUM(coalesce(CASE WHEN IsCash=1 THEN Amount END, 0))
                                 	FROM Transactions 
                                 	WHERE ControlId <> 1 AND Date BETWEEN '{from}' AND '{to}'
                                 	GROUP BY SpaceId, TenantId, HeadId
                                 ) 
                                 SELECT p.Name, s.Name, t.Name, c.Name, h.Name, InCash, Mobile, InKind, (InCash + Mobile + InKind) Total
                                 from t0 as tn
                                 LEFT JOIN Plots p ON p.Id = tn.Plot
                                 LEFT JOIN Spaces s ON s.Id = tn.Space
                                 LEFT JOIN Tenants t ON t.Id = tn.Tenant
                                 LEFT JOIN ControlHeads c ON c.Id = tn.Control
                                 LEFT JOIN Heads h ON h.Id = tn.Head";
        var reader = command.ExecuteReader();
        while (reader.Read()) {
            list.Add(new NetReceiptPayment() {
                Plot = reader.GetString(0),
                Space = reader.GetString(1),
                Tenant = reader.GetString(2),
                Control = reader.GetString(3),
                Head = reader.GetString(4),
                Cash = reader.GetInt32(5),
                Mobile = reader.GetInt32(6),
                Kind = reader.GetInt32(7),
                Total = reader.GetInt32(8)
            });
        }
        reader.Close();
        reader.DisposeAsync();
        int total = 0;
        foreach (var item in list) {
            var bytes = item.GetBytes();
            segments.AddRange(bytes);
            total += bytes.Sum(x => x.Count);
        }
        segments.Insert(0, BitConverter.GetBytes(total));
        responses.Add(new QueuedResponse() {
            Sender = s,
            Message = segments
        });
    }
    public void GetPlotDueChart(Request r, Socket s) {
        int id = (int)r.Args[0];
        string date = r.Args[1].ToString();

        string where1 = "";
        string where2 = "";
        if (id == 0) {
            where1 = $"WHERE Date < '{date}'";
            where2 = $"WHERE Date >= '{date}'";
        }
        else {
            where1 = $"WHERE PlotId = {id} AND Date < '{date}'";
            where2 = $"WHERE PlotId = {id} AND Date >= '{date}'";
        }
        var list = new List<NetPlotWiseDue>();
        command.CommandText = $@"WITH t0(Date, Month, TenantId, Amount) AS(
                                    SELECT '' Date, '' Month, TenantId,
                                    SUM(CASE WHEN ControlId = 1 THEN Amount ELSE 0 END) -
                                    SUM(CASE WHEN ControlId = 2 AND HeadId = 5 THEN Amount ELSE 0 END) Amount
                                    FROM Transactions {where1}
                                    GROUP BY TenantId
                                   ),
                                   t1 AS(
                                   	SELECT Date, strftime('%m - %Y', Date) Month, TenantId,
                                   	SUM(CASE WHEN ControlId = 1 THEN Amount ELSE 0 END) -
                                   	SUM(CASE WHEN ControlId = 2 AND HeadId = 5 THEN Amount ELSE 0 END) Amount	
                                   	FROM Transactions tn {where2}
                                   	GROUP BY TenantId, strftime('%m-%Y', Date)
                                   	ORDER BY strftime('%Y', Date), strftime('%m', Date)
                                   ),
                                   t3 AS(SELECT * FROM t0 UNION ALL SELECT * FROM t1),
                                   t4 AS(
                                   	SELECT Date, Month, TenantId, t.Name, Amount, ROW_NUMBER() OVER (PARTITION BY TenantId) RowNum
                                   	FROM t3
                                   	LEFT JOIN Tenants t ON t.Id = TenantId
                                   ),
                                   t5 AS(SELECT Month, Name, SUM(Amount) OVER (PARTITION BY TenantId ORDER BY RowNum) Due, Date FROM t4)
                                   SELECT * FROM t5 WHERE Month <> ''
                                   ORDER BY strftime('%Y', Date), strftime('%m', Date)";
        var reader = command.ExecuteReader();
        while (reader.Read()) {
            list.Add(new NetPlotWiseDue() {
                Month = reader.GetString(0),
                Tenant = reader.GetString(1),
                Due = reader.GetInt32(2)
            });
        }
        reader.Close();
        reader.DisposeAsync();

        var bytes = new List<ArraySegment<byte>>();
        foreach (var item in list) {
            bytes.AddRange(item.GetBytes());
        }
        var size = bytes.Sum(x => x.Count);
        bytes.Insert(0, BitConverter.GetBytes(size));
        responses.Add(new QueuedResponse() {
            Sender = s,
            Message = bytes
        });
    }
    public void GetPlotWiseRent(Request r, Socket s) {
        int id = (int)r.Args[0];
        string date = r.Args[1].ToString();
        string query = "";
        if (id == 0) {
            query = $@"SELECT 'All plots', t.Name, strftime('%m - %Y', Date) Month, 
                           coalesce(SUM(CASE WHEN ControlId=1 THEN Amount END), 0) Rent,
                           coalesce(SUM(CASE WHEN ControlId=2 AND HeadId=5 AND IsCash=0 THEN Amount END),0) Cash,
                           coalesce(SUM(CASE WHEN ControlId=2 AND HeadId=5 AND IsCash=2 THEN Amount END),0) Mobile,
                           coalesce(SUM(CASE WHEN ControlId=2 AND HeadId=5 AND IsCash=1 THEN Amount END),0) Kind,
                       tn.PlotId
                       From Transactions tn
                       LEFT JOIN Tenants t ON t.Id = tn.TenantId
                       WHERE Date > '{date}'
                       GROUP BY TenantId, strftime('%m-%Y', Date) 
                       ORDER BY strftime('%Y', Date), strftime('%m', Date)";
        }
        else {
            query = $@"SELECT p.Name, t.Name, strftime('%m - %Y', Date) Month, 
                           coalesce(SUM(CASE WHEN ControlId=1 THEN Amount END), 0) Rent,
                           coalesce(SUM(CASE WHEN ControlId=2 AND HeadId=5 AND IsCash=0 THEN Amount END), 0) Cash,
                           coalesce(SUM(CASE WHEN ControlId=2 AND HeadId=5 AND IsCash=2 THEN Amount END), 0) Mobile,
                           coalesce(SUM(CASE WHEN ControlId=2 AND HeadId=5 AND IsCash=1 THEN Amount END), 0) Kind,
                       tn.PlotId
                       From Transactions tn
                       LEFT JOIN Plots p ON p.Id = tn.PlotId
                       LEFT JOIN Tenants t ON t.Id = tn.TenantId
                       WHERE PlotId = {id} AND Date > '{date}'
                       GROUP BY TenantId, strftime('%m-%Y', Date) 
                       ORDER BY strftime('%Y', Date), strftime('%m', Date)";
        }
        var list = new List<NetPlotWiseRent>();
        command.CommandText = query;
        var reader = command.ExecuteReader();
        while (reader.Read()) {
            var pr = new NetPlotWiseRent() {
                Plot = reader.GetString(0),
                Tenant = reader.GetString(1),
                Month = reader.GetString(2),
                Rent = reader.GetInt32(3),
                Cash = reader.GetInt32(4),
                Mobile = reader.GetInt32(5),
                Kind = reader.GetInt32(6),
                PlotId = reader.GetInt32(7)
            };
            pr.Total = pr.Cash + pr.Mobile + pr.Kind;
            list.Add(pr);
        }
        reader.Close();
        reader.DisposeAsync();

        var bytes = new List<ArraySegment<byte>>();
        foreach (var item in list) {
            bytes.AddRange(item.GetBytes());
        }
        var size = bytes.Sum(x => x.Count);
        bytes.Insert(0, BitConverter.GetBytes(size));
        responses.Add(new QueuedResponse() {
            Sender = s,
            Message = bytes
        });
    }
    public void GetTenantDetail(Request r, Socket s) {
        int id = (int)r.Args[0];
        string date = DateTime.Today.AddMonths(-12).ToString("yyyy-MM-dd");
        if (tenants.First(x => x.Id == id).HasLeft) {
            command.CommandText = $"SELECT MAX(Date) FROM Transactions WHERE TenantId = {id}";
            var lastDate = command.ExecuteScalar();
            if (lastDate != null) {
                var dateParts = lastDate.ToString().Split('-');
                var dt = new DateTime(Convert.ToInt32(dateParts[0]), Convert.ToInt32(dateParts[1]), Convert.ToInt32(dateParts[2]));
                date = dt.AddMonths(-12).ToString("yyyy-MM-dd");
            }
        }
        command.CommandText = $@"SELECT coalesce(SUM(CASE WHEN HeadId = 4 THEN Amount ELSE -Amount END), 0) Deposit
                                 FROM Transactions WHERE TenantId = {id} AND HeadId IN(4, 6)";
        var deposit = Convert.ToInt32(command.ExecuteScalar());

        var list = new List<NetRentPayment>();
        command.CommandText = $@"WITH t0(Date, Plot, Space, Tenant, Control, Due, Cash, Mobile, Kind) AS(
                                	SELECT '' Date, '' Plot, '' Space, '' Tenant, tn.ControlId,
                                	SUM(CASE WHEN ControlId = 1 THEN Amount ELSE 0 END) -
                                	SUM(CASE WHEN ControlId <> 1 THEN Amount ELSE 0 END) Due,
                                	0 Cash, 0 Mobile, 0 Kind FROM Transactions tn
                                	WHERE TenantId = {id} AND ControlId <> 3 AND HeadId <> 4 AND Date < '{date}'
                                	GROUP BY Plot, Space
                                ),
                                t1 AS(
                                	SELECT Date, p.Name Plot, s.Name Space, t.Name Tenant, tn.ControlId,
                                	SUM(CASE WHEN ControlId = 1 THEN Amount ELSE 0 END) Due,
                                	SUM(CASE WHEN ControlId <> 1 AND IsCash = 0 THEN Amount ELSE 0 END) Cash,
                                    SUM(CASE WHEN ControlId <> 1 AND IsCash = 2 THEN Amount ELSE 0 END) Mobile,
                                	SUM(CASE WHEN ControlId <> 1 AND IsCash = 1 THEN Amount ELSE 0 END) Kind
                                    FROM Transactions tn
                                	LEFT JOIN Plots p ON p.Id = tn.PlotId
                                	LEFT JOIN Spaces s ON s.Id = tn.SpaceId
                                	LEFT JOIN Tenants t ON t.Id = tn.TenantId
                                	WHERE TenantId = {id} AND ControlId <> 3 AND HeadId <> 4 AND Date >= '{date}'
                                	GROUP BY Plot, Space, HeadId, Date
                                	ORDER BY Date, ControlId DESC
                                ),
                                t2 AS(SELECT * FROM t0 UNION ALL SELECT * FROM t1),
                                t3 AS(SELECT *, ROW_NUMBER() OVER(ORDER BY (SELECT 1)) RowNum FROM t2),
                                t4 AS(SELECT *, SUM(Due - Cash - Mobile - Kind) OVER(ORDER BY RowNum) Balance FROM t3),
                                t5 AS(SELECT *, LAG(Balance, 1, 0) OVER (ORDER BY RowNum) Pos FROM t4)	
                                SELECT Date, Plot, Space, Tenant, Cash, Mobile, Kind, Pos AS Due FROM t5
                                WHERE Cash > 0 OR Mobile > 0 OR Kind > 0
                                ORDER BY Date";
        var reader = command.ExecuteReader();
        while (reader.Read()) {
            var rp = new NetRentPayment() {
                Date = reader.GetString(0),
                Plot = reader.GetString(1),
                Space = reader.GetString(2),
                Tenant = reader.GetString(3),
                Cash = reader.GetInt32(4),
                Mobile = reader.GetInt32(5),
                Kind = reader.GetInt32(6),
                Due = reader.GetInt32(7)
            };
            rp.TotalPaid = rp.Cash + rp.Mobile + rp.Kind;
            list.Add(rp);
        }
        reader.Close();
        reader.DisposeAsync();

        var bytes = new List<ArraySegment<byte>>();
        bytes.Add(BitConverter.GetBytes(deposit));
        foreach (var item in list) {
            bytes.AddRange(item.GetBytes());
        }
        var size = bytes.Sum(x => x.Count);
        bytes.Insert(0, BitConverter.GetBytes(size));
        responses.Add(new QueuedResponse() {
            Sender = s,
            Message = bytes
        });
    }
    public void GetDepositDueRent(Request r, Socket s) {
        var state = (byte)r.Args[0];
        string query = "";
        if(state == 1) {
            query = @"SELECT PlotId, SpaceId, TenantId,
                          SUM(CASE WHEN ControlId = 2 THEN 1 ELSE -1 END * Amount) Amount
                      FROM Transactions 
                      LEFT JOIN Tenants t ON t.Id = TenantId
                      WHERE HeadId IN(4,6) AND t.HasLeft = 0
                      GROUP BY PlotId, SpaceId, TenantId";
        }
        else {
            query = @"SELECT PlotId, SpaceId, TenantId,
                          SUM(CASE WHEN ControlId = 1 THEN 1 ELSE -1 END * Amount) Amount
                      FROM Transactions 
                      LEFT JOIN Tenants t ON t.Id = TenantId
                      WHERE ControlId IN(1, 2) AND HeadId <> 4 AND t.HasLeft = 0
                      GROUP BY PlotId, SpaceId, TenantId";
        }
        var list = new List<NetDepositDueRent>();
        command.CommandText = query;
        var reader = command.ExecuteReader();
        while (reader.Read()) {
            list.Add(new NetDepositDueRent() {
                State = state,
                PlotId = reader.GetInt32(0),
                SpaceId = reader.GetInt32(1),
                TenantId = reader.GetInt32(2),
                Amount = reader.GetInt32(3)
            });
        }
        reader.Close();
        reader.DisposeAsync();

        var bytes = new List<ArraySegment<byte>>();
        foreach (var item in list) {
            bytes.AddRange(item.GetBytes());
        }
        var size = bytes.Sum(x => x.Count);
        bytes.Insert(0, BitConverter.GetBytes(size));
        responses.Add(new QueuedResponse() {
            Sender = s,
            Message = bytes
        });
    }
}