﻿public class NetParty
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string Address { get; set; }
    public string Phone { get; set; }

    public List<ArraySegment<byte>> GetBytes() {
        return new List<ArraySegment<byte>>() {
            BitConverter.GetBytes(Id),
            Encoding.ASCII.GetBytes(Name + '\0'),
            Encoding.ASCII.GetBytes(Address + '\0'),
            Encoding.ASCII.GetBytes(Phone + '\0')
        };
    }
    public static NetParty FromBytes(ReadOnlySpan<byte> array) {
        int read, start, index;
        index = 0;
        read = start = 4;
        var segments = new string[3];
        while (read < array.Length) {
            if (array[read] != 0) {
                read++;
                continue;
            }
            segments[index++] = Encoding.ASCII.GetString(array.Slice(start, read - start));
            start = ++read;
            if (index == segments.Length) break;
        }
        return new NetParty() {
            Id = BitConverter.ToInt32(array.Slice(0, 4)),
            Name = segments[0],
            Address = segments[1],
            Phone = segments[2]
        };
    }
}
