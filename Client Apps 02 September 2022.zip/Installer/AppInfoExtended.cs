﻿class AppInfoExtended
{
    public string Name { get; set; }
    public string Version { get; set; }
    public bool IsSelected { get; set; }
}
