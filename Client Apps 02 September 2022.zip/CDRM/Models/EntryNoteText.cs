﻿class EntryNoteText : Notifiable
{
    public int Id { get; set; }
    public DateTime? Date { get; set; }
    public string NoteType { get; set; }
    public string Site { get; set; }
    public string Entry { get; set; }

    public int NoteTypeId { get; set; }
    public int SiteId { get; set; }
}
