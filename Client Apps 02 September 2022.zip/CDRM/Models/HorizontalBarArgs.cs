﻿class HorizontalBarArgs
{
    public string Type { get; set; }
    public string Name { get; set; }
    public DateTime From { get; set; }
    public DateTime To { get; set; }
}
