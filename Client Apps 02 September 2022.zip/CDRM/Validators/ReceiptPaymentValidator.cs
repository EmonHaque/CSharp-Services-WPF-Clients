﻿using System.ComponentModel.DataAnnotations;
using System.Windows.Media.Media3D;

class ReceiptPaymentValidator
{
    EntryReceiptPayment entry;
    public List<ValidationError> Errors { get; set; }

    public ReceiptPaymentValidator() { }
    public ReceiptPaymentValidator(EntryReceiptPayment entry) {
        this.entry = entry;
    }

    public bool DoesExist() {
        if (!AppData.HasParty(entry.Party)) {
            Errors.Add(new ValidationError() {
                Head = "Party",
                Error = Constants.DoesntExist
            });
        }
        else entry.PartyId = AppData.GetParty().Id;
        if (!AppData.HasHead(entry.Head)) {
            Errors.Add(new ValidationError() {
                Head = "Head",
                Error = Constants.DoesntExist
            });
        }
        else entry.HeadId = AppData.GetHead().Id;
        return Errors.Count == 0;
    }
    public bool IsEqual(EntryReceiptPayment e) {
        if (e.IsReceipt != entry.IsReceipt) {
            if (e.IsReceipt == 0) entry.Title = "Receipt";
            else entry.Title = "Payment";
            return false;
        }
        if (e.Date != entry.Date) return false;
        if (e.IsCash != entry.IsCash) return false;
        if (!e.Head.Equals(entry.Head, StringComparison.InvariantCultureIgnoreCase)) return false;
        if (!e.Party.Equals(entry.Party, StringComparison.InvariantCultureIgnoreCase)) return false;
        if (!e.Narration.Equals(entry.Narration, StringComparison.InvariantCultureIgnoreCase)) return false;

        int originalAmount, editedAmount;
        int.TryParse(e.Amount, NumberStyles.Number, CultureInfo.CurrentCulture.NumberFormat, out originalAmount);
        int.TryParse(entry.Amount, NumberStyles.Number, CultureInfo.CurrentCulture.NumberFormat, out editedAmount);
        if (originalAmount != editedAmount) return false;

        return true;
    }
    public bool IsValid() {
        Errors = new List<ValidationError>();
        if (entry.Date is null) {
            Errors.Add(new ValidationError() {
                Head = nameof(entry.Date),
                Error = Constants.CannotBeEmpty
            });
        }
        if (string.IsNullOrWhiteSpace(entry.Party)) {
            Errors.Add(new ValidationError() {
                Head = nameof(entry.Party),
                Error = Constants.CannotBeEmpty
            });
        }
        if (string.IsNullOrWhiteSpace(entry.Head)) {
            Errors.Add(new ValidationError() {
                Head = nameof(entry.Head),
                Error = Constants.CannotBeEmpty
            });
        }

        if (string.IsNullOrWhiteSpace(entry.Amount)) {
            Errors.Add(new ValidationError() {
                Head = nameof(entry.Amount),
                Error = Constants.CannotBeEmpty
            });
        }
        else {
            int x;
            if (!int.TryParse(entry.Amount, NumberStyles.Number, CultureInfo.CurrentCulture.NumberFormat, out x)) {
                Errors.Add(new ValidationError() {
                    Head = nameof(entry.Amount),
                    Error = Constants.IsntValid
                });
            }
            else if (x <= 0) {
                Errors.Add(new ValidationError() {
                    Head = nameof(entry.Amount),
                    Error = Constants.MustBePositive
                });
            }
        }
        return Errors.Count == 0;
    }
    public async Task<bool> Resolve(double left, double top, double width, double height) {
        bool isSuccess = true;
        var request = new CDRMRequest() { UserId = App.service.UserId };
        Response response = null;

        foreach (var e in Errors) {
            switch (e.Head) {
                case "Head": {
                        var name = entry.Head.Trim();
                        request.Method = (int)Function.AddHead;
                        request.Args = new object[] { new NetHead() { Name = name } };
                        response = await App.service.GetResponse(request);
                        if (response.IsSuccess) {
                            entry.HeadId = BitConverter.ToInt32(response.Packet.Skip(1).ToArray());
                            entry.Head = name;
                        }
                        else {
                            isSuccess = false;
                            break;
                        }
                    }
                    break;
                case "Party": {
                        var name = entry.Party.Trim();
                        var dialog = new CreatePartyDialog(left, top, width, height, entry.Party);
                        dialog.ShowDialog();
                        var (address, phone) = dialog.GetAddressAndPhone();
                        var party = new NetParty() {
                            Name = name,
                            Address = address.Trim(),
                            Phone = phone?.Trim()
                        };
                        request.Method = (int)Function.AddParty;
                        request.Args = new object[] { party };
                        response = await App.service.GetResponse(request);
                        if (response.IsSuccess) {
                            entry.PartyId = BitConverter.ToInt32(response.Packet.Skip(1).ToArray());
                            entry.Party = name;
                        }
                        else {
                            isSuccess = false;
                            break;
                        }
                    }
                    break;
            }
        }
        return isSuccess;
    }
}
