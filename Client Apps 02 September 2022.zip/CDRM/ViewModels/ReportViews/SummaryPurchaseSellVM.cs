﻿class SummaryPurchaseSellVM : Notifiable
{
    Type dueType;
    PropertyInfo primaryProperty, secondaryProperty, tertiaryProperty;
    Func<SumPurchaseSell, Due, bool> condition;
    List<Due> dues;
    ObservableCollection<SumPurchaseSell> reportables;
    ObservableCollection<SumPurchaseSellDetail> detail;

    string query;
    public string Query {
        get { return query; }
        set { query = value; Reportables.Refresh(); }
    }
    SumPurchaseSell selected;
    public SumPurchaseSell Selected {
        get { return selected; }
        set { selected = value; makeSubSummary(); }
    }

    public byte IsContruction { get; set; }
    public byte PrimaryGroup { get; set; }
    public byte SecondaryGroup { get; set; }
    public int NoOfSummaryGroup { get; set; }
    public int NoOfDetailGroup { get; set; }
    public int TotalPurchase { get; set; }
    public int TotalSell { get; set; }
    public int TotalDetailPurchase { get; set; }
    public int TotalDetailSell { get; set; }
    public ReportDates Dates { get; set; }
    public ICollectionView Reportables { get; set; }
    public ICollectionView Detail { get; set; }
    public static event Action<ReportDates> Refreshed;
    public event Action CoordinateRequested;

    public SummaryPurchaseSellVM() {
        dueType = typeof(Due);
        dues = new List<Due>();
        reportables = new ObservableCollection<SumPurchaseSell>();
        detail = new ObservableCollection<SumPurchaseSellDetail>();
        getDates();

        Detail = CollectionViewSource.GetDefaultView(detail);
        Detail.GroupDescriptions.Add(new PropertyGroupDescription(nameof(SumPurchaseSellDetail.GroupName)));

        Reportables = CollectionViewSource.GetDefaultView(reportables);
        Reportables.GroupDescriptions.Add(new PropertyGroupDescription(nameof(SumPurchaseSell.GroupName)));
        Reportables.Filter = filter;
        Reportables.CollectionChanged += onCollectionChanged;
    }

    public void Refresh() {
        CoordinateRequested?.Invoke();
        BusyWindow.Activate(SummaryPurchaseSell.LeftOfLeftGrid, SummaryPurchaseSell.TopOfLeftGrid,
            SummaryPurchaseSell.WidthOfLeftGrid, SummaryPurchaseSell.HeightOfLeftGrid, "Refreshing");

        updateReportables();
        setCondition();
        makeSummary();
        if(BusyWindow.IsOpened) BusyWindow.Terminate();
        Refreshed?.Invoke(Dates);
    }
    public void SortReportablesParticulars() => sort(Reportables, nameof(SumPurchaseSell.GroupName), nameof(SumPurchaseSell.Particulars));
    public void SortReportablesPurchase() => sort(Reportables, nameof(SumPurchaseSell.Purchase), nameof(SumPurchaseSell.GroupTotalPurchase));
    public void SortReportablesSell() => sort(Reportables, nameof(SumPurchaseSell.Sell), nameof(SumPurchaseSell.GroupTotalSell));
    public void SortDetailParticulars() => sort(Detail, nameof(SumPurchaseSellDetail.GroupName), nameof(SumPurchaseSellDetail.Date));
    public void SortDetailPurchase() => sort(Detail, nameof(SumPurchaseSellDetail.Purchase), nameof(SumPurchaseSellDetail.GroupTotalPurchase));
    public void SortDetailSell() => sort(Detail, nameof(SumPurchaseSellDetail.Sell), nameof(SumPurchaseSellDetail.GroupTotalSell));

    bool filter(object o) {
        if (string.IsNullOrWhiteSpace(Query)) return true;
        var s = (SumPurchaseSell)o;
        return
            s.Particulars.Contains(Query, StringComparison.InvariantCultureIgnoreCase)
            || s.GroupName.Contains(Query, StringComparison.InvariantCultureIgnoreCase);
    }
    ListSortDirection getDirection(ICollectionView view, string propertyName) {
        var direction = propertyName.Equals(nameof(IPurchaseSell.GroupName)) ?
            ListSortDirection.Ascending :
            ListSortDirection.Descending;
        var description = view.SortDescriptions.FirstOrDefault(x => x.PropertyName.Equals(propertyName));
        if (description.PropertyName is not null) {
            direction = description.Direction == ListSortDirection.Descending ?
                ListSortDirection.Ascending :
                ListSortDirection.Descending;
        }
        return direction;
    }
    void setCondition() {
        var site = dueType.GetProperty(nameof(Due.Site));
        var party = dueType.GetProperty(nameof(Due.Party));
        var head = dueType.GetProperty(nameof(Due.Head));

        switch (PrimaryGroup) {
            case 0: // Site
                primaryProperty = site;
                switch (SecondaryGroup) {
                    case 0: // Party
                        condition = (s, d) => s.GroupName.Equals(d.Site) && s.Particulars.Equals(d.Party);
                        secondaryProperty = party;
                        tertiaryProperty = head;
                        break;
                    default: // Head
                        condition = (s, d) => s.GroupName.Equals(d.Site) && s.Particulars.Equals(d.Head);
                        secondaryProperty = head;
                        tertiaryProperty = party;
                        break;
                }
                break;
            case 1: // Party
                primaryProperty = party;
                switch (SecondaryGroup) {
                    case 0: // Site
                        condition = (s, d) => s.GroupName.Equals(d.Party) && s.Particulars.Equals(d.Site);
                        secondaryProperty = site;
                        tertiaryProperty = head;
                        break;
                    default: // Head
                        condition = (s, d) => s.GroupName.Equals(d.Party) && s.Particulars.Equals(d.Head);
                        secondaryProperty = head;
                        tertiaryProperty = site;
                        break;
                }
                break;
            default: // Head
                primaryProperty = head;
                switch (SecondaryGroup) {
                    case 0: // Party
                        condition = (s, d) => s.GroupName.Equals(d.Head) && s.Particulars.Equals(d.Party);
                        secondaryProperty = party;
                        tertiaryProperty = site;
                        break;
                    default: // Site
                        condition = (s, d) => s.GroupName.Equals(d.Head) && s.Particulars.Equals(d.Site);
                        secondaryProperty = site;
                        tertiaryProperty = party;
                        break;
                }
                break;
        }
    }
    void makeSubSummary() {
        TotalDetailPurchase = TotalDetailSell = 0;
        if (Selected is null) {
            detail.Clear();
            OnPropertyChanged(nameof(TotalDetailPurchase));
            OnPropertyChanged(nameof(TotalDetailSell));
            return;
        }
        CoordinateRequested?.Invoke();
        //BusyWindow.Activate(SummaryPurchaseSell.LeftOfRightBorder, SummaryPurchaseSell.TopOfRightBorder,
        //    SummaryPurchaseSell.WidthOfRightBorder, SummaryPurchaseSell.HeightOfRightBorder, "Refreshing");

        var list = new List<SumPurchaseSellDetail>();

        if (IsContruction > 3 /*All*/) {
            foreach (var item in dues) {
                if (primaryProperty.GetValue(item, null).Equals(Selected.GroupName)
                    && secondaryProperty.GetValue(item, null).Equals(Selected.Particulars)) {
                    var subHead = string.IsNullOrWhiteSpace(item.SubHead) ? "" : (" " + item.SubHead);
                    var qty = item.Quantity == 0 ? "" : (" " + item.Quantity.ToString() + " " + item.Unit);
                    list.Add(new SumPurchaseSellDetail() {
                        Date = item.Date,
                        GroupName = tertiaryProperty.GetValue(item, null).ToString(),
                        Particulars = subHead + qty,
                        Purchase = item.Purchase,
                        Sell = item.Sell,
                        Narration = string.IsNullOrWhiteSpace(item.Narration) ? "narration n/a" : item.Narration
                    });
                    TotalDetailPurchase += item.Purchase;
                    TotalDetailSell += item.Sell;
                }
            }
        }
        else foreach (var item in dues) {
                if (item.IsConstruction != IsContruction) continue;
                if (primaryProperty.GetValue(item, null).Equals(Selected.GroupName)
                    && secondaryProperty.GetValue(item, null).Equals(Selected.Particulars)) {
                    var subHead = string.IsNullOrWhiteSpace(item.SubHead) ? "" : (" " + item.SubHead);
                    var qty = item.Quantity == 0 ? "" : (" " + item.Quantity.ToString() + " " + item.Unit);
                    list.Add(new SumPurchaseSellDetail() {
                        Date = item.Date,
                        GroupName = tertiaryProperty.GetValue(item, null).ToString(),
                        Particulars = subHead + qty,
                        Purchase = item.Purchase,
                        Sell = item.Sell,
                        Narration = string.IsNullOrWhiteSpace(item.Narration) ? "narration n/a" : item.Narration
                    });
                    TotalDetailPurchase += item.Purchase;
                    TotalDetailSell += item.Sell;
                }
            }

        //do you need a Detail.DeferRefresh here?
        detail.Clear();
        foreach (var item in list) {
            var x = list.Where(x => x.GroupName.Equals(item.GroupName)).ToList();
            int currentTotalPurchase = 0;
            int currentTotalSell = 0;
            if (x.Count > 0) {
                foreach (var g in x) {
                    g.GroupTotalPurchase += item.Purchase;
                    g.GroupTotalSell += item.Sell;
                    if (currentTotalPurchase == 0) {
                        currentTotalPurchase = g.GroupTotalPurchase;
                    }
                    if (currentTotalSell == 0) {
                        currentTotalSell = g.GroupTotalSell;
                    }
                }
                item.GroupTotalPurchase = currentTotalPurchase;
                item.GroupTotalSell = currentTotalSell;
            }
            else {
                item.GroupTotalPurchase = item.Purchase;
                item.GroupTotalSell = item.Sell;
            }
            detail.Add(item);
        }

        NoOfDetailGroup = Detail.Groups.Count;
        OnPropertyChanged(nameof(NoOfDetailGroup));
        OnPropertyChanged(nameof(TotalDetailPurchase));
        OnPropertyChanged(nameof(TotalDetailSell));
        //BusyWindow.Terminate();
    }
    void makeSummary() {
        List<SumPurchaseSell> sums = new();
        SumPurchaseSell group = null;

        if (IsContruction > 3 /*All*/) {
            foreach (var item in dues) {
                group = sums.FirstOrDefault(x => condition.Invoke(x, item));
                if (group is null) {
                    var e = new SumPurchaseSell() {
                        GroupName = primaryProperty.GetValue(item, null).ToString(),
                        Particulars = secondaryProperty.GetValue(item, null).ToString(),
                        Purchase = item.Purchase,
                        Sell = item.Sell
                    };
                    sums.Add(e);
                }
                else {
                    group.Sell += item.Sell;
                    group.Purchase += item.Purchase;
                }
            }
        }
        else {
            foreach (var item in dues) {
                if (item.IsConstruction != IsContruction) continue;
                group = sums.FirstOrDefault(x => condition.Invoke(x, item));
                if (group is null) {
                    var e = new SumPurchaseSell() {
                        GroupName = primaryProperty.GetValue(item, null).ToString(),
                        Particulars = secondaryProperty.GetValue(item, null).ToString(),
                        Purchase = item.Purchase,
                        Sell = item.Sell
                    };
                    sums.Add(e);
                }
                else {
                    group.Sell += item.Sell;
                    group.Purchase += item.Purchase;
                }
            }
        }
        using (Reportables.DeferRefresh()) {
            Reportables.CollectionChanged -= onCollectionChanged;
            Reportables.Filter = null;
            reportables.Clear();
        }
        TotalPurchase = TotalSell = 0;

        foreach (var item in sums) {
            TotalPurchase += item.Purchase;
            TotalSell += item.Sell;
            var x = reportables.Where(x => x.GroupName.Equals(item.GroupName)).ToList();
            int currentTotalPurchase = 0;
            int currentTotalSell = 0;
            if (x.Count > 0) {
                foreach (var g in x) {
                    g.GroupTotalPurchase += item.Purchase;
                    g.GroupTotalSell += item.Sell;
                    if (currentTotalPurchase == 0) {
                        currentTotalPurchase = g.GroupTotalPurchase;
                    }
                    if (currentTotalSell == 0) {
                        currentTotalSell = g.GroupTotalSell;
                    }
                }
                item.GroupTotalPurchase = currentTotalPurchase;
                item.GroupTotalSell = currentTotalSell;
            }
            else {
                item.GroupTotalPurchase = item.Purchase;
                item.GroupTotalSell = item.Sell;
            }
            reportables.Add(item);
        }
        Reportables.Filter = filter;
        Reportables.CollectionChanged += onCollectionChanged;
        NoOfSummaryGroup = Reportables.Groups.Count;
        TotalDetailPurchase = TotalDetailSell = 0;

        OnPropertyChanged(nameof(TotalPurchase));
        OnPropertyChanged(nameof(TotalSell));
        OnPropertyChanged(nameof(NoOfSummaryGroup));
        OnPropertyChanged(nameof(TotalDetailPurchase));
        OnPropertyChanged(nameof(TotalDetailSell));
    }
    async void getDates() {
        var request = new CDRMRequest() {
            UserId = App.service.UserId,
            Method = (int)Function.GetDates
        };
        var response = await App.service.GetResponse(request);
        if (!response.IsSuccess) {
            //message
            return;
        }
        await convertDates(response.Packet);
    }
    Task convertDates(byte[] packet) {
        var bytes = new ReadOnlySpan<byte>(packet);
        int read, start, index;
        start = read = index = 0;
        var segments = new string[4];
        while (read < bytes.Length) {
            if (bytes[read] != 0) {
                read++;
                continue;
            }
            segments[index++] = Encoding.ASCII.GetString(bytes.Slice(start, read - start));
            if (index == segments.Length) break;
            start = ++read;
        }
        Dates = new ReportDates() {
            From = DateTime.ParseExact(segments[0], "yyyy-MM-dd", CultureInfo.CurrentCulture.DateTimeFormat),
            Start = DateTime.ParseExact(segments[1], "yyyy-MM-dd", CultureInfo.CurrentCulture.DateTimeFormat),
            To = DateTime.ParseExact(segments[2], "yyyy-MM-dd", CultureInfo.CurrentCulture.DateTimeFormat),
            End = DateTime.ParseExact(segments[3], "yyyy-MM-dd", CultureInfo.CurrentCulture.DateTimeFormat)
        };
        return Task.CompletedTask;
    }
    Task addInDues(byte[] packet) {
        var bytes = new ReadOnlySpan<byte>(packet);
        int read, start, index;
        start = read = index = 0;
        var segments = new string[7];

        while (read < bytes.Length) {
            var isSell = bytes.Slice(start, 1)[0];
            var isConstruction = bytes.Slice(start + 1, 1)[0];
            var purchase = BitConverter.ToInt32(bytes.Slice(start + 2, 4));
            var sell = BitConverter.ToInt32(bytes.Slice(start + 6, 4));
            var quantity = BitConverter.ToDouble(bytes.Slice(start + 10, 8));
            read += 18;
            start += 18;
            while (read < bytes.Length) {
                if (bytes[read] != 0) {
                    read++;
                    continue;
                }
                segments[index++] = Encoding.ASCII.GetString(bytes.Slice(start, read - start));
                if (index == segments.Length) break;
                start = ++read;
            }
            dues.Add(new Due() {
                IsSell = isSell,
                IsConstruction = isConstruction,
                Purchase = purchase,
                Sell = sell,
                Quantity = quantity,
                Date = DateTime.ParseExact(segments[0], "yyyy-MM-dd", CultureInfo.CurrentCulture.DateTimeFormat),
                Site = segments[1],
                Party = segments[2],
                Head = segments[3],
                SubHead = segments[4],
                Unit = segments[5],
                Narration = segments[6]
            });
            index = 0;
            start = ++read;
        }
        return Task.CompletedTask;
    }
    async void updateReportables() {
        dues.Clear();
        var request = new CDRMRequest() {
            UserId = App.service.UserId,
            Method = (int)Function.GetPurchaseSell,
            Args = new object[]{
                Dates.From.Value.ToString("yyyy-MM-dd"),
                Dates.To.Value.ToString("yyyy-MM-dd"),
            }
        };
        var response = await App.service.GetResponse(request);
        if (!response.IsSuccess) {
            BusyWindow.Terminate();
            InfoDialog.Activate("Summary", LocalConstants.ServiceDown);
            return;
        }
        await addInDues(response.Packet);
    }
    void onCollectionChanged(object? sender, NotifyCollectionChangedEventArgs e) {
        TotalPurchase = TotalSell = 0;
        foreach (SumPurchaseSell item in Reportables) {
            TotalPurchase += item.Purchase;
            TotalSell += item.Sell;
        }
        OnPropertyChanged(nameof(TotalPurchase));
        OnPropertyChanged(nameof(TotalSell));
    }
    void sort(ICollectionView view, string directionalProperty, string property) {
        if (view.IsEmpty) return;
        var direction = getDirection(view, directionalProperty);
        using (view.DeferRefresh()) {
            view.SortDescriptions.Clear();
            if (directionalProperty.Equals(nameof(IPurchaseSell.GroupName))) {
                view.SortDescriptions.Add(new SortDescription(directionalProperty, direction));
                view.SortDescriptions.Add(new SortDescription(property, direction));
            }
            else {
                view.SortDescriptions.Add(new SortDescription(property, direction));
                view.SortDescriptions.Add(new SortDescription(directionalProperty, direction));
            }
        }
    }
}
