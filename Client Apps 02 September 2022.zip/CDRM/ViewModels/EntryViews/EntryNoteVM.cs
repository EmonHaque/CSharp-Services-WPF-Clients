﻿class EntryNoteVM : Notifiable
{
    public double Top { get; set; }
    public double Left { get; set; }
    public double Width { get; set; }
    public double Height { get; set; }

    public EntryNoteText Entry { get; set; }
    string siteAddress;
    public string SiteAddress {
        get { return siteAddress; }
        set { siteAddress = value; OnPropertyChanged(nameof(SiteAddress)); }
    }
    public event Action CoordinateRequested;

    public EntryNoteVM() {
        Entry = new EntryNoteText() { Date = DateTime.Today };
    }

    public async void AddEntry() {
        var validator = new NoteValidator(Entry);
        if (!validator.IsValid()) {
            CoordinateRequested?.Invoke();
            var errorDialog = new ErrorDialog(Left, Top, Width, Height, validator.Errors);
            errorDialog.ShowDialog();
            return;
        }
        if (!validator.DoesExist()) {
            CoordinateRequested?.Invoke();
            var confirmDialog = new ConfirmCreationDialog(Left, Top, Width, Height, validator.Errors);
            var result = confirmDialog.ShowDialog();
            if (!result.HasValue) return;
            if (!result.Value) return;

            var isSuccess = await validator.Resolve(Left, Top, Width, Height);
            if (!isSuccess) {
                InfoDialog.Activate("Creation", LocalConstants.ServiceDown);
                return;
            }
        }
        var note = new NetNote() {
            Date = Entry.Date.Value.ToString("yyyy-MM-dd"),
            Entry = Entry.Entry,
            NoteTypeId = Entry.NoteTypeId,
            SiteId = Entry.SiteId
        };
        var request = new CDRMRequest() { 
            UserId = App.service.UserId,
            Method = (int)Function.AddNote,
            Args = new object[] { note }
        };
        var response = await App.service.GetResponse(request);
        if (!response.IsSuccess) {
            InfoDialog.Activate("Creation", LocalConstants.ServiceDown);
            return;
        }
        Entry = new EntryNoteText() { Date = DateTime.Today };
        OnPropertyChanged(nameof(Entry));
    }
    public void SetSiteAddress() {
        if (string.IsNullOrWhiteSpace(Entry.Site)) {
            SiteAddress = null;
            return;
        }
        var site = AppData.sites.FirstOrDefault(x => x.Name.Equals(Entry.Site, StringComparison.InvariantCultureIgnoreCase));
        if (site is null) {
            SiteAddress = null;
            return;
        }
        SiteAddress = site.Address;
    }  
}
