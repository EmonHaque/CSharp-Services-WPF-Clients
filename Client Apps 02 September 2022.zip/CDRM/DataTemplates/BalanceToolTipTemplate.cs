﻿class BalanceToolTipTemplate : DataTemplate
{
    public BalanceToolTipTemplate() {
        var grid = new FrameworkElementFactory(typeof(Grid)) { Name = "grid"};
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col3 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var head = new FrameworkElementFactory(typeof(TextBlock));
        var purchase = new FrameworkElementFactory(typeof(TextBlock));
        var sell = new FrameworkElementFactory(typeof(TextBlock));

        col2.SetValue(ColumnDefinition.WidthProperty, new GridLength(Constants.AmountColumnWidth));
        col3.SetValue(ColumnDefinition.WidthProperty, new GridLength(Constants.AmountColumnWidth));
        purchase.SetValue(Grid.ColumnProperty, 1);
        sell.SetValue(Grid.ColumnProperty, 2);
        purchase.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
        sell.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);

        head.SetBinding(TextBlock.TextProperty, new Binding(nameof(SumTransaction.Head)));
        purchase.SetBinding(TextBlock.TextProperty, new Binding(nameof(SumTransaction.PurchaseReceipt)) { StringFormat = Constants.NumberFormat });
        sell.SetBinding(TextBlock.TextProperty, new Binding(nameof(SumTransaction.SellPayment)) { StringFormat = Constants.NumberFormat });

        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(col3);
        grid.AppendChild(head);
        grid.AppendChild(purchase);
        grid.AppendChild(sell);
        VisualTree = grid;

        Triggers.Add(new Trigger() {
            Property = ItemsControl.AlternationIndexProperty,
            Value = 1,
            Setters = {
                new Setter(Grid.BackgroundProperty, Constants.BackgroundDark, "grid")
            }
        });
    }
}

