﻿class RPToolTipTemplate : DataTemplate
{
    public RPToolTipTemplate() {
        var grid = new FrameworkElementFactory(typeof(Grid)) { Name = "grid"};
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col3 = new FrameworkElementFactory(typeof(ColumnDefinition)) ;
        var col4 = new FrameworkElementFactory(typeof(ColumnDefinition)) { Name = "col4" };
        var col5 = new FrameworkElementFactory(typeof(ColumnDefinition)) { Name = "col5" };
        var date = new FrameworkElementFactory(typeof(TextBlock));
        var icon = new FrameworkElementFactory(typeof(PathIcon));
        var head = new FrameworkElementFactory(typeof(TextBlock));
        var payment = new FrameworkElementFactory(typeof(TextBlock));
        var receipt = new FrameworkElementFactory(typeof(TextBlock));

        col2.SetValue(ColumnDefinition.WidthProperty, GridLength.Auto);
        col4.SetValue(ColumnDefinition.WidthProperty, new GridLength(Constants.AmountColumnWidth));
        col5.SetValue(ColumnDefinition.WidthProperty, new GridLength(Constants.AmountColumnWidth));
        icon.SetValue(Grid.ColumnProperty, 1);
        head.SetValue(Grid.ColumnProperty, 2);
        payment.SetValue(Grid.ColumnProperty, 3);
        receipt.SetValue(Grid.ColumnProperty, 4);
        icon.SetValue(PathIcon.MarginProperty, new Thickness(5, 0, 5, 0));
        payment.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
        receipt.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
        date.SetBinding(TextBlock.TextProperty, new Binding(nameof(RPToolTipEntry.Date)) { StringFormat = "dd MMM yyyy"});
        icon.SetBinding(PathIcon.IconProperty, new Binding(nameof(RPToolTipEntry.IsCash)) { Converter = Converters.isCash2Icon });
        icon.SetBinding(PathIcon.FillProperty, new Binding(nameof(RPToolTipEntry.IsCash)) { Converter = Converters.isCash2Fill});
        head.SetBinding(TextBlock.TextProperty, new Binding(nameof(RPToolTipEntry.Head)));
        payment.SetBinding(TextBlock.TextProperty, new Binding(nameof(RPToolTipEntry.Payment)) { StringFormat = Constants.NumberFormat});
        receipt.SetBinding(TextBlock.TextProperty, new Binding(nameof(RPToolTipEntry.Receipt)) { StringFormat = Constants.NumberFormat });

        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(col3);
        grid.AppendChild(col4);
        grid.AppendChild(col5);
        grid.AppendChild(date);
        grid.AppendChild(icon);
        grid.AppendChild(head);
        grid.AppendChild(payment);
        grid.AppendChild(receipt);
        VisualTree = grid;

        Triggers.Add(new Trigger() {
            Property = ItemsControl.AlternationIndexProperty,
            Value = 1,
            Setters = {
                new Setter(Grid.BackgroundProperty, Constants.BackgroundDark, "grid")
            }
        });
        //Triggers.Add(new DataTrigger() {
        //    Binding = new Binding(nameof(SumReceiptPayment.Payment)),
        //    Value = 0,
        //    Setters = {
        //        new Setter(ColumnDefinition.WidthProperty, new GridLength(0), "col4")
        //    }
        //});
        //Triggers.Add(new DataTrigger() {
        //    Binding = new Binding(nameof(SumReceiptPayment.Receipt)),
        //    Value = 0,
        //    Setters = {
        //        new Setter(ColumnDefinition.WidthProperty, new GridLength(0), "col5")
        //    }
        //});
    }
}
