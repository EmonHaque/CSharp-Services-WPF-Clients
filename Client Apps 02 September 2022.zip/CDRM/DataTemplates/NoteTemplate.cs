﻿class NoteTemplate : DataTemplate
{
    public NoteTemplate() {
        var grid = new FrameworkElementFactory(typeof(Grid));
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var date = new FrameworkElementFactory(typeof(TextBlock));
        var note = new FrameworkElementFactory(typeof(TextBox));

        col1.SetValue(ColumnDefinition.WidthProperty, GridLength.Auto);
        note.SetValue(Grid.ColumnProperty, 1);
        note.SetValue(TextBox.MarginProperty, new Thickness(5, 0, 0, 0));
        note.SetValue(TextBox.MaxLinesProperty, 2);
        note.SetValue(TextBox.TextWrappingProperty, TextWrapping.Wrap);
        note.SetValue(TextBox.IsEnabledProperty, false);
        note.SetValue(TextBox.BorderThicknessProperty, new Thickness(0));
        note.SetValue(TextBox.ForegroundProperty, Brushes.LightGray);
        date.SetValue(TextBlock.FontWeightProperty, FontWeights.Bold);
        date.SetBinding(TextBlock.TextProperty, new Binding(nameof(EntryNoteText.Date)) { StringFormat = "dd MMM yyyy" });
        note.SetBinding(TextBox.TextProperty, new Binding(nameof(EntryNoteText.Entry)));

        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(date);
        grid.AppendChild(note);

        VisualTree = grid;
    }
}
