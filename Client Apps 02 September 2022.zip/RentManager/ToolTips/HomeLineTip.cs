﻿class HomeLineTip : ToolTip
{
    public HomeLineTip(DepositDueRent data) {
        var header = new TextBlock() { FontSize = 16 };
        var divider = new Separator() { Background = Brushes.LightGray };
        FrameworkElement receivables = null;

        var footer = new TextBlock() {
            Margin = new Thickness(0, 10, 0, 0),
            HorizontalAlignment = HorizontalAlignment.Right,
            FontStyle = FontStyles.Italic,
            Visibility = Visibility.Collapsed
        };

        header.Text = AppData.tenants.First(x => x.Id == data.TenantId).Name;
        if (data.State == DepositDueRentState.Rent) {
            receivables = new ItemsControl() {
                Margin = new Thickness(2, 0, 2, 0),
                ItemTemplate = new ReceivableTemplate()
            };
            var lease = AppData.leases.FirstOrDefault(x => x.TenantId == data.TenantId && x.SpaceId == data.SpaceId && !x.IsExpired);
            if (lease is null) return;
            footer.Text = "since " + lease.DateStart.Value.ToString("dd MMMM yyyy");
            ((ItemsControl)receivables).ItemsSource = lease.FixedReceivables;
            footer.Visibility = Visibility.Visible;
        }
        else if (data.State == DepositDueRentState.Deposit) {
            receivables = new Grid() {
                Children = {
                    new TextBlock(){Text = "Security Deposit"},
                    new TextBlock(){
                        Text = data.Amount.ToString("N0"),
                        HorizontalAlignment = HorizontalAlignment.Right
                    }
                }
            };
        }
        else {
            receivables = new Grid() {
                Children = {
                    new TextBlock(){Text = "Due"},
                    new TextBlock(){
                        Text = data.Amount.ToString("N0"),
                        HorizontalAlignment = HorizontalAlignment.Right
                    }
                }
            };
        }
        Grid.SetRow(divider, 1);
        Grid.SetRow(receivables, 2);
        Grid.SetRow(footer, 3);
        Content = new Grid() {
            MinWidth = 175,
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(),
                new RowDefinition(){ Height = GridLength.Auto },
            },
            Children = { header, divider, receivables, footer },
            Resources = {{
                    typeof(TextBlock),
                    new Style() {
                        Setters = {
                            new Setter(TextBlock.ForegroundProperty, Brushes.LightGray)
                        }
                    }
                }
            }
        };
    }
}
