﻿class ReportMonthlyBalanceVM : Notifiable
{
    DateTime lastDayOfPreviousMonth, firstDayOfPreviousMonth, lastDayOfSelectedMonth;
    ObservableCollection<MonthlyBalance> payments;
    byte state;
    public byte State {
        get { return state; }
        set { state = value; Payments.Refresh(); }
    }
    string status;
    public string Status {
        get { return status; }
        set { status = value; OnPropertyChanged(nameof(Status)); }
    }

    public double Top { get; set; }
    public double Left { get; set; }
    public double Width { get; set; }
    public double Height { get; set; }

    public int TotalDue { get; set; }
    public int TotalLastDue { get; set; }
    public int TotalPaid { get; set; }
    public int TotalShort { get; set; }
    public ICollectionView Payments { get; set; }
    public Action Refresh { get; set; }
    public DateTime SelectedDate { get; set; }
    public event Action CoordinateRequested;

    public ReportMonthlyBalanceVM() {
        payments = new ObservableCollection<MonthlyBalance>();
        Payments = CollectionViewSource.GetDefaultView(payments);
        Payments.GroupDescriptions.Add(new PropertyGroupDescription(nameof(MonthlyBalance.Plot)));
        Payments.Filter = filter;
        Payments.CollectionChanged += onCollectionChanged;

        SelectedDate = DateTime.Today;
        lastDayOfPreviousMonth = SelectedDate.AddMonths(-1);
        var lastDay = DateTime.DaysInMonth(lastDayOfPreviousMonth.Year, lastDayOfPreviousMonth.Month);
        lastDayOfPreviousMonth = new DateTime(lastDayOfPreviousMonth.Year, lastDayOfPreviousMonth.Month, lastDay);
        firstDayOfPreviousMonth = new DateTime(lastDayOfPreviousMonth.Year, lastDayOfPreviousMonth.Month, 1);
        lastDay = DateTime.DaysInMonth(SelectedDate.Year, SelectedDate.Month);
        lastDayOfSelectedMonth = new DateTime(SelectedDate.Year, SelectedDate.Month, lastDay);

        getData();
        Refresh = refresh;
    }

    bool filter(object o) {
        var p = (MonthlyBalance)o;

        switch (state) {
            case 0: return true;
            case 1: return p.Payment != 0;
            default: return (p.Payment == 0 || p.ShortOrLong != 0) && p.Due != 0;
        }
    }
    void onCollectionChanged(object? sender, NotifyCollectionChangedEventArgs e) {
        TotalDue = TotalLastDue = TotalPaid = TotalShort = 0;
        foreach (MonthlyBalance item in Payments) {
            TotalDue += item.Due;
            TotalLastDue += item.LastMonthDue;
            TotalPaid += item.Payment;
            TotalShort += item.ShortOrLong;
        }
        OnPropertyChanged(nameof(TotalDue));
        OnPropertyChanged(nameof(TotalLastDue));
        OnPropertyChanged(nameof(TotalPaid));
        OnPropertyChanged(nameof(TotalShort));
    }

    async void refresh() {
        CoordinateRequested?.Invoke();
        BusyWindow.Activate(Left, Top, Width, Height, "Reloading ...");

        lastDayOfPreviousMonth = SelectedDate.AddMonths(-1);
        var lastDay = DateTime.DaysInMonth(lastDayOfPreviousMonth.Year, lastDayOfPreviousMonth.Month);
        lastDayOfPreviousMonth = new DateTime(lastDayOfPreviousMonth.Year, lastDayOfPreviousMonth.Month, lastDay);
        firstDayOfPreviousMonth = new DateTime(lastDayOfPreviousMonth.Year, lastDayOfPreviousMonth.Month, 1);
        lastDay = DateTime.DaysInMonth(SelectedDate.Year, SelectedDate.Month);
        lastDayOfSelectedMonth = new DateTime(SelectedDate.Year, SelectedDate.Month, lastDay);

        await getData();
        BusyWindow.Terminate();
    }
    async Task getData() {
        Status = "requesting data";
        var request = new RentManagerRequest() {
            UserId = App.service.UserId,
            Method = (int)Function.GetMonthlyBalance,
            Args = new object[] {
                firstDayOfPreviousMonth.ToString("yyyy-MM-dd"),
                lastDayOfPreviousMonth.ToString("yyyy-MM-dd"),
                lastDayOfSelectedMonth.ToString("yyyy-MM-dd")
            }
        };
        var response = await App.service.GetResponse(request);
        await Task.Delay(500);
        if (!response.IsSuccess) {
            Status = LocalConstants.DownMessage;
            return;
        }
        Status = $"received {response.Packet.Length.ToString("N0")} bytes";
        await Task.Delay(500);
        await addEntries(response.Packet);
    }
    Task addEntries(byte[] packet) {
        payments.Clear();
        var span = new ReadOnlySpan<byte>(packet);
        int start, index, read;
        start = read = index = 0;
        var segments = new string[3];

        while (read < span.Length) {
            while (read < span.Length) {
                if (span[read] != 0) {
                    read++;
                    continue;
                }
                segments[index++] = Encoding.ASCII.GetString(span.Slice(start, read - start));
                start = ++read;
                if (index == segments.Length) break;
            }
            int lastDue = BitConverter.ToInt32(span.Slice(start + 4));
            int payment = BitConverter.ToInt32(span.Slice(start + 8));
            payments.Add(new MonthlyBalance() {
                Date = segments[0],
                Plot = segments[1],
                Tenant = segments[2],
                Due = BitConverter.ToInt32(span.Slice(start)),
                LastMonthDue = lastDue,
                Payment = payment,
                ShortOrLong = lastDue - payment
            });
            index = 0;
            read += 12;
            start = read;
        }
        return Task.CompletedTask;
    }
}
