﻿class BulkRentTransactionVM : Notifiable
{
    List<Lease> activeLeases;
    string narration, chargeDate;
    public string ErrorMonth { get; set; }
    public bool IsValid { get; set; }
    public ICollectionView Leases { get; set; }
    public Action PassEntries { get; set; }
    DateTime? month;
    public DateTime? Month {
        get { return month; }
        set {
            if (month != value) {
                month = value;
                validate();
            }
        }
    }
    List<Lease> excluededLeases;
    public List<Lease> ExcludedLeases {
        get { return excluededLeases; }
        set {
            if (excluededLeases != value) {
                excluededLeases = value;
                validate();
            }
        }
    }
    string filterName;
    public string FilterName {
        get { return filterName; }
        set {
            if (filterName != value) {
                filterName = value?.Trim().ToLower();
                Leases.Refresh();
            }
        }
    }

    public BulkRentTransactionVM() {
        Leases = new CollectionViewSource() {
            Source = AppData.leases,
            IsLiveFilteringRequested = true,
            LiveFilteringProperties = { nameof(Lease.IsExpired) },
            IsLiveSortingRequested = true,
            LiveSortingProperties = { nameof(Lease.SpaceName) },
            IsLiveGroupingRequested = true,
            LiveGroupingProperties = { nameof(Lease.PlotName) }
        }.View;
        activeLeases = new List<Lease>();
        ExcludedLeases = new List<Lease>();

        Leases.GroupDescriptions.Add(new PropertyGroupDescription(nameof(Lease.PlotName)));
        Leases.SortDescriptions.Add(new SortDescription(nameof(Lease.SpaceName), ListSortDirection.Ascending));
        Leases.Filter = filter;
        PassEntries = passEntries;
        ErrorMonth = " is required";
    }

    void validate() {
        ErrorMonth = Month == null ? " is required" : string.Empty;
        OnPropertyChanged(nameof(ErrorMonth));
        //activeLeases computation could be moved to the filter function
        activeLeases = AppData.leases.Where(x => !x.IsExpired).ToList();
        IsValid =
            !Leases.IsEmpty &&
            Month != null &&
            ExcludedLeases.Count < activeLeases.Count;
        OnPropertyChanged(nameof(IsValid));
    }
    bool filter(object o) {
        var lease = (Lease)o;
        if (string.IsNullOrWhiteSpace(FilterName)) return !lease.IsExpired;
        return
            !lease.IsExpired &&
            (ExcludedLeases.Contains(lease) ||
            lease.TenantName.ToLower().Contains(FilterName) ||
            lease.PlotName.ToLower().Contains(FilterName) ||
            lease.SpaceName.ToLower().Contains(FilterName));
    }
    async void passEntries() {
        if (ExcludedLeases.Count > 0)
            activeLeases = activeLeases.Except(ExcludedLeases).ToList();

        narration = CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(month.Value.Month) + ", " + Month.Value.Year;
        ConfirmDialog.Activate("Rent", $"Rent for {activeLeases.Count} spaces for the month of {narration} will be sent");

        if (ConfirmDialog.IsOk) {
            chargeDate = new DateTime(Month.Value.Year, month.Value.Month, DateTime.DaysInMonth(Month.Value.Year, month.Value.Month)).ToString("yyyy-MM-dd");
            List<NetTransaction> transactions = new();
            foreach (var lease in activeLeases) {
                foreach (var receivable in lease.FixedReceivables) {
                    transactions.Add(new NetTransaction() {
                        PlotId = lease.PlotId.Value,
                        SpaceId = lease.SpaceId.Value,
                        TenantId = lease.TenantId.Value,
                        ControlId = AppData.controlIdOfReceivable.Value,
                        HeadId = receivable.HeadId.Value,
                        Amount = receivable.Amount,
                        Date = chargeDate,
                        Narration = narration,
                        IsCash = 1
                    });
                }
            }
            var request = new RentManagerRequest() {
                UserId = App.service.UserId,
                Method = (int)Function.AddBulkRent,
                Args = new object[] { transactions }
            };
            var response = await App.service.GetResponse(request);
            if (response.IsSuccess) {
                var isSuccess = BitConverter.ToBoolean(response.Packet);
                if (!isSuccess) {
                    var message = Encoding.ASCII.GetString(response.Packet.Skip(1).ToArray());
                    InfoDialog.Activate("Rent", message);
                }
                else {
                    InfoDialog.Activate("Rent", $"Rent for {activeLeases.Count} spaces for the month of {narration} has been charged");
                    Month = null;
                    OnPropertyChanged(nameof(Month));
                }
            }
            else {
                InfoDialog.Activate("Service", "Couldn't connect to service, try restrating the Application");
            }
        }
    }

}
