﻿abstract class AddBase<T> : Notifiable where T : Notifiable, new()
{
    public T TObject { get; set; }
    public Action Add { get; set; }
    public AddBase() {
        TObject = new T();
        Add = addTObject;
    }
    protected abstract ObservableCollection<T> collection { get; }

    protected abstract void insertInDatabase();
    protected abstract void renewTObject();
    void addTObject() {
        insertInDatabase();
        renewTObject();
    }
    protected void handleResponse(Response response, string header) {
        if (response.IsSuccess) {
            var isSuccess = BitConverter.ToBoolean(response.Packet);
            if (!isSuccess) {
                var message = Encoding.ASCII.GetString(response.Packet.Skip(1).ToArray());
                InfoDialog.Activate(header, message);
            }
        }
        else {
            InfoDialog.Activate("Service", "Couldn't connect to service, try restrating the Application");
        }
    }
}
