﻿class PlotWiseDue
{
    public string Month { get; set; }
    public string Tenant { get; set; }
    public int Due { get; set; }
}
