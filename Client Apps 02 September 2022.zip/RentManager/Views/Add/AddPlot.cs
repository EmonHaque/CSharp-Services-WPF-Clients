﻿class AddPlot : CardView
{
    public override string Header => "Plot";
    EditText name, description;
    CommandButton button;
    AddPlotVM viewModel;

    public override void OnFirstSight() {
        base.OnFirstSight();
        viewModel = new AddPlotVM();
        DataContext = viewModel;
        initializeUI();
        bind();
    }
    void initializeUI() {
        name = new EditText() {
            Hint = "Name",
            IsRequired = true,
            Icon = Icons.Plot
        };
        description = new EditText() {
            Hint = "Description",
            IsMultiline = true,
            IsRequired = true,
            MaxLength = 100,
            Icon = Icons.Description
        };
        button = new CommandButton() {
            Width = 14,
            Height = 14,
            Icon = Icons.Add,
            Command = viewModel.Add,
            HorizontalAlignment = HorizontalAlignment.Right
        };
        Grid.SetRow(description, 1);
        Grid.SetRow(button, 2);
        var grid = new Grid() {
            Margin = new Thickness(0, 2, 0, 0),
            RowDefinitions = {
                    new RowDefinition() { Height = GridLength.Auto },
                    new RowDefinition(),
                    new RowDefinition() { Height = GridLength.Auto },
                },
            Children = { name, description, button }
        };
        setContent(grid);
    }
    void bind() {
        name.SetBinding(EditText.TextProperty, new Binding($"{nameof(viewModel.TObject)}.{nameof(Plot.Name)}"));
        name.SetBinding(EditText.ErrorProperty, new Binding(nameof(viewModel.ErrorName)));
        description.SetBinding(EditText.TextProperty, new Binding($"{nameof(viewModel.TObject)}.{nameof(Plot.Description)}"));
        description.SetBinding(EditText.ErrorProperty, new Binding(nameof(viewModel.ErrorDescription)));
        button.SetBinding(IsEnabledProperty, new Binding(nameof(viewModel.IsValid)));
    }
}
