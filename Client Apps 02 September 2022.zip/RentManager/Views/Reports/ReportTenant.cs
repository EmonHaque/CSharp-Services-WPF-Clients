﻿class ReportTenant : LedgerView
{
    public override string Icon => Icons.Tenant;
    public override string Header => "Tenant";
    ReportTenantVM vm;
    DataTemplate dTemplate;
    protected override ReportBase viewModel => vm;
    protected override DataTemplate template => dTemplate;
    protected override void initialize() {
        vm = new ReportTenantVM();
        dTemplate = new TenantTemplate(nameof(vm.Query), vm, true);
    }
}
