﻿class Rent : CardView
{
    public override string Header => "Rent, Deposit & Dues";
    ActionButton refresh;
    PieChart pie;
    MultiState state;
    TextBlock status;
    RentVM viewModel;

    public override void OnFirstSight() {
        base.OnFirstSight();
        viewModel = new RentVM();
        DataContext = viewModel;
        initializeUI();
        bind();
    }
    async void refreshCommand() {
        if (BusyWindow.IsOpened) return;
        var position = PointToScreen(new Point(0, 0));
        var dpi = VisualTreeHelper.GetDpi(this);
        position.X /= dpi.DpiScaleX;
        position.Y /= dpi.DpiScaleY;
        position.X += Constants.CardMargin;
        position.Y += Constants.CardMargin;
        var width = ActualWidth - 2 * Constants.CardMargin;
        var height = ActualHeight - 2 * Constants.CardMargin;

        BusyWindow.Activate(position.X, position.Y, width, height, "Reloading ...");
        viewModel.Refresh.Invoke();
        BusyWindow.Terminate();
    }
    void initializeUI() {
        status = new TextBlock() {
            Margin = new Thickness(0, 0, 10, 0),
            VerticalAlignment = VerticalAlignment.Center
        };
        state = new MultiState() {
            HorizontalAlignment = HorizontalAlignment.Right,
            Icons = new string[] { Icons.Rent, Icons.Deposit, Icons.Due },
            Texts = new string[] { "Rent", "Deposit", "Due" }
        };
        refresh = new ActionButton() {
            Command = refreshCommand,
            Icon = Icons.Refresh,
            ToolTip = "Reload",
            Margin = new Thickness(5, 0, 0, 0)
        };
        addActions(new UIElement[] { status, state, refresh });
        pie = new PieChart() { SelectedValuePath = nameof(PlotSummary.Id) };
        setContent(pie);
    }
    void bind() {
        status.SetBinding(TextBlock.TextProperty, new Binding(nameof(viewModel.Status)));
        pie.SetBinding(PieChart.ItemsSourceProperty, new Binding(nameof(viewModel.Summary)));
        pie.SetBinding(PieChart.SelectedValueProperty, new Binding(nameof(viewModel.Selected)));
        state.SetBinding(MultiState.StateProperty, new Binding(nameof(viewModel.State)));
    }
}
