﻿class MultiLineChart : Panel
{
    int numSteps = 10;
    bool hasData;
    double x1Max, x2Max;
    Size bottomLabelDesired, sideLabelDesired;
    StackPanel infoPanel;
    TextBlock noInfoBlock, nameBlock, sumBlock;

    public MultiLineChart() {
        LayoutTransform = new ScaleTransform() { ScaleY = -1 };
        noInfoBlock = new TextBlock() {
            TextAlignment = TextAlignment.Center,
            FontSize = 18,
            FontWeight = FontWeights.Bold,
            Foreground = Brushes.Gray,
            Inlines = {
                    new Run(){ Text = "No data"},
                    new LineBreak(),
                    new Run(){ Text = "available" }
                },
            LayoutTransform = new ScaleTransform() { ScaleY = -1 }
        };
        nameBlock = new TextBlock() {
            Tag = "Info",
            IsHitTestVisible = false,
            FontWeight = FontWeights.Bold,
            HorizontalAlignment = HorizontalAlignment.Right
        };
        sumBlock = new TextBlock() {
            Tag = "Info",
            IsHitTestVisible = false,
            FontStyle = FontStyles.Italic,
            HorizontalAlignment = HorizontalAlignment.Right,
            TextAlignment = TextAlignment.Right
        };
        infoPanel = new StackPanel() {
            Children = { sumBlock, nameBlock },
            LayoutTransform = new ScaleTransform() { ScaleY = -1 }
        };
    }
    void addLabel(string date) {
        var label = new TextBlock() {
            Tag = "Label",
            Text = date,
            IsHitTestVisible = false,
            TextAlignment = TextAlignment.Right,
            Padding = new Thickness(0, 0, 5, 0),
            RenderTransform = new TransformGroup() {
                Children = {
                            new ScaleTransform() { ScaleY = -1 },
                            new RotateTransform() { Angle = 90 }
                        }
            }
        };
        Children.Add(label);
        label.Measure(new Size(double.PositiveInfinity, double.PositiveInfinity));
        if (label.DesiredSize.Width > bottomLabelDesired.Width)
            bottomLabelDesired = label.DesiredSize;
        //label.Loaded += animateLabels;
    }
    void addLine() {
        var line = new Line() {
            StrokeThickness = 1,
            Stroke = Brushes.LightGray,
            StrokeDashCap = PenLineCap.Flat,
            StrokeDashArray = new DoubleCollection(new List<double> { 3, 3 }),
            IsHitTestVisible = false
        };
        Children.Add(line);
        SetZIndex(line, 1);
        //line.Loaded += animateLines;
    }
    void addX1Tick(double value) {
        var tick = new TextBlock() {
            Tag = "x1Tick",
            Text = value.ToString("N0"),
            HorizontalAlignment = HorizontalAlignment.Left,
            RenderTransform = new TransformGroup() {
                Children = {
                            new ScaleTransform() { ScaleY = - 1 },
                            new TranslateTransform()
                        }
            },
            IsHitTestVisible = false
        };
        Children.Add(tick);
        //tick.Loaded += animateTicks;
    }
    void addX2Tick(double value) {
        var tick = new TextBlock() {
            Tag = "x2Tick",
            Text = value.ToString("N0"),
            HorizontalAlignment = HorizontalAlignment.Right,
            RenderTransform = new TransformGroup() {
                Children = {
                            new ScaleTransform() { ScaleY = - 1 },
                            new TranslateTransform()
                        }
            },
            IsHitTestVisible = false
        };
        Children.Add(tick);
        //tick.Loaded += animateTicks;
    }
    void addSideLables() {
        var x1Label = new TextBlock() {
            Tag = "x1Label",
            Text = "Collections",
            FontSize = 14,
            FontWeight = FontWeights.Bold,
            Foreground = Brushes.Gray,
            Padding = new Thickness(0, 0, 0, 5),
            RenderTransform = new RotateTransform(90),
            LayoutTransform = new ScaleTransform() { ScaleY = -1 },
            TextAlignment = TextAlignment.Center

        };
        var x2Label = new TextBlock() {
            Tag = "x2Label",
            Text = "Charges",
            FontSize = 14,
            FontWeight = FontWeights.Bold,
            Foreground = Brushes.Gray,
            Padding = new Thickness(0, 0, 0, 5),
            RenderTransform = new RotateTransform(-90),
            LayoutTransform = new ScaleTransform() { ScaleY = -1 },
            TextAlignment = TextAlignment.Center
        };
        Children.Add(x1Label);
        Children.Add(x2Label);
        x1Label.Measure(new Size(double.PositiveInfinity, double.PositiveInfinity));
        x2Label.Measure(new Size(double.PositiveInfinity, double.PositiveInfinity));
        sideLabelDesired.Width = x1Label.DesiredSize.Width > x2Label.DesiredSize.Width ? x1Label.DesiredSize.Width : x2Label.DesiredSize.Width;
        sideLabelDesired.Height = x1Label.DesiredSize.Height > x2Label.DesiredSize.Height ? x1Label.DesiredSize.Height : x2Label.DesiredSize.Height;
    }
    void generateChart(List<PlotwiseRent> list) {
        bottomLabelDesired = new Size(0, 0);
        x1Max = x2Max = 0;
        int cash, mobile, kind, rent, numMonths;
        cash = mobile = kind = rent = numMonths = 0;
        var months = list.Select(x => x.Month).Distinct();
        var rentList = new List<int>();
        foreach (var month in months) {
            var tenants = list.Where(x => string.Equals(x.Month, month)).ToList();
            Pin pin = new(tenants);
            Children.Add(pin);
            SetZIndex(pin, 3);
            addLabel(month);
            var totalRent = tenants.Sum(x => x.Rent);
            var totalCash = tenants.Sum(x => x.Cash);
            var totalMobile = tenants.Sum(x => x.Mobile);
            var totalKind = tenants.Sum(x => x.Kind);
            cash += totalCash;
            mobile += totalMobile;
            kind += totalKind;
            rent += totalRent;
            numMonths++;
            rentList.Add(totalRent);
            var collectionTotal = totalCash + totalMobile + totalKind;
            if (collectionTotal > x1Max) x1Max = collectionTotal;
            if (totalRent > x2Max) x2Max = totalRent;
        }
        var path = new LineStream(rentList);
        Children.Add(path);
        SetZIndex(path, 2);
        sumBlock.Inlines.Clear();
        nameBlock.Text = " in " + list.First().Plot;
        var rentRun = new Run() {
            Text = $"Rent {rent.ToString("N0")} charged"
        };
        var collectionRun = new Run();
        string text = "";
        if (cash != 0) text += "Cash: " + cash.ToString("N0");
        if (mobile != 0) text += ", Mobile: " + mobile.ToString("N0");
        if (kind != 0) text += ", Kind: " + kind.ToString("N0");

        if (cash != 0 && mobile != 0 && kind != 0) text += ", Total: " + (cash + mobile + kind).ToString("N0");

        text += " paid in " + numMonths + " month";
        collectionRun.Text = text;
        sumBlock.Inlines.Add(rentRun);
        sumBlock.Inlines.Add(new LineBreak());
        sumBlock.Inlines.Add(collectionRun);
        Children.Add(infoPanel);

        double pinStep = x1Max / (numSteps - 1);
        double lineStep = x2Max / (numSteps - 1);
        var pinCurrent = 0d;
        var lineCurrent = 0d;
        for (int i = 0; i < 10; i++) {
            addLine();
            addX1Tick(pinCurrent);
            addX2Tick(lineCurrent);
            pinCurrent += pinStep;
            lineCurrent += lineStep;
        }
        addSideLables();
    }
    protected override Size ArrangeOverride(Size finalSize) {
        if (finalSize.Width < 20 || finalSize.Height == 0) return finalSize;
        if (!hasData) {
            noInfoBlock.Measure(finalSize);
            var center = new Point(finalSize.Width / 2, finalSize.Height / 2);
            var point = new Point(center.X - noInfoBlock.DesiredSize.Width / 2, center.Y - noInfoBlock.DesiredSize.Height / 2);
            noInfoBlock.Arrange(new Rect(point, noInfoBlock.DesiredSize));
            return finalSize;
        }
        var x1Tick = new TextBlock() { Text = x1Max.ToString("N0") };
        var x2Tick = new TextBlock() { Text = x2Max.ToString("N0") };
        x1Tick.Measure(finalSize);
        x2Tick.Measure(finalSize);
        var labelHeight = bottomLabelDesired.Width;

        infoPanel.Width = finalSize.Width - x2Tick.DesiredSize.Height;
        infoPanel.Measure(finalSize);
        infoPanel.Arrange(new Rect(new Point(0, finalSize.Height - infoPanel.DesiredSize.Height), infoPanel.DesiredSize));

        var bars = Children.OfType<Pin>().Count();
        var x1TickSpace = x1Tick.DesiredSize.Width + sideLabelDesired.Height;
        var x2TickSpace = x2Tick.DesiredSize.Width + sideLabelDesired.Height;
        var pinWidth = (finalSize.Width - x1TickSpace - x2TickSpace) / bars;

        var remainingHeight = finalSize.Height - labelHeight - x1Tick.DesiredSize.Height - infoPanel.DesiredSize.Height;
        var lineSpace = remainingHeight / (numSteps - 1);
        var availableHeight = remainingHeight /*/ numsteps * (numsteps - 1)*/;
        var barSpace = x1TickSpace;
        var labelSpace = x1TickSpace + pinWidth / 2 - bottomLabelDesired.Height / 2;
        var y = labelHeight;
        var pinTickY = labelHeight;
        var linetickY = labelHeight;
        var availableWidth = finalSize.Width - x1Tick.DesiredSize.Width - x2Tick.DesiredSize.Width - pinWidth - 2 * sideLabelDesired.Height;

        if (availableWidth < 5 || availableHeight < 5) return finalSize;
        foreach (UIElement item in Children) {
            if (item is Pin) {
                var rect = (Pin)item;
                rect.upperBound = x1Max;
                rect.Measure(new Size(pinWidth, availableHeight));
                rect.Arrange(new Rect(new Point(barSpace, labelHeight), rect.DesiredSize));
                barSpace += pinWidth;
            }
            else if (item is LineStream) {
                var path = (LineStream)item;
                path.SetParameters(availableWidth, availableHeight, 0d, x2Max, pinWidth);
                path.Arrange(new Rect(new Point(x1Tick.DesiredSize.Width + pinWidth / 2 + sideLabelDesired.Height, labelHeight), path.DesiredSize));
            }
            else if (item is Line) {
                var line = (Line)item;
                line.X1 = sideLabelDesired.Height;
                line.X2 = finalSize.Width - sideLabelDesired.Height;
                line.Y1 = line.Y2 = y;
                item.Measure(finalSize);
                item.Arrange(new Rect(item.DesiredSize));
                y += lineSpace;
            }
            else if (item is TextBlock) {
                var block = (TextBlock)item;
                if (string.Equals(block.Tag.ToString(), "x1Tick")) {
                    block.Measure(finalSize);
                    block.Arrange(new Rect(new Point(sideLabelDesired.Height, pinTickY + block.DesiredSize.Height), block.DesiredSize));
                    pinTickY += lineSpace;
                }
                else if (string.Equals(block.Tag.ToString(), "x2Tick")) {
                    block.Measure(finalSize);
                    block.Arrange(new Rect(new Point(finalSize.Width - block.DesiredSize.Width - sideLabelDesired.Height, linetickY + block.DesiredSize.Height), block.DesiredSize));
                    linetickY += lineSpace;
                }
                else if (string.Equals(block.Tag.ToString(), "Label")) {
                    block.Width = bottomLabelDesired.Width;
                    block.Measure(finalSize);
                    block.Arrange(new Rect(new Point(labelSpace, 0), block.DesiredSize));
                    labelSpace += pinWidth;
                }
                else if (string.Equals(block.Tag.ToString(), "x1Label")) {
                    block.Width = remainingHeight;
                    block.Measure(finalSize);
                    block.Arrange(new Rect(new Point(block.DesiredSize.Height, labelHeight), block.DesiredSize));
                }
                else if (string.Equals(block.Tag.ToString(), "x2Label")) {
                    block.Width = remainingHeight;
                    block.Measure(finalSize);
                    block.Arrange(new Rect(new Point(finalSize.Width - block.DesiredSize.Height, labelHeight + remainingHeight), block.DesiredSize));
                }
            }
        }

        return finalSize;
    }

    public IEnumerable ItemsSource {
        get { return (IEnumerable)GetValue(ItemsSourceProperty); }
        set { SetValue(ItemsSourceProperty, value); }
    }
    public static readonly DependencyProperty ItemsSourceProperty =
        DependencyProperty.Register("ItemsSource", typeof(IEnumerable), typeof(MultiLineChart), new FrameworkPropertyMetadata() {
            DefaultValue = null,
            PropertyChangedCallback = onSourceChanged,
            AffectsArrange = true
        });

    static void onSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
        var o = d as MultiLineChart;
        o.Children.Clear();
        if (e.NewValue != null) {
            var list = ((IEnumerable<PlotwiseRent>)e.NewValue).ToList();
            o.hasData = list.Count > 0;
            if (o.hasData) o.generateChart(list);
            else o.Children.Add(o.noInfoBlock);
        }
        else {
            o.hasData = false;
            o.Children.Add(o.noInfoBlock);
        }
    }
}
