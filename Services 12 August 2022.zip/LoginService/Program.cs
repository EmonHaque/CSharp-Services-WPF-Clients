IHost host = Host.CreateDefaultBuilder(args)
    .UseWindowsService()
    .ConfigureServices(services => {
        services.AddHostedService<LoginWorker>();
    })
    .Build();

await host.RunAsync();
