IHost host = Host.CreateDefaultBuilder(args)
    .ConfigureServices(services =>
    {
        services.AddHostedService<InstallWorker>();
    })
    .Build();

await host.RunAsync();
