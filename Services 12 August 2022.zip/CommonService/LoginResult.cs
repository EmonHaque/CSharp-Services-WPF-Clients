﻿public class LoginResult
{
    public Role Role { get; set; }
    public int UserId { get; set; }
    public bool IsSuccess { get; set; }

    public List<ArraySegment<byte>> GetBytes() {
        var role = BitConverter.GetBytes((int)Role);
        var id = BitConverter.GetBytes(UserId);
        var status = BitConverter.GetBytes(IsSuccess);
        var size = BitConverter.GetBytes(role.Length + id.Length + status.Length);
        return new List<ArraySegment<byte>>() { size, role, id, status };
    }
    public static LoginResult FromBytes(byte[] array) {
        var span = new ReadOnlySpan<byte>(array);
        var level = BitConverter.ToInt32(span.Slice(0, 4));
        var id = BitConverter.ToInt32(span.Slice(4, 4));
        var status = BitConverter.ToBoolean(span.Slice(8, 1));
        return new LoginResult() {
            Role = (Role)level,
            UserId = id,
            IsSuccess = status
        };
    }
}
