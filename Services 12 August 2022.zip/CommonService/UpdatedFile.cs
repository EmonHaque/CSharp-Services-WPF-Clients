﻿public class UpdatedFile
{
    public int Size { get; set; }
    public string Name { get; set; }
    public byte[] Content { get; set; }

    public byte[] GetBytes() {
        var name = Encoding.ASCII.GetBytes(Name + '\0');
        var size = BitConverter.GetBytes(name.Length + Content.Length);
        var length = name.Length + size.Length + Content.Length;

        var array = new byte[length];
        int start = 0;
        size.CopyTo(array, start);
        start += size.Length;
        name.CopyTo(array, start);
        start += name.Length;
        Content.CopyTo(array, start);
        return array;
    }
    public static UpdatedFile FromBytes(byte[] array) {
        int start = 0;
        while (true) {
            if (array[start] != 0) {
                start++;
                continue;
            }
            break;
        }
        return new UpdatedFile() {
            Name = Encoding.ASCII.GetString(array.Take(start).ToArray()),
            Content = array.Skip(start + 1).ToArray()
        };
    }
}
