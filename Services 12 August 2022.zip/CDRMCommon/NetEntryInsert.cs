﻿public class NetEntryInsert
{
    public bool IsPS { get; set; }
    public byte IsCash { get; set; }
    public byte IsSell { get; set; }
    public byte IsConstruction { get; set; }
    public byte IsReceipt { get; set; }   
    public int Amount { get; set; }
    public int SiteId { get; set; }
    public int PartyId { get; set; }
    public int HeadId { get; set; }
    public int SubHeadId { get; set; }
    public int UnitId { get; set; }
    public double Quantity { get; set; }
    public string Date { get; set; }
    public string Narration { get; set; }   

    public List<ArraySegment<byte>> GetBytes() {
        return new List<ArraySegment<byte>>() {
            BitConverter.GetBytes(IsPS),
            new byte[1]{ IsCash },
            new byte[1]{ IsSell },
            new byte[1]{ IsConstruction },
            new byte[1]{ IsReceipt },
            BitConverter.GetBytes(Amount),
            BitConverter.GetBytes(SiteId),
            BitConverter.GetBytes(PartyId),
            BitConverter.GetBytes(HeadId),
            BitConverter.GetBytes(SubHeadId),
            BitConverter.GetBytes(UnitId),
            BitConverter.GetBytes(Quantity),
            Encoding.ASCII.GetBytes(Date + '\0'),
            Encoding.ASCII.GetBytes(Narration + '\0')
        };
    }
}
