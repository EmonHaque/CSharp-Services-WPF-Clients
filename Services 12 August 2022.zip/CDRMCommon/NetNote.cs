﻿public class NetNote
{
    public int Id { get; set; }
    public int SiteId { get; set; }
    public int NoteTypeId { get; set; }
    public string Date { get; set; }
    public string Entry { get; set; }

    public List<ArraySegment<byte>> GetBytes() {
        return new List<ArraySegment<byte>>() {
            BitConverter.GetBytes(Id),
            BitConverter.GetBytes(SiteId),
            BitConverter.GetBytes(NoteTypeId),
            Encoding.ASCII.GetBytes(Date + '\0'),
            Encoding.ASCII.GetBytes(Entry + '\0')
        };
    }
    public static NetNote FromBytes(ReadOnlySpan<byte> array) {
        int start, read, index;
        start = read = 12;
        index = 0;
        var segments = new string[2];
        while (read < array.Length) {
            if (array[read] != 0) {
                read++;
                continue;
            }
            segments[index++] = Encoding.ASCII.GetString(array.Slice(start, read - start));
            start = ++read;
            if (index == segments.Length) break;
        }
        return new NetNote() {
            Id = BitConverter.ToInt32(array.Slice(0, 4)),
            SiteId = BitConverter.ToInt32(array.Slice(4, 4)),
            NoteTypeId = BitConverter.ToInt32(array.Slice(8, 4)),
            Date = segments[0],
            Entry = segments[1]
        };
    }
}
