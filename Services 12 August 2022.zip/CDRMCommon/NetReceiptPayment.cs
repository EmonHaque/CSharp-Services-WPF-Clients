﻿public class NetReceiptPayment
{
    public int Payment { get; set; }
    public int Receipt { get; set; }
    public byte IsCash { get; set; }
    public string Date { get; set; }
    public string Party { get; set; }
    public string Head { get; set; }
    public string Narration { get; set; }
    public string Month { get; set; }
   
    public List<ArraySegment<byte>> GetBytes() {
        return new List<ArraySegment<byte>>() {
            BitConverter.GetBytes(Payment),
            BitConverter.GetBytes(Receipt),
            new byte[1]{ IsCash },
            Encoding.ASCII.GetBytes(Date + '\0'),
            Encoding.ASCII.GetBytes(Party + '\0'),
            Encoding.ASCII.GetBytes(Head + '\0'),
            Encoding.ASCII.GetBytes(Narration + '\0'),
            Encoding.ASCII.GetBytes(Month + '\0')
        };
    }
}
