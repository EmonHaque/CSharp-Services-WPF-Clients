﻿public class NetSite
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string Address { get; set; }

    public List<ArraySegment<byte>> GetBytes() {
        return new List<ArraySegment<byte>>() {
            BitConverter.GetBytes(Id),
            Encoding.ASCII.GetBytes(Name + '\0'),
            Encoding.ASCII.GetBytes(Address + '\0')
        };
    }
    public static NetSite FromBytes(ReadOnlySpan<byte> array) {
        int read, start, index;
        index = 0;
        read = start = 4;
        var segments = new string[2];
        while (read < array.Length) {
            if (array[read] != 0) {
                read++;
                continue;
            }
            segments[index++] = Encoding.ASCII.GetString(array.Slice(start, read - start));
            start = ++read;
            if (index == segments.Length) break;
        }
        return new NetSite() {
            Id = BitConverter.ToInt32(array.Slice(0, 4)),
            Name = segments[0],
            Address = segments[1]
        };
    }
}
