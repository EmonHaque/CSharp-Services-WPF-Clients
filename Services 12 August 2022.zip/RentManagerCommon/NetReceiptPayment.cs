﻿public class NetReceiptPayment
{
    public string Control { get; set; }
    public string Head { get; set; }
    public string Plot { get; set; }
    public string Tenant { get; set; }
    public string Space { get; set; }
    public int Cash { get; set; }
    public int Mobile { get; set; }
    public int Kind { get; set; }
    public int Total { get; set; }

    public List<ArraySegment<byte>> GetBytes() {
        var segments =  new List<ArraySegment<byte>>() {
            Encoding.ASCII.GetBytes(Control + '\0'),
            Encoding.ASCII.GetBytes(Head + '\0'),
            Encoding.ASCII.GetBytes(Plot + '\0'),
            Encoding.ASCII.GetBytes(Tenant + '\0'),
            Encoding.ASCII.GetBytes(Space + '\0'),
            BitConverter.GetBytes(Cash),
            BitConverter.GetBytes(Mobile),
            BitConverter.GetBytes(Kind),
            BitConverter.GetBytes(Total)
        };
        int total = segments.Sum(x => x.Count);
        segments.Insert(0, BitConverter.GetBytes(total));
        return segments;
    }
    public static NetReceiptPayment FromBytes(ReadOnlySpan<byte> bytes) {
        int start, read, index;
        start = read = index = 0;
        var segments = new string[5];
        while (read < bytes.Length) {
            if (bytes[read] != 0) {
                read++;
                continue;
            }
            segments[index++] = Encoding.ASCII.GetString(bytes.Slice(start, read - start));
            start = ++read;
            if (index == segments.Length) break;
        }
        return new NetReceiptPayment() {
            Control = segments[0],
            Head = segments[1],
            Plot = segments[2],
            Tenant = segments[3],
            Space = segments[4],
            Cash = BitConverter.ToInt32(bytes.Slice(start, 4)),
            Mobile = BitConverter.ToInt32(bytes.Slice(start + 4, 4)),
            Kind = BitConverter.ToInt32(bytes.Slice(start + 8, 4)),
            Total = BitConverter.ToInt32(bytes.Slice(start + 12, 4))
        };
    }
}
