﻿public class NetPlot
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string Description { get; set; }

    public List<ArraySegment<byte>> GetBytes() {
        return new List<ArraySegment<byte>>() {
            BitConverter.GetBytes(Id),
            Encoding.ASCII.GetBytes(Name + '\0'),
            Encoding.ASCII.GetBytes(Description + '\0')
        };
    }
    public static NetPlot FromBytes(ReadOnlySpan<byte> array) {
        int start = 0;
        int read = 0;
        int id = BitConverter.ToInt32(array.Slice(start, 4));
        read += 4;
        start = read;

        while (array[read] != 0) read++;
        var name = Encoding.ASCII.GetString(array.Slice(start, read - start));

        start = ++read;
        while (array[read] != 0) read++;
        var description = Encoding.ASCII.GetString(array.Slice(start, read - start));

        return new NetPlot() {
            Id = id,
            Name = name,
            Description = description
        };
    }
}
