#define _CRT_SECURE_NO_WARNINGS
#pragma comment (lib, "Ws2_32.lib")
#include "Program.h"

#pragma region variables
wchar_t SERVICE_NAME[10];
SERVICE_STATUS g_ServiceStatus = { 0 };
SERVICE_STATUS_HANDLE g_StatusHandle = NULL;
HANDLE g_ServiceStopEvent = INVALID_HANDLE_VALUE;
SOCKET server;
CRITICAL_SECTION criticalClient;
byte isRunning;
HANDLE serviceThread, acceptClientThread;
List clients, apps;
#pragma endregion

int main() {
#ifdef _DEBUG
	Initialize();
	g_ServiceStopEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	serviceThread = CreateThread(NULL, 0, ServiceWorker, NULL, 0, NULL);
	WaitForSingleObject(serviceThread, INFINITE);
#else
	SERVICE_TABLE_ENTRY entry[] = {
		{SERVICE_NAME, (LPSERVICE_MAIN_FUNCTION)ServiceMain},
		{NULL, NULL}
	};
	StartServiceCtrlDispatcher(entry);
#endif
	return 0;
}
void ServiceMain(ulong argc, ulong* argv) {
	OnStarting();
	Initialize();
	// Create a service stop event to wait on later
	g_ServiceStopEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	OnStarted();
	// Start a thread that will perform the main task of the service
	serviceThread = CreateThread(NULL, 0, ServiceWorker, NULL, 0, NULL);
	// Wait until our worker thread exits signaling that the service needs to stop
	WaitForSingleObject(serviceThread, INFINITE);
	//Perform any cleanup tasks
	CloseHandle(g_ServiceStopEvent);
	onStopped();
}
void ServiceCtrlHandler(ulong code) {
	switch (code) {
		case SERVICE_CONTROL_STOP:
			if (g_ServiceStatus.dwCurrentState != SERVICE_RUNNING)
				break;
			//Perform tasks necessary to stop the service here
			Cleanup();
			OnStopping();
			// This will signal the worker thread to start shutting down
			SetEvent(g_ServiceStopEvent);
			break;
	}
}
ulong ServiceWorker(void* p) {
	//  Periodically check if the service has been requested to stop
	while (WaitForSingleObject(g_ServiceStopEvent, 0) != WAIT_OBJECT_0)
		//Perform main service function here
		AcceptClient();

	return 0;
}
ulong HandleRequest(void* p) {
	SOCKET client = p;
	char header[4];
	int packetSize, read, newRead;
	char* packet = { 0 };

	read = recv(client, header, 4, 0);
	if (read < 0) goto onDisconnect;
	while (read < 4) {
		newRead = recv(client, &header[read], 4 - read, 0);
		if (newRead < 0) goto onDisconnect;
		read += newRead;
	}
	memcpy(&packetSize, header, 4);

	packet = malloc(packetSize);
	read = newRead = 0;
	while (read < packetSize) {
		newRead = recv(client, packet, packetSize - read, 0);
		if (newRead < 0) goto onDisconnect;
		read += newRead;
	}
	char* app = packet;
	char* version = packet + strlen(app) + 1;

	byte hasUpdate = 0;
	AppInfo** infos = apps.data;
	AppInfo* info = { 0 };
	for (int i = 0; i < apps.count; i++) {
		if (strcmp(infos[i]->appName, app) == 0) {
			if (strcmp(infos[i]->version, version) != 0) {
				hasUpdate = 1;
				info = infos[i];
				break;
			}
		}
	}
	if (hasUpdate) {
		sendByte(client, hasUpdate);
		sendInt(client, info->totalSize);
		AppFile** fileList = info->fileList.data;
		for (int i = 0; i < info->fileList.count; i++) {
			int size = fileList[i]->fileLength + strlen(fileList[i]->fileName) + 1;
			sendInt(client, size);
			sendString(client, fileList[i]->fileName);

			char fileBuffer[1024];
			int read = 0;
			FILE* f = fopen(fileList[i]->filePath, "rb");
			while ((read = fread(fileBuffer, 1, sizeof(fileBuffer), f)) > 0) {
				int sent = 0;
				do {
					sent = send(client, fileBuffer, read, 0);
					if (sent == SOCKET_ERROR) break;
					read -= sent;
				} while (read > 0);
				if (sent == SOCKET_ERROR) break;
			}
			fclose(f);
		}
	}

onDisconnect:
	if (packet) free(packet);

	EnterCriticalSection(&criticalClient);
	Client** list = clients.data;
	Client* c = 0;
	for (int i = 0; i < clients.count; i++) {
		if (list[i]->socket == client) {
			c = list[i];
			break;
		}
	}
	shutdown(client, SD_BOTH);
	closesocket(client);

	CloseHandle(c->thread); // do you've to CloseHandle when it exits?
	//HANDLE thisThread = GetCurrentThread();
	//CloseHandle(thisThread) // this has no effect? if it's you don't have to maintain a client list and critical section
	removeFromList(&clients, c);
	free(c);
	LeaveCriticalSection(&criticalClient);

	return 0;
}

int mallocate(char* src, char** dst) {
	int length = strlen(src) + 1;
	*dst = malloc(length);
	memcpy(*dst, src, length - 1);
	(*dst)[length - 1] = 0;
	return length;
}
void populateAppList() {
	FILE* fp = fopen("C:/Users/Emon/Desktop/AppRepo/applist.txt", "r");
	char line[500];
	int index, read, length;
	char* token;
	char* tokens[3];
	while ((fgets(line, sizeof line, fp)) != 0) {
		read = 0;
		index = 0;
		while (index < 3) {
			token = strtok(line + read, ",");
			length = strlen(token);
			if (index == 2 && token[length - 1] == '\n') {
				token[length - 1] = 0;
			}
			tokens[index] = token;
			index++;
			read += length + 2;
		}
		AppInfo* info = malloc(APP_INFO_SIZE);
		mallocate(tokens[0], &info->appName);
		mallocate(tokens[1], &info->version);
		mallocate(tokens[2], &info->repository);
		List fileList = { 0, 10, malloc(10 * POINTER_SIZE) };

		WIN32_FIND_DATAA fdFile;
		HANDLE hFind = NULL;
		char sPath[2048];
		sprintf(sPath, "%s/*.*", info->repository);
		hFind = FindFirstFileA(sPath, &fdFile);
		info->totalSize = 0;
		do {
			if (strcmp(fdFile.cFileName, ".") != 0
				&& strcmp(fdFile.cFileName, "..") != 0) {
				info->totalSize += fdFile.nFileSizeLow + strlen(fdFile.cFileName) + 1 + 4;
				sprintf(sPath, "%s/%s", info->repository, fdFile.cFileName);

				AppFile* file = malloc(APP_FILE_SIZE);
				mallocate(fdFile.cFileName, &file->fileName);
				mallocate(sPath, &file->filePath);
				file->fileLength = fdFile.nFileSizeLow;
				addToList(&fileList, file);
			}
		} while (FindNextFileA(hFind, &fdFile));
		FindClose(hFind);

		info->fileList = fileList;
		addToList(&apps, info);
	}
	fclose(fp);
}
void OnStarting() {
	// Register our service control handler with the SCM
	g_StatusHandle = RegisterServiceCtrlHandler(SERVICE_NAME, ServiceCtrlHandler);
	// Tell the service controller we are starting
	ZeroMemory(&g_ServiceStatus, sizeof(g_ServiceStatus));
	g_ServiceStatus.dwServiceType = SERVICE_WIN32_OWN_PROCESS;
	g_ServiceStatus.dwControlsAccepted = 0;
	g_ServiceStatus.dwCurrentState = SERVICE_START_PENDING;
	g_ServiceStatus.dwWin32ExitCode = 0;
	g_ServiceStatus.dwServiceSpecificExitCode = 0;
	g_ServiceStatus.dwCheckPoint = 0;
	SetServiceStatus(g_StatusHandle, &g_ServiceStatus);
}
void OnStarted() {
	// Tell the service controller we are started
	g_ServiceStatus.dwControlsAccepted = SERVICE_ACCEPT_STOP;
	g_ServiceStatus.dwCurrentState = SERVICE_RUNNING;
	g_ServiceStatus.dwWin32ExitCode = 0;
	g_ServiceStatus.dwCheckPoint = 0;
	SetServiceStatus(g_StatusHandle, &g_ServiceStatus);
}
void OnStopping() {
	g_ServiceStatus.dwControlsAccepted = 0;
	g_ServiceStatus.dwCurrentState = SERVICE_STOP_PENDING;
	g_ServiceStatus.dwWin32ExitCode = 0;
	g_ServiceStatus.dwCheckPoint = 4;
	SetServiceStatus(g_StatusHandle, &g_ServiceStatus);
}
void onStopped() {
	// Tell the service controller we are stopped
	g_ServiceStatus.dwControlsAccepted = 0;
	g_ServiceStatus.dwCurrentState = SERVICE_STOPPED;
	g_ServiceStatus.dwWin32ExitCode = 0;
	g_ServiceStatus.dwCheckPoint = 3;
	SetServiceStatus(g_StatusHandle, &g_ServiceStatus);
}
void Initialize() {
	WSADATA w;
	WSAStartup(MAKEWORD(2, 2), &w);
	SOCKADDR_IN address = { AF_INET, htons(5555) };
	InetPton(AF_INET, L"127.0.0.1", &address.sin_addr.s_addr);
	server = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	bind(server, &address, sizeof(address));
	listen(server, SOMAXCONN);
	isRunning = 1;

	clients.capacity = 5;
	clients.count = 0;
	clients.data = malloc(clients.capacity * CLIENT_SIZE);

	apps.capacity = 5;
	apps.count = 0;
	apps.data = malloc(apps.capacity * APP_INFO_SIZE);
	populateAppList();
	InitializeCriticalSection(&criticalClient);
}
void AcceptClient() {
	while (isRunning) {
		SOCKADDR_IN from;
		int length = sizeof(from);
		SOCKET client = accept(server, &from, &length);
		//char ipv4[INET_ADDRSTRLEN];
		//inet_ntop(AF_INET, &(from.sin_addr), ipv4, INET_ADDRSTRLEN);
		BOOL b = TRUE;
		setsockopt(client, IPPROTO_TCP, TCP_NODELAY, &b, sizeof(BOOL));

		EnterCriticalSection(&criticalClient);
		HANDLE requestThread = CreateThread(NULL, 0, HandleRequest, client, 0, NULL);
		Client* c = malloc(CLIENT_SIZE);
		c->socket = client;
		c->thread = requestThread;
		addToList(&clients, c);
		LeaveCriticalSection(&criticalClient);
	}
}
void Cleanup() {
	isRunning = 0;
	closesocket(server);
	WSACleanup();
}