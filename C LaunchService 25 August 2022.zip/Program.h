#pragma once
#include <winsock2.h>
#include <ws2tcpip.h>
#include <Windows.h>
#include <tchar.h>
#include <stdio.h>
#include "Defined.h"
#include "List.h"
#include "Structures.h"
#include "Messenger.h"

extern wchar_t SERVICE_NAME[10];
extern SERVICE_STATUS g_ServiceStatus;
extern SERVICE_STATUS_HANDLE g_StatusHandle;
extern HANDLE g_ServiceStopEvent;

extern SOCKET server;
extern byte isRunning;
extern HANDLE serviceThread, acceptClientThread;
extern List clients, apps;

void ServiceMain(ulong, ulong*);
void ServiceCtrlHandler(ulong);
ulong ServiceWorker(void*);
ulong HandleRequest(void*);

void OnStarting();
void Initialize();
void OnStarted();
void AcceptClient();
void Cleanup();
void OnStopping();
void onStopped();

int mallocate(char*, char**);
void populateAppList();