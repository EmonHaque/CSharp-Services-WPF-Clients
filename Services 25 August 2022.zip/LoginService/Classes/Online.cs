﻿class Online
{
    public int Id { get; set; }
    public Login Login { get; set; }
    public SocketAsyncEventArgs Args { get; set; }
    public DateTime Time { get; set; }
}
