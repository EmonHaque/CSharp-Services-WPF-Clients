﻿class Address
{
    public int Id { get; set; }
    public string IP { get; set; }
}
