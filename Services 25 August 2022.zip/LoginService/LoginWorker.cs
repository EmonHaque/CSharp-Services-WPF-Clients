public class LoginWorker : IHostedService
{
    bool isRunning;
    const string DB = @"data source = C:\Users\Emon\Desktop\Logins.db";
    object sqlKey;
    int maxAttempt;
    Socket server;
    SqliteCommand command;
    SqliteConnection connection;
    List<Login> logins;
    List<Online> onlines;
    List<App> apps;
    List<Address> addresses;
    BlockingCollection<Attempt> attempts;

    void getData() {
        command.CommandText = @"SELECT * FROM Logins; 
                                SELECT * FROM Apps;
                                SELECT * From Addresses;
                                SELECT MAX(Id) FROM Attempts";
        var reader = command.ExecuteReader();
        while (reader.Read()) {
            logins.Add(new Login() {
                Id = reader.GetInt32(0),
                Name = reader.GetString(1),
                UserName = reader.GetString(2),
                Password = reader.GetString(3),
                Role = (Role)reader.GetInt32(4),
                IsActive = reader.GetBoolean(5)
            });
        }
        reader.NextResult();
        while (reader.Read()) {
            apps.Add(new App() {
                Id = reader.GetInt32(0),
                Name = reader.GetString(1)
            });
        }
        reader.NextResult();
        while (reader.Read()) {
            addresses.Add(new Address() {
                Id = reader.GetInt32(0),
                IP = reader.GetString(1)
            });
        }
        reader.NextResult();
        reader.Read();
        maxAttempt = reader.IsDBNull(0) ? 0 : reader.GetInt32(0);

        reader.Close();
        reader.DisposeAsync();
    }
    void accept() {
        var e = new SocketAsyncEventArgs();
        e.Completed += onAccepted;
        bool started = server.AcceptAsync(e);
        if (!started) onAccepted(null, e);
    }
    void onAccepted(object sender, SocketAsyncEventArgs e) {
        if (e.SocketError == SocketError.Success) {
            e.Completed -= onAccepted;
            e.Completed += onReceived;
            bool started = e.AcceptSocket.ReceiveAsync(e);
            if (!started) onReceived(null, e);
            accept();
        }
        else if (e.SocketError == SocketError.OperationAborted) {
            e.Completed -= onAccepted;
            e.Dispose();
            accept();
        }
    }
    void onReceived(object? sender, SocketAsyncEventArgs e) {
        var header = new byte[4];
        if (e.SocketError == SocketError.Success) {
            e.Completed -= onReceived;
            e.Completed += onSent;

            int read = e.AcceptSocket.Receive(header);
            while (read < header.Length) {
                read += e.AcceptSocket.Receive(header, read, header.Length - read, SocketFlags.None);
            }
            var packet = new byte[BitConverter.ToInt32(header)];
            read = e.AcceptSocket.Receive(packet);
            while (read < packet.Length) {
                read += e.AcceptSocket.Receive(packet, read, packet.Length - read, SocketFlags.None);
            }
            handleRequest(User.FromBytes(packet), e);
        }
    }  
    void onSent(object? sender, SocketAsyncEventArgs e) {
        e.Completed -= onSent;
        var result = (LoginResult)e.UserToken;
        e.AcceptSocket.Send(result.GetBytes());

        if (!result.IsSuccess)  {
            e.AcceptSocket.Shutdown(SocketShutdown.Both);
            e.AcceptSocket.Close();
            e.AcceptSocket.Dispose();
        }
        else {
            e.Completed += onDisconnected;
            bool started = e.AcceptSocket.ReceiveAsync(e);
            if (!started) onDisconnected(null, e);
        }
    }
    void onDisconnected(object? sender, SocketAsyncEventArgs e) {
        e.Completed -= onDisconnected;
        Online online = null;
        for (int i = 0; i < onlines.Count; i++) {
            if (onlines[i].Args.Equals(e)) {
                online = onlines[i];
                break;
            }
        }
        onlines.Remove(online);
        online.Args.AcceptSocket.Shutdown(SocketShutdown.Both);
        online.Args.AcceptSocket.Close();
        online.Args.AcceptSocket.Dispose();
        var date = DateTime.Now.ToString("yyyy-MM-dd");
        var time = DateTime.Now.ToString("HH:mm:ss");
        lock (sqlKey) {
            command.CommandText = $"UPDATE Attempts SET DateOut = '{date}', TimeOut ='{time}' WHERE Id = {online.Id}";
            command.ExecuteNonQuery();
        }
    }
    void handleRequest(User request, SocketAsyncEventArgs e) {
        Login login = null;
        for (int i = 0; i < logins.Count; i++) {
            if (logins[i].UserName.Equals(request.UserName)
                && logins[i].Password.Equals(request.Password)) {
                login = logins[i];
                break;
            }
        }
        int attemptId = Interlocked.Increment(ref maxAttempt);
        var address = e.AcceptSocket.RemoteEndPoint.ToString().Split(':');
        var ip = address[0];
        var port = address[1];

        var time = DateTime.Now;
        var attempt = new Attempt() {
            Id = attemptId,
            AppId = getApp(request.App).Id,
            AddressId = getAddress(ip).Id,
            Port = port,
            DateIn = time.ToString("yyyy-MM-dd"),
            TimeIn = time.ToString("HH:mm:ss")
        };
        LoginResult result = new();
        if (login is not null) {
            result.IsSuccess = attempt.IsSuccess = true;
            result.Role = login.Role;
            result.UserId = attempt.UserId = login.Id;
            onlines.Add(new Online() {
                Id = attemptId,
                Login = login,
                Args = e,
                Time = time
            });
        }
        else {
            result.IsSuccess = attempt.IsSuccess = false;
            attempt.UserName = request.UserName;
            attempt.Password = request.Password;
        }
        e.UserToken = result;
        bool started = e.AcceptSocket.SendAsync(e);
        if (!started) onSent(null, e);
        attempts.Add(attempt);
    }
    App getApp(string name) {
        var app = apps.FirstOrDefault(x => x.Name.Equals(name));
        if(app is null) {
            var id = apps.Count == 0 ? 0 : apps.Max(x => x.Id);
            id++;
            app = new App() {
                Id = id,
                Name = name
            };
            apps.Add(app);
            lock (sqlKey) {
                command.CommandText = "INSERT INTO Apps(Name) VALUES(@Name)";
                command.Parameters.AddWithValue("@Name", name);
                command.ExecuteNonQuery();
                command.Parameters.Clear();
            }
        }
        return app;
    }
    Address getAddress(string ip) {
        var address = addresses.FirstOrDefault(x => x.IP.Equals(ip));
        if(address is null) {
            var id = addresses.Count == 0? 0 : addresses.Max(x => x.Id);
            id++;
            address = new Address() {
                Id = id,
                IP = ip
            };
            addresses.Add(address);
            lock (sqlKey) {
                command.CommandText = "INSERT INTO Addresses(IP) VALUES(@IP)";
                command.Parameters.AddWithValue("@IP", ip);
                command.ExecuteNonQuery();
                command.Parameters.Clear();
            }
        }
        return address;
    }
    void writeInDatabase() {
        while (isRunning) {
            var attempt = attempts.Take();
            object userId, userName, password;
            userId = userName = password = DBNull.Value;
            int isSuccess = 1;
            if (!attempt.IsSuccess) {
                userName = attempt.UserName;
                password = attempt.Password;
                isSuccess = 0;
            }
            else userId = attempt.UserId;
            lock (sqlKey) {
                command.CommandText = $@"INSERT INTO Attempts(UserId, AppId, AddressId, Port, UserName, Password, DateIn, TimeIn, IsSucccess)
                                              VALUES(@UserId, {attempt.AppId}, {attempt.AddressId}, '{attempt.Port}', @UserName, @Password, 
                                                '{attempt.DateIn}', '{attempt.TimeIn}', {isSuccess})";
                command.Parameters.AddWithValue(@"UserId", userId);
                command.Parameters.AddWithValue(@"UserName", userName);
                command.Parameters.AddWithValue(@"Password", password);
                command.ExecuteNonQuery();
                command.Parameters.Clear();
            }
        }
    }

    public Task StartAsync(CancellationToken cancellationToken) {
        logins = new List<Login>();
        onlines = new List<Online>();
        apps = new List<App>();
        addresses = new List<Address>();
        attempts = new BlockingCollection<Attempt>();
        sqlKey = new object();
        connection = new SqliteConnection(DB);
        connection.Open();
        command = connection.CreateCommand();
        getData();

        server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        server.Bind(new IPEndPoint(IPAddress.Parse(Addresses.LoginAddress), Addresses.LoginPort));
        server.Listen(500);
        accept();
        isRunning = true;
        new Thread(writeInDatabase) { IsBackground = true }.Start();
        return Task.CompletedTask;
    }
    public Task StopAsync(CancellationToken cancellationToken) {
        isRunning = false;
        command.Dispose();
        connection.Close();
        connection.Dispose();
        foreach (var item in onlines) {
            item.Args.AcceptSocket.Shutdown(SocketShutdown.Both);
            item.Args.AcceptSocket.Close();
            item.Args.AcceptSocket.Dispose();
        }
        onlines.Clear();
        server.Shutdown(SocketShutdown.Both);
        server.Close();
        server.Dispose();
        return Task.CompletedTask;
    }
}