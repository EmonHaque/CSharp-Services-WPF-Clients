IHost host = Host.CreateDefaultBuilder(args)
    .UseWindowsService()
    .ConfigureServices(services =>
    {
        services.AddHostedService<CDRMWorker>();
    })
    .Build();

await host.RunAsync();
