IHost host = Host.CreateDefaultBuilder(args)
    .UseWindowsService()
    .ConfigureServices(services =>
    {
        services.AddHostedService<RentManagerWorker>();
    })
    .Build();

await host.RunAsync();
