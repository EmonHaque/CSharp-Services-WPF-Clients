﻿public class AppInfo
{
    public string Name { get; set; }
    public string Version { get; set; }
    public string Repository { get; set; }

    public List<ArraySegment<byte>> GetBytes() {
        return new List<ArraySegment<byte>>() {
            Encoding.ASCII.GetBytes(Name + '\0'),
            Encoding.ASCII.GetBytes(Version + '\0'),
        };
    }
}
