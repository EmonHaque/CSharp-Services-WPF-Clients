IHost host = Host.CreateDefaultBuilder(args)
    .UseWindowsService()
    .ConfigureServices(services =>
    {
        services.AddHostedService<InstallWorker>();
    })
    .Build();

await host.RunAsync();
