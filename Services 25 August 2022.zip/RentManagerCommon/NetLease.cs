﻿public class NetLease
{
    public int Id { get; set; }
    public int PlotId { get; set; }
    public int SpaceId { get; set; }
    public int TenantId { get; set; }
    public string DateStart { get; set; }
    public string DateEnd { get; set; }
    public string Business { get; set; }
    public bool IsExpired { get; set; }

    public List<ArraySegment<byte>> GetBytes() {
        return new List<ArraySegment<byte>>() {
            BitConverter.GetBytes(Id),
            BitConverter.GetBytes(PlotId),
            BitConverter.GetBytes(SpaceId),
            BitConverter.GetBytes(TenantId),
            Encoding.ASCII.GetBytes(DateStart + '\0'),
            Encoding.ASCII.GetBytes(DateEnd + '\0'),
            Encoding.ASCII.GetBytes(Business + '\0'),
            BitConverter.GetBytes(IsExpired)
        };
    }
    public static NetLease FromBytes(ReadOnlySpan<byte> bytes) {
        int read = 16;
        int start = 16;
        int index = 0;
        var segments = new string[3];
        while (read < bytes.Length) {
            if (bytes[read] != 0) {
                read++;
                continue;
            }
            segments[index++] = Encoding.ASCII.GetString(bytes.Slice(start, read - start));
            start = ++read;
            if (index == segments.Length) break;
        }
        return new NetLease() {
            Id = BitConverter.ToInt32(bytes.Slice(0, 4)),
            PlotId = BitConverter.ToInt32(bytes.Slice(4, 4)),
            SpaceId = BitConverter.ToInt32(bytes.Slice(8, 4)),
            TenantId = BitConverter.ToInt32(bytes.Slice(12, 4)),
            DateStart = segments[0],
            DateEnd = segments[1],
            Business = segments[2],
            IsExpired = BitConverter.ToBoolean(bytes.Slice(read, 1))
        };
    }
}
