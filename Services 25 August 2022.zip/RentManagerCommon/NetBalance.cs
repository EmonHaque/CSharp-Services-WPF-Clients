﻿public class NetBalance
{
    public string Space { get; set; }
    public string Tenant { get; set; }
    public string DateStart { get; set; }
    public string DateEnd { get; set; }
    public int Security { get; set; }
    public int Rent { get; set; }
    public int Due { get; set; }
    public int Count { get; set; }
    public bool IsExpired { get; set; }
    
    public List<ArraySegment<byte>> GetBytes() {
        return new List<ArraySegment<byte>>() {
            Encoding.ASCII.GetBytes(Space + '\0'),
            Encoding.ASCII.GetBytes(Tenant + '\0'),
            Encoding.ASCII.GetBytes(DateStart + '\0'),
            Encoding.ASCII.GetBytes(DateEnd + '\0'),
            BitConverter.GetBytes(Security),
            BitConverter.GetBytes(Rent),
            BitConverter.GetBytes(Due),
            BitConverter.GetBytes(Count),
            BitConverter.GetBytes(IsExpired)
        };
    }
}
