﻿public class RentManagerRequest : Request
{
    protected override List<ArraySegment<byte>> getArgBytes() {
        switch ((Function)Method) {
            case Function.GetInitialData: return new List<ArraySegment<byte>>();
            case Function.AddPlot:
            case Function.EditPlot: return ((NetPlot)Args[0]).GetBytes();
            case Function.AddSpace: return ((NetSpace)Args[0]).GetBytes();
            case Function.EditSpace: {
                    var bytes = new List<ArraySegment<byte>>();
                    bytes.Add(Encoding.ASCII.GetBytes(Args[0].ToString() + '\0'));
                    bytes.AddRange(((NetSpace)Args[1]).GetBytes());
                    return bytes;
                }
            case Function.AddTenant: return ((NetTenant)Args[0]).GetBytes();
            case Function.EditTenant: {
                    var bytes = new List<ArraySegment<byte>>();
                    bytes.Add(Encoding.ASCII.GetBytes(Args[0].ToString() + '\0'));
                    bytes.AddRange(((NetTenant)Args[1]).GetBytes());
                    return bytes;
                }
            case Function.AddHead:
            case Function.EditHead: return ((NetHead)Args[0]).GetBytes();
            case Function.AddLease:
            case Function.EditLease: {
                    var bytes = new List<ArraySegment<byte>>();
                    bytes.AddRange(((NetLease)Args[0]).GetBytes());
                    var list = (List<NetReceivable>)Args[1];
                    foreach (var item in list) {
                        bytes.AddRange(item.GetBytes());
                    }
                    return bytes;
                }
            case Function.AddTransactionsRegular:
            case Function.AddTransactionsIrregular:
            case Function.AddBulkRent: {
                    var bytes = new List<ArraySegment<byte>>();
                    var transactions = (List<NetTransaction>)Args[0];
                    foreach (var t in transactions) bytes.AddRange(t.GetBytes());
                    return bytes;
                }
            case Function.EditTransaction:
            case Function.DeleteTransaction: return ((NetTransaction)Args[0]).GetBytes();
            case Function.GetTransactions:
                return new List<ArraySegment<byte>>() {
                    Encoding.ASCII.GetBytes(Args[0].ToString() + '\0')
                };
            case Function.GetBalance:
                return new List<ArraySegment<byte>>() {
                        BitConverter.GetBytes((int)Args[0]),
                        BitConverter.GetBytes((int)Args[1])
                    };
            case Function.GetMonthlyBalance:
                return new List<ArraySegment<byte>>() {
                        Encoding.ASCII.GetBytes(Args[0].ToString() + '\0'),
                        Encoding.ASCII.GetBytes(Args[1].ToString() + '\0'),
                        Encoding.ASCII.GetBytes(Args[2].ToString() + '\0')
                    };
            case Function.GetLedger:
                return new List<ArraySegment<byte>>() {
                        BitConverter.GetBytes((int)Args[0]),
                        Encoding.ASCII.GetBytes(Args[1].ToString() + '\0')
                    };
            case Function.GetReceiptPayment:
                return new List<ArraySegment<byte>>() {
                        Encoding.ASCII.GetBytes(Args[0] + "\0"),
                        Encoding.ASCII.GetBytes(Args[1] + "\0")
                    };
            case Function.GetPlotwiseRent:
            case Function.GetPlotDueChart:
                return new List<ArraySegment<byte>>() {
                    BitConverter.GetBytes((int)Args[0]),
                    Encoding.ASCII.GetBytes(Args[1].ToString() + '\0')
                };
            case Function.GetTenantDetail: return new List<ArraySegment<byte>>() { BitConverter.GetBytes((int)Args[0]) };
            case Function.GetDepositDueRent: return new List<ArraySegment<byte>>() { BitConverter.GetBytes((byte)Args[0]) };
            default: return new List<ArraySegment<byte>>();
        }
    }

    public static RentManagerRequest FromBytes(byte[] array) {
        var span = new ReadOnlySpan<byte>(array);
        var user = BitConverter.ToInt32(span.Slice(0, 4));
        var method = BitConverter.ToInt32(span.Slice(4, 4));
        var args = getArgs(method, span.Slice(8, array.Length - 8));
        return new RentManagerRequest() {
            UserId = user,
            Method = method,
            Args = args
        };
    }
    static object[] getArgs(int method, ReadOnlySpan<byte> bytes) {
        switch ((Function)method) {
            case Function.GetInitialData: return new object[] { "" };
            case Function.AddPlot:
            case Function.EditPlot: return new object[] { NetPlot.FromBytes(bytes) };
            case Function.AddSpace: return new object[] { NetSpace.FromBytes(bytes) };
            case Function.EditSpace: {
                    int read = 0;
                    while (read < bytes.Length) {
                        if (bytes[read] != 0) {
                            read++;
                            continue;
                        }
                        break;
                    }
                    var vaccatedOn = Encoding.ASCII.GetString(bytes.Slice(0, read));
                    read++;
                    var space = NetSpace.FromBytes(bytes.Slice(read));
                    return new object[] { vaccatedOn, space };
                }
            case Function.AddTenant: return new object[] { NetTenant.FromBytes(bytes) };
            case Function.EditTenant: {
                    int read = 0;
                    while (read < bytes.Length) {
                        if (bytes[read] != 0) {
                            read++;
                            continue;
                        }
                        break;
                    }
                    var vaccatedOn = Encoding.ASCII.GetString(bytes.Slice(0, read));
                    read++;
                    var tenant = NetTenant.FromBytes(bytes.Slice(read));
                    return new object[] { vaccatedOn, tenant };
                }
            case Function.AddHead:
            case Function.EditHead: return new object[] { NetHead.FromBytes(bytes) };
            case Function.AddLease:
            case Function.EditLease: {
                    var lease = new NetLease() {
                        Id = BitConverter.ToInt32(bytes.Slice(0, 4)),
                        PlotId = BitConverter.ToInt32(bytes.Slice(4, 4)),
                        SpaceId = BitConverter.ToInt32(bytes.Slice(8, 4)),
                        TenantId = BitConverter.ToInt32(bytes.Slice(12, 4)),
                    };
                    int index = 0;
                    int read = 16;
                    int start = 16;
                    var segments = new string[3];
                    while (read < bytes.Length) {
                        if (bytes[read] != 0) {
                            read++;
                            continue;
                        }
                        segments[index++] = Encoding.ASCII.GetString(bytes.Slice(start, read - start));
                        start = ++read;
                        if (index == segments.Length) break;
                    }
                    lease.DateStart = segments[0];
                    lease.DateEnd = segments[1];
                    lease.Business = segments[2];
        
                    lease.IsExpired = BitConverter.ToBoolean(bytes.Slice(read, 1));
                    read++;

                    var balance = bytes.Length - read;
                    var numReceivable = balance / 12;
                    var receivables = new List<NetReceivable>(numReceivable);
                    
                    for (int i = 0; i < numReceivable; i++) {
                        var r = NetReceivable.FromBytes(bytes.Slice(read, 12));
                        receivables.Add(r);
                        read += 12;
                    }
                    return new object[] { lease, receivables };
                }
            case Function.AddTransactionsRegular:
            case Function.AddTransactionsIrregular:
            case Function.AddBulkRent: {
                    List<NetTransaction> transactions = new();
                    int read = 0;
                    int start = 0;
                    while (read < bytes.Length) {
                        var transaction = new NetTransaction() {
                            Id = BitConverter.ToInt32(bytes.Slice(start, 4)),
                            PlotId = BitConverter.ToInt32(bytes.Slice(start + 4, 4)),
                            SpaceId = BitConverter.ToInt32(bytes.Slice(start + 8, 4)),
                            TenantId = BitConverter.ToInt32(bytes.Slice(start + 12, 4)),
                            ControlId = BitConverter.ToInt32(bytes.Slice(start + 16, 4)),
                            HeadId = BitConverter.ToInt32(bytes.Slice(start + 20, 4)),
                            Amount = BitConverter.ToInt32(bytes.Slice(start + 24, 4)),
                            IsCash = bytes.Slice(start + 28, 1)[0]
                        };
                        read += 29;
                        start += 29;
                        while (bytes[read] != 0) read++;
                        transaction.Date = Encoding.ASCII.GetString(bytes.Slice(start, read - start));

                        start = ++read;
                        while (bytes[read] != 0) read++;
                        transaction.Narration = Encoding.ASCII.GetString(bytes.Slice(start, read - start));

                        transactions.Add(transaction);
                        start = ++read;
                    }
                    return new object[] { transactions };
                }
            case Function.EditTransaction:
            case Function.DeleteTransaction: return new object[] { NetTransaction.FromBytes(bytes) };
            case Function.GetTransactions: return new object[] { Encoding.ASCII.GetString(bytes) };
            case Function.GetBalance:
                return new object[] {
                            BitConverter.ToInt32(bytes.Slice(0, 4)),
                            BitConverter.ToInt32(bytes.Slice(4, 4))
                        };

            case Function.GetLedger: {
                    var id = BitConverter.ToInt32(bytes.Slice(0, 4));
                    var where = Encoding.ASCII.GetString(bytes.Slice(4, bytes.Length - 5));
                    return new object[] { id, where };
                }
            case Function.GetMonthlyBalance:
            case Function.GetReceiptPayment: {
                    int start, read, index;
                    start = read = index = 0;
                    var size = method == (int)Function.GetMonthlyBalance ? 3 : 2;
                    var segments = new string[size];
                    while (read < bytes.Length) {
                        if (bytes[read] != 0) {
                            read++;
                            continue;
                        }
                        segments[index++] = Encoding.ASCII.GetString(bytes.Slice(start, read - start));
                        start = ++read;
                    }
                    return segments;
                }
            case Function.GetPlotwiseRent:
            case Function.GetPlotDueChart: {
                    return new object[] {
                        BitConverter.ToInt32(bytes.Slice(0, 4)),
                        Encoding.ASCII.GetString(bytes.Slice(4, bytes.Length - 5))
                    };
                }
            case Function.GetTenantDetail: return new object[] { BitConverter.ToInt32(bytes.Slice(0, 4)) };
            case Function.GetDepositDueRent: return new object[] { bytes.Slice(0, 1)[0] };
            default: return new object[0];
        }
    }
}
