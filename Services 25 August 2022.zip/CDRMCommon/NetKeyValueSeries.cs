﻿public class NetKeyValueSeries
{
    public string Key { get; set; }
    public int Value { get; set; }

    public List<ArraySegment<byte>> GetBytes() {
        return new List<ArraySegment<byte>>() {
            Encoding.ASCII.GetBytes(Key + '\0'),
            BitConverter.GetBytes(Value)
        };
    }
}
