﻿public class NetReceiptPaymentText
{
    public int Id { get; set; }
    public byte IsCash { get; set; }
    public byte IsReceipt { get; set; }
    public string Date { get; set; }
    public string Amount { get; set; }
    public string Party { get; set; }
    public string Head { get; set; }
    public string Narration { get; set; }

   public List<ArraySegment<byte>> GetBytes() {
        return new List<ArraySegment<byte>>() {
            BitConverter.GetBytes(Id),
            new byte[1]{ IsCash },
            new byte[1]{ IsReceipt },
            Encoding.ASCII.GetBytes(Date + '\0'),
            Encoding.ASCII.GetBytes(Amount + '\0'),
            Encoding.ASCII.GetBytes(Party + '\0'),
            Encoding.ASCII.GetBytes(Head + '\0'),
            Encoding.ASCII.GetBytes(Narration + '\0')
        };
    }
}
