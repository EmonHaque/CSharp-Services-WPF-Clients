﻿public class NetDates
{
    public string From { get; set; }
    public string Start { get; set; }
    public string To { get; set; }
    public string End { get; set; }
    public List<ArraySegment<byte>> GetBytes() {
        return new List<ArraySegment<byte>>() {
            Encoding.ASCII.GetBytes(From + '\0'),
            Encoding.ASCII.GetBytes(Start + '\0'),
            Encoding.ASCII.GetBytes(To + '\0'),
            Encoding.ASCII.GetBytes(End + '\0')
        };
    }
}
