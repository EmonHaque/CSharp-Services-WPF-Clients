﻿public class NetPurchaseSellText
{
    public int Id { get; set; }
    public byte IsSell { get; set; }
    public byte IsConstruction { get; set; }
    public string Date { get; set; }
    public string Site { get; set; }
    public string Party { get; set; }
    public string Head { get; set; }
    public string SubHead { get; set; }
    public string Unit { get; set; }
    public string Amount { get; set; }
    public string Quantity { get; set; }
    public string Narration { get; set; }

    public List<ArraySegment<byte>> GetBytes() {
        return new List<ArraySegment<byte>>() {
            BitConverter.GetBytes(Id),
            new byte[1]{ IsSell },
            new byte[1]{ IsConstruction },
            Encoding.ASCII.GetBytes(Date +'\0'),
            Encoding.ASCII.GetBytes(Site +'\0'),
            Encoding.ASCII.GetBytes(Party +'\0'),
            Encoding.ASCII.GetBytes(Head +'\0'),
            Encoding.ASCII.GetBytes(SubHead +'\0'),
            Encoding.ASCII.GetBytes(Unit +'\0'),
            Encoding.ASCII.GetBytes(Amount +'\0'),
            Encoding.ASCII.GetBytes(Quantity +'\0'),
            Encoding.ASCII.GetBytes(Narration +'\0'),
        };
    }
}
