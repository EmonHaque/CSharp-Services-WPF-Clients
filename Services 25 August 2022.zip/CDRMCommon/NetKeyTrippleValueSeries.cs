﻿public class NetKeyTrippleValueSeries
{
    public string Key { get; set; }
    public int Value1 { get; set; }
    public int Value2 { get; set; }
    public int Value3 { get; set; }

    public List<ArraySegment<byte>> GetBytes() {
        return new List<ArraySegment<byte>>() {
            Encoding.ASCII.GetBytes(Key +'\0'),
            BitConverter.GetBytes(Value1),
            BitConverter.GetBytes(Value2),
            BitConverter.GetBytes(Value3)
        };
    }
}
