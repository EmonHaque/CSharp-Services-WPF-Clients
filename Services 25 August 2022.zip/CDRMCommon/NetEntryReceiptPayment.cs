﻿public class NetEntryReceiptPayment
{
    public byte IsReceipt { get; set; }
    public byte IsCash { get; set; }
    public int Id { get; set; }
    public int PartyId { get; set; }
    public int HeadId { get; set; }
    public int Amount { get; set; }
    public string Date { get; set; }
    public string Narration { get; set; }

    public List<ArraySegment<byte>> GetBytes() {
        return new List<ArraySegment<byte>>() {
            new byte[1]{ IsReceipt },
            new byte[1]{ IsCash },
            BitConverter.GetBytes(Id),
            BitConverter.GetBytes(PartyId),
            BitConverter.GetBytes(HeadId),
            BitConverter.GetBytes(Amount),
            Encoding.ASCII.GetBytes(Date + '\0'),
            Encoding.ASCII.GetBytes(Narration + '\0')
        };
    }
    public static NetEntryReceiptPayment FromBytes(ReadOnlySpan<byte> array) {
        int start, read, index;
        start = read = 18;
        index = 0;
        var segments = new string[2];
        while (read < array.Length) {
            if (array[read] != 0) {
                read++;
                continue;
            }
            segments[index++] = Encoding.ASCII.GetString(array.Slice(start, read - start));
            start = ++read;
            if (index == segments.Length) break;
        }
        return new NetEntryReceiptPayment() {
            IsReceipt = array.Slice(0, 1)[0],
            IsCash = array.Slice(1, 1)[0],
            Id = BitConverter.ToInt32(array.Slice(2, 4)),
            PartyId = BitConverter.ToInt32(array.Slice(6, 4)),
            HeadId = BitConverter.ToInt32(array.Slice(10, 4)),
            Amount = BitConverter.ToInt32(array.Slice(14, 4)),
            Date = segments[0],
            Narration = segments[1]
        };
    }
}
