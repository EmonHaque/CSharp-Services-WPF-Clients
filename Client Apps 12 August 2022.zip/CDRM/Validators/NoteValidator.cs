﻿using System.ComponentModel.DataAnnotations;
using System.Windows.Media.Media3D;

class NoteValidator
{
    EntryNoteText entry; 
    public List<ValidationError> Errors { get; set; }

    public NoteValidator() { }
    public NoteValidator(EntryNoteText entry) {
        this.entry = entry;
    }
    public bool IsValid() {
        Errors = new List<ValidationError>();
        if(entry.Date is null) {
            Errors.Add(new ValidationError() {
                Head = nameof(entry.Date),
                Error = "cannot be empty"
            });
        }
        if (string.IsNullOrWhiteSpace(entry.NoteType)) {
            Errors.Add(new ValidationError() {
                Head = nameof(entry.NoteType),
                Error = "cannot be empty"
            });
        }
        if (string.IsNullOrWhiteSpace(entry.Site)) {
            Errors.Add(new ValidationError() {
                Head = nameof(entry.Site),
                Error = "cannot be empty"
            });
        }
        if (string.IsNullOrWhiteSpace(entry.Entry)) {
            Errors.Add(new ValidationError() {
                Head = nameof(entry.Entry),
                Error = "cannot be empty"
            });
        }
        return Errors.Count == 0;
    }
    public bool DoesExist() {
        Errors = new List<ValidationError>();
        if (!AppData.HasNoteTye(entry.NoteType)) {
            Errors.Add(new ValidationError() {
                Head = nameof(entry.NoteType),
                Error = Constants.DoesntExist
            });
        }
        else entry.NoteTypeId = AppData.GetNoteType().Id;
        if (!AppData.HasSite(entry.Site)) {
            Errors.Add(new ValidationError() {
                Head = nameof(entry.Site),
                Error = Constants.DoesntExist
            });
        }
        else entry.SiteId = AppData.GetSite().Id;
        return Errors.Count == 0;
    }
    public bool IsEqual(EntryNoteText e) {
        return
            e.Date == entry.Date
            && string.Equals(e.NoteType, entry.NoteType, StringComparison.InvariantCultureIgnoreCase)
            && string.Equals(e.Site, entry.Site, StringComparison.InvariantCultureIgnoreCase)
            && string.Equals(e.Entry, entry.Entry, StringComparison.InvariantCultureIgnoreCase);
    }
    public async Task<bool> Resolve(double left, double top, double width, double height) {
        bool isSuccess = true;
        var request = new CDRMRequest() { UserId = App.service.UserId };
        Response response = null;

        foreach (var e in Errors) {
            switch (e.Head) {
                case nameof(entry.Site): {
                        var name = entry.Site.Trim();
                        var dialog = new CreateSiteDialog(left, top, width, height, entry.Site);
                        dialog.ShowDialog();
                        var site = new NetSite() {
                            Name = name,
                            Address = dialog.GetAddress().Trim()
                        };
                        request.Method = (int)Function.AddSite;
                        request.Args = new object[] { site };
                        response = await App.service.GetResponse(request);
                        if (response.IsSuccess) {
                            entry.SiteId = BitConverter.ToInt32(response.Packet.Skip(1).ToArray());
                            entry.Site = name;
                        }
                        else {
                            isSuccess = false;
                            break;
                        }
                    }
                    break;

                case nameof(entry.NoteType): {
                        var name = entry.NoteType.Trim();
                        var noteType = new NetNoteType() { Name = name };
                        request.Method = (int)Function.AddNoteType;
                        request.Args = new object[] { noteType };
                        response = await App.service.GetResponse(request);
                        if (response.IsSuccess) {
                            entry.NoteTypeId = BitConverter.ToInt32(response.Packet.Skip(1).ToArray());
                            entry.NoteType = name;
                        }
                        else {
                            isSuccess = false;
                            break;
                        }
                    }
                    break;
            }
        }
        return isSuccess;
    }
}
