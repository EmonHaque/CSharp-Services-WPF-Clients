﻿class SummaryDueVM : Notifiable
{
    List<SumTransaction> entries;
    ObservableCollection<SumPartyTransaction> reportables;
    string query;
    public string Query {
        get { return query; }
        set { query = value; Reportables.Refresh(); }
    }
    bool isSettled;
    public bool IsSettled {
        get { return isSettled; }
        set { isSettled = value; Reportables.Refresh(); }
    }

    public int TotalPaid { get; set; }
    public int TotalBalance { get; set; }
    public ICollectionView Reportables { get; set; }
    public event Action CoordinateRequested;

    public SummaryDueVM() {
        entries = new List<SumTransaction>();
        reportables = new ObservableCollection<SumPartyTransaction>();
        Reportables = CollectionViewSource.GetDefaultView(reportables);
        Reportables.Filter = filter;
        Reportables.CollectionChanged += onCollectionChanged;
        getEntries();
    }

    public void Refresh() {
        CoordinateRequested?.Invoke();
        BusyWindow.Activate(SummaryDue.Left, SummaryDue.Top, SummaryDue.Width, SummaryDue.Height, "Refreshing");
        getEntries();
        if(BusyWindow.IsOpened) BusyWindow.Terminate();
    }
    public void SortName() => sort(nameof(SumPartyTransaction.Party));
    public void SortPaid() => sort(nameof(SumPartyTransaction.Paid));
    public void SortBalance() => sort(nameof(SumPartyTransaction.Balance));

    ListSortDirection getDirection(string property) {
        var direction = property.Equals(nameof(SumPartyTransaction.Party)) ?
            ListSortDirection.Ascending :
            ListSortDirection.Descending;
        var description = Reportables.SortDescriptions.FirstOrDefault(x => x.PropertyName.Equals(property));
        if (description.PropertyName is not null) {
            direction = description.Direction == ListSortDirection.Descending ?
                ListSortDirection.Ascending :
                ListSortDirection.Descending;
        }
        return direction;
    }
    bool filter(object o) {
        if (string.IsNullOrWhiteSpace(Query)) return ((SumPartyTransaction)o).IsSettled == IsSettled;
        var s = (SumPartyTransaction)o;
        return
            s.IsSettled == IsSettled &&
            s.Party.Contains(Query, StringComparison.InvariantCultureIgnoreCase);
    }
    void sort(string property) {
        if (Reportables.IsEmpty) return;
        var direction = getDirection(property);
        using (Reportables.DeferRefresh()) {
            Reportables.SortDescriptions.Clear();
            Reportables.SortDescriptions.Add(new SortDescription(property, direction));
        }
    }
    void onCollectionChanged(object? sender, NotifyCollectionChangedEventArgs e) {
        TotalPaid = 0;
        foreach (SumPartyTransaction item in Reportables) {
            TotalPaid += item.Paid;
            TotalBalance += item.Balance;
        }
        OnPropertyChanged(nameof(TotalPaid));
        OnPropertyChanged(nameof(TotalBalance));
    }
    Task addEntries(byte[] packet) {
        var bytes = new ReadOnlySpan<byte>(packet);
        int read, start;
        start = read = 0;
        while (read < bytes.Length) {
            var party = BitConverter.ToInt32(bytes.Slice(start, 4));
            var purchase = BitConverter.ToInt32(bytes.Slice(start + 4, 4));
            var sell = BitConverter.ToInt32(bytes.Slice(start + 8, 4));
            read += 12;
            start = read;
            while (bytes[read] != 0) read++;
            var head = Encoding.ASCII.GetString(bytes.Slice(start, read - start));
            entries.Add(new SumTransaction() {
                Head = head,
                PartyId = party,
                PurchaseReceipt = purchase,
                SellPayment = sell
            });
            start = ++read;
        }
        return Task.CompletedTask;
    }
    async void getEntries() {
        entries.Clear();
        var request = new CDRMRequest() {
            UserId = App.service.UserId,
            Method = (int)Function.GetDues
        };
        var response = await App.service.GetResponse(request);
        if (!response.IsSuccess) {
            BusyWindow.Terminate();
            InfoDialog.Activate("Summary", LocalConstants.ServiceDown);
            return;
        }
        await addEntries(response.Packet);
        
        using (Reportables.DeferRefresh()) {
            Reportables.Filter = null;
            Reportables.CollectionChanged -= onCollectionChanged;
            reportables.Clear();
        }
        SumPartyTransaction group = null;
        foreach (var e in entries) {
            group = reportables.FirstOrDefault(x => x.PartyId == e.PartyId);
            if (group is null) {
                group = new SumPartyTransaction() {
                    PartyId = e.PartyId,
                    Party = AppData.parties.First(x => x.Id == e.PartyId).Name,
                    Transactions = new List<SumTransaction>()
                };
                group.Transactions.Add(e);
                reportables.Add(group);
            }
            else group.Transactions.Add(e);

            group.Balance += e.PurchaseReceipt;
            group.Balance -= e.SellPayment;
        }
        foreach (var party in reportables) {
            party.IsSettled = party.Balance == 0;
            int sell = 0;
            var sellEntry = party.Transactions.FirstOrDefault(x => x.Head.Equals("Sell"));
            if (sellEntry != null) sell = sellEntry.SellPayment;
            party.Paid = party.Transactions.Sum(x => x.SellPayment) - sell;
        }
        Reportables.Filter = filter;
        Reportables.CollectionChanged += onCollectionChanged;
    }
}
