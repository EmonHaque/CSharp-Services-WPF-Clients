﻿class EditNoteControl : Grid
{
    DayPicker date;
    SuggestBox noteType, site;
    EditText entry;

    public EditNoteControl() {
        Margin = new Thickness(0, 10, 0, 0);
        date = new DayPicker() {
            Hint = "Date",
            DateFormat = "dd/mm/yyyy"
        };
        noteType = new SuggestBox() {
            IsRequired = true,
            Icon = Icons.NoteType,
            Hint = "Note type",
            Source = AppData.noteTypes
        };
        site = new SuggestBox() {
            IsRequired = true,
            Icon = Icons.Plot,
            Hint = "Site",
            Source = AppData.sites
        };

        entry = new EditText() {
            Margin = new Thickness(5, 15, 5, 10),
            IsMultiline = true,
            Icon = Icons.Description,
            Hint = "Entry"
        };
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
        RowDefinitions.Add(new RowDefinition());
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
        SetRow(site, 1);
        SetRow(entry, 2);
        SetRow(date, 3);
        Children.Add(noteType);
        Children.Add(site);
        Children.Add(entry);
        Children.Add(date);

        noteType.SetBinding(SuggestBox.TextProperty, new Binding(nameof(EntryNoteText.NoteType)));
        site.SetBinding(SuggestBox.TextProperty, new Binding(nameof(EntryNoteText.Site)));
        entry.SetBinding(EditText.TextProperty, new Binding(nameof(EntryNoteText.Entry)));
        date.SetBinding(DayPicker.SelectedDateProperty, new Binding(nameof(EntryNoteText.Date)));
    }
}
