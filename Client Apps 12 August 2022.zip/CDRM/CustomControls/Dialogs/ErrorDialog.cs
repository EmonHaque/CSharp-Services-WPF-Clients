﻿class ErrorDialog : Window
{
    List<ValidationError> error;
    ActionButton button;
    ItemsControl box;

    public ErrorDialog(double left, double top, double width, double height, List<ValidationError> e) {
        error = e;
        Left = left;
        Top = top;
        Width = width;
        Height = height;
        Owner = App.Current.MainWindow;
        ShowInTaskbar = false;
        AllowsTransparency = true;
        WindowStyle = WindowStyle.None;
        ResizeMode = ResizeMode.NoResize;
        Background = new SolidColorBrush(Color.FromArgb(127, 0, 0, 0));
        WindowChrome.SetWindowChrome(this, new WindowChrome() {
            GlassFrameThickness = new Thickness(0),
            CornerRadius = new CornerRadius(7),
            ResizeBorderThickness = new Thickness(0),
            CaptionHeight = 0
        });
        initializeContent();
    }

    void initializeContent() {
        button = new ActionButton() {
            HorizontalAlignment = HorizontalAlignment.Right,
            Width = 24,
            Height = 24,
            Margin = new Thickness(0, 5, 5, 5),
            Icon = Icons.Ok,
            ToolTip = "Close",
            Command = Close
        };
        box = new ItemsControl() {
            HorizontalContentAlignment = HorizontalAlignment.Stretch,
            VerticalAlignment = VerticalAlignment.Center,
            BorderThickness = new Thickness(0),
            Margin = new Thickness(15, 0, 15, 0),
            ItemTemplate = new ValidationErrorTemplate(),
            ItemsSource = error
        };
        box.SetValue(Grid.IsSharedSizeScopeProperty, true);
        box.SetValue(ScrollViewer.VerticalScrollBarVisibilityProperty, ScrollBarVisibility.Auto);
        box.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        Grid.SetRow(button, 1);

        Content = new Grid() {
            RowDefinitions = {
                new RowDefinition(),
                new RowDefinition(){Height = GridLength.Auto }
            },
            Children = { box, button }
        };
    }
}
