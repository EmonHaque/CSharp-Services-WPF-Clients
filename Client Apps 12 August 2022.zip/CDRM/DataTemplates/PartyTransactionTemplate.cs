﻿class PartyTransactionTemplate : DataTemplate
{
    public PartyTransactionTemplate() {
        var grid = new FrameworkElementFactory(typeof(Grid));
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var name = new FrameworkElementFactory(typeof(HiBlock));
        var paid = new FrameworkElementFactory(typeof(TextBlock));

        col2.SetValue(ColumnDefinition.WidthProperty, new GridLength(Constants.AmountColumnWidth));
        paid.SetValue(Grid.ColumnProperty, 1);
        paid.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
        paid.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);
        name.SetValue(HiBlock.TextWrappingProperty, TextWrapping.Wrap);

        name.SetBinding(HiBlock.TextProperty, new Binding(nameof(SumPartyTransaction.Party)));
        name.SetBinding(HiBlock.QueryProperty, new Binding("DataContext.Query") {
            RelativeSource = new RelativeSource(RelativeSourceMode.FindAncestor, typeof(ListBox), 1)
        });
        paid.SetBinding(TextBlock.TextProperty, new Binding(nameof(SumPartyTransaction.Paid)) { StringFormat = Constants.NumberFormat});
        grid.SetValue(Grid.ToolTipProperty, new BalanceToolTip());

        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(name);
        grid.AppendChild(paid);
        VisualTree = grid;
    }
}
