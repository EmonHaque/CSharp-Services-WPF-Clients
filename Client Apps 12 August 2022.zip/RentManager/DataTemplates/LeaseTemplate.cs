﻿class LeaseTemplate : DataTemplate
{
    public LeaseTemplate(string queryProperty, object viewModel, bool isSpaceBold = true, bool hasTrigger = false) {

        var block = new FrameworkElementFactory(typeof(HiBlock));
        var space = new FrameworkElementFactory(typeof(Run));
        var colon = new FrameworkElementFactory(typeof(Run));
        var tenant = new FrameworkElementFactory(typeof(Run));
        space.SetBinding(Run.TextProperty, new Binding(nameof(Lease.SpaceName)));
        if (isSpaceBold) space.SetValue(Run.FontWeightProperty, FontWeights.Bold);
        colon.SetValue(Run.TextProperty, " : ");
        tenant.SetBinding(Run.TextProperty, new Binding(nameof(Lease.TenantName)));
        tenant.SetValue(Run.FontStyleProperty, FontStyles.Italic);
        block.SetBinding(HiBlock.QueryProperty, new Binding(queryProperty) { Source = viewModel, IsAsync = true });

        block.AppendChild(space);
        block.AppendChild(colon);
        block.AppendChild(tenant);

        if (hasTrigger) {
            Triggers.Add(new MultiDataTrigger() {
                Conditions = {
                        new Condition(new Binding("FilterState"){ Source = viewModel }, null),
                        new Condition(new Binding(nameof(Lease.IsExpired)), true),
                    },
                Setters = {
                        new Setter(HiBlock.ForegroundProperty, Brushes.Gray),
                        new Setter(HiBlock.FontStyleProperty, FontStyles.Italic),
                    }
            });
        }
        VisualTree = block;
    }
}
