﻿class BalanceTemplate : DataTemplate
{
    public BalanceTemplate() {
        var grid = new FrameworkElementFactory(typeof(Grid));
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col3 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col4 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col5 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var spacePanel = new FrameworkElementFactory(typeof(StackPanel));
        var tenantName = new FrameworkElementFactory(typeof(HiBlock)) { Name = "tenant" };
        var hyphen = new FrameworkElementFactory(typeof(TextBlock)) { Name = "hyphen" };
        var space = new FrameworkElementFactory(typeof(TextBlock));
        var expired = new FrameworkElementFactory(typeof(TextBlock)) { Name = "expired" };
        var from = new FrameworkElementFactory(typeof(TextBlock));
        var cash = new FrameworkElementFactory(typeof(TextBlock));
        var kind = new FrameworkElementFactory(typeof(TextBlock));
        var total = new FrameworkElementFactory(typeof(TextBlock));
        var expiredOn = new FrameworkElementFactory(typeof(Run));
        var expiredDate = new FrameworkElementFactory(typeof(Run));

        Resources.Add(typeof(TextBlock), new Style() {
            Setters = {
                new Setter(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right)
            }
        });

        col2.SetValue(ColumnDefinition.WidthProperty, new GridLength(150));
        col3.SetValue(ColumnDefinition.WidthProperty, new GridLength(70));
        col4.SetValue(ColumnDefinition.WidthProperty, new GridLength(70));
        col5.SetValue(ColumnDefinition.WidthProperty, new GridLength(70));
        tenantName.SetValue(HiBlock.FontWeightProperty, FontWeights.Bold);
        tenantName.SetValue(HiBlock.VisibilityProperty, Visibility.Collapsed);
        hyphen.SetValue(TextBlock.TextProperty, " - ");
        hyphen.SetValue(TextBlock.VisibilityProperty, Visibility.Collapsed);
        expiredOn.SetValue(Run.TextProperty, " - expired on ");
        expired.SetValue(TextBlock.FontStyleProperty, FontStyles.Italic);
        spacePanel.SetValue(StackPanel.OrientationProperty, Orientation.Horizontal);
        from.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Center);

        from.SetValue(Grid.ColumnProperty, 1);
        cash.SetValue(Grid.ColumnProperty, 2);
        kind.SetValue(Grid.ColumnProperty, 3);
        total.SetValue(Grid.ColumnProperty, 4);

        tenantName.SetBinding(HiBlock.TextProperty, new Binding(nameof(Balance.Tenant)));
        tenantName.SetBinding(HiBlock.QueryProperty, new Binding("DataContext." + nameof(ReportBalanceVM.TenantQuery)) {
            RelativeSource = new RelativeSource(RelativeSourceMode.FindAncestor, typeof(ListBox), 1),
            IsAsync = true
        });
        space.SetBinding(TextBlock.TextProperty, new Binding(nameof(Balance.Space)));
        expiredDate.SetBinding(Run.TextProperty, new Binding(nameof(Balance.DateEnd)) { StringFormat = "dd MMMM yyyy" });
        from.SetBinding(TextBlock.TextProperty, new Binding(nameof(Balance.DateStart)) { StringFormat = "dd MMMM yyyy" });

        cash.SetBinding(TextBlock.TextProperty, new Binding(nameof(Balance.Security)) { StringFormat = Constants.NumberFormat });
        kind.SetBinding(TextBlock.TextProperty, new Binding(nameof(Balance.Rent)) { StringFormat = Constants.NumberFormat });
        total.SetBinding(TextBlock.TextProperty, new Binding(nameof(Balance.Due)) { StringFormat = Constants.NumberFormat });

        expired.AppendChild(expiredOn);
        expired.AppendChild(expiredDate);
        spacePanel.AppendChild(tenantName);
        spacePanel.AppendChild(hyphen);
        spacePanel.AppendChild(space);
        spacePanel.AppendChild(expired);

        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(col3);
        grid.AppendChild(col4);
        grid.AppendChild(col5);

        grid.AppendChild(spacePanel);
        grid.AppendChild(from);
        grid.AppendChild(cash);
        grid.AppendChild(kind);
        grid.AppendChild(total);

        Triggers.Add(new MultiDataTrigger() {
            Conditions = {
                new Condition(new Binding("DataContext.IsBottomLevel"){
                    RelativeSource = new RelativeSource(RelativeSourceMode.FindAncestor, typeof(ItemsPresenter), 1)
                }, true),
                new Condition(new Binding("DataContext.ItemCount"){
                    RelativeSource = new RelativeSource(RelativeSourceMode.FindAncestor, typeof(ItemsPresenter), 1)
                }, 1),
            },
            Setters = {
                new Setter(HiBlock.VisibilityProperty, Visibility.Visible, "tenant"),
                new Setter(TextBlock.VisibilityProperty, Visibility.Visible, "hyphen"),
            }
        });
        Triggers.Add(new DataTrigger() {
            Binding = new Binding(nameof(Balance.IsExpired)),
            Value = false,
            Setters = {
                new Setter(TextBlock.VisibilityProperty, Visibility.Collapsed, "expired")
            }
        });

        VisualTree = grid;
    }
}
