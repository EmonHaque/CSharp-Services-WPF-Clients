﻿class ReportMonthlyBalanceVM : Notifiable
{
    DateTime lastDayOfPreviousMonth, firstDayOfPreviousMonth, lastDayOfSelectedMonth;
    ObservableCollection<MonthlyBalance> payments;
    byte state;
    public byte State {
        get { return state; }
        set { state = value; Payments.Refresh(); }
    }
    string status;
    public string Status {
        get { return status; }
        set { status = value; OnPropertyChanged(nameof(Status)); }
    }

    public int TotalDue { get; set; }
    public int TotalLastDue { get; set; }
    public int TotalPaid { get; set; }
    public ICollectionView Payments { get; set; }
    public Action Refresh { get; set; }
    public DateTime SelectedDate { get; set; }

    public ReportMonthlyBalanceVM() {
        payments = new ObservableCollection<MonthlyBalance>();
        Payments = CollectionViewSource.GetDefaultView(payments);
        Payments.GroupDescriptions.Add(new PropertyGroupDescription(nameof(MonthlyBalance.Plot)));
        Payments.Filter = filter;
        Payments.CollectionChanged += onCollectionChanged;

        SelectedDate = DateTime.Today;
        lastDayOfPreviousMonth = SelectedDate.AddMonths(-1);
        var lastDay = DateTime.DaysInMonth(lastDayOfPreviousMonth.Year, lastDayOfPreviousMonth.Month);
        lastDayOfPreviousMonth = new DateTime(lastDayOfPreviousMonth.Year, lastDayOfPreviousMonth.Month, lastDay);
        firstDayOfPreviousMonth = new DateTime(lastDayOfPreviousMonth.Year, lastDayOfPreviousMonth.Month, 1);
        lastDay = DateTime.DaysInMonth(SelectedDate.Year, SelectedDate.Month);
        lastDayOfSelectedMonth = new DateTime(SelectedDate.Year, SelectedDate.Month, lastDay);

        getData();
        Refresh = refresh;
    }

    bool filter(object o) {
        var p = (MonthlyBalance)o;

        switch (state) {
            case 0: return true;
            case 1: return p.Payment != 0;
            default: return p.Payment == 0 && p.Due != 0;
        }
    }
    void onCollectionChanged(object? sender, NotifyCollectionChangedEventArgs e) {
        TotalDue = 0;
        TotalLastDue = 0;
        TotalPaid = 0;
        foreach (MonthlyBalance item in Payments) {
            TotalDue += item.Due;
            TotalLastDue += item.LastMonthDue;
            TotalPaid += item.Payment;
        }
        OnPropertyChanged(nameof(TotalDue));
        OnPropertyChanged(nameof(TotalLastDue));
        OnPropertyChanged(nameof(TotalPaid));
    }

    void refresh() {
        //BusyWindow.Activate(ReportMonthlyBalance.Left, ReportMonthlyBalance.Top, ReportMonthlyBalance.Width, ReportMonthlyBalance.Height, "Reloading ...");

        lastDayOfPreviousMonth = SelectedDate.AddMonths(-1);
        var lastDay = DateTime.DaysInMonth(lastDayOfPreviousMonth.Year, lastDayOfPreviousMonth.Month);
        lastDayOfPreviousMonth = new DateTime(lastDayOfPreviousMonth.Year, lastDayOfPreviousMonth.Month, lastDay);
        firstDayOfPreviousMonth = new DateTime(lastDayOfPreviousMonth.Year, lastDayOfPreviousMonth.Month, 1);
        lastDay = DateTime.DaysInMonth(SelectedDate.Year, SelectedDate.Month);
        lastDayOfSelectedMonth = new DateTime(SelectedDate.Year, SelectedDate.Month, lastDay);

        getData();
        //BusyWindow.Terminate();
    }
    async void getData() {
        Status = "requesting data";
        var request = new RentManagerRequest() {
            UserId = App.service.UserId,
            Method = (int)Function.GetMonthlyBalance,
            Args = new object[] {
                firstDayOfPreviousMonth.ToString("yyyy-MM-dd"),
                lastDayOfPreviousMonth.ToString("yyyy-MM-dd"),
                lastDayOfSelectedMonth.ToString("yyyy-MM-dd")
            }
        };
        var response = await App.service.GetResponse(request);
        await Task.Delay(500);
        if (!response.IsSuccess) {
            Status = LocalConstants.DownMessage;
            return;
        }
        Status = $"received {response.Packet.Length.ToString("N0")} bytes";
        await Task.Delay(500);
        await addEntries(response.Packet);
    }
    Task addEntries(byte[] packet) {
        payments.Clear();
        var span = new ReadOnlySpan<byte>(packet);
        int read = 0;
        while (read < span.Length) {
            var size = BitConverter.ToInt32(span.Slice(read, 4));
            read += 4;
            var e = NetMonthlyBalance.FromBytes(span.Slice(read, size));
            read += size;

            payments.Add(new MonthlyBalance() {
                Date = e.Date,
                Plot = e.Plot,
                Tenant = e.Tenant,
                Due = e.Due,
                LastMonthDue = e.LastMonthDue,
                Payment = e.Payment
            });
        }
        return Task.CompletedTask;
    }
}
