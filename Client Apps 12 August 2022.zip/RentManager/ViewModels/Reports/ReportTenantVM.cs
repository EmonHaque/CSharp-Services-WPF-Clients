﻿class ReportTenantVM : ReportBase
{
    public override ICollectionView selectionView => tenants.View;
    protected override string Where => where;
    string where;
    CollectionViewSource tenants;
    public ReportTenantVM()  {
        where = "TenantId";
        tenants = new CollectionViewSource() { 
            Source = AppData.tenants
        };
        selectionView.Filter = filterTenants;
    }
    protected override void setTitleAndSubTitle() {
        var tenant = AppData.tenants.First(x => x.Id == Id);
        Title = tenant.Name;
        SubTitle = tenant.Address;
    }
    bool filterTenants(object o) {
        if (string.IsNullOrWhiteSpace(Query)) return true;
        return ((Tenant)o).Name.ToLower().Contains(Query);
    }
}
