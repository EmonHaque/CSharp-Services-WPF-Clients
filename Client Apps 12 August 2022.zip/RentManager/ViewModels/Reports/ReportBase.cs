﻿using static System.Windows.Forms.VisualStyles.VisualStyleElement;

public abstract class ReportBase : Notifiable
{
    List<ReportEntry> reserved, reportables;
    int? id;
    public int? Id {
        get { return id; }
        set {
            if (id != value) {
                id = value;
                updateReportables();
                IsRefreshValid = value == null ? false : true;
                OnPropertyChanged(nameof(IsRefreshValid));
            }
        }
    }
    string query;
    public string Query {
        get { return query; }
        set {
            if (query != value) {
                query = value?.Trim().ToLower();
                selectionView.Refresh();
            }
        }
    }
    string particularsQuery;
    public string ParticularsQuery {
        get { return particularsQuery; }
        set {
            if (particularsQuery != value) {
                particularsQuery = value?.Trim().ToLower();
                Reportables.Refresh();
            }
        }
    }

    string heading;
    public string Heading {
        get { return heading; }
        set { heading = value; OnPropertyChanged(nameof(Heading)); }
    }
    public ICollectionView Reportables { get; set; }
    public ReportDates Dates { get; set; }

    public int TotalEntry { get; set; }
    public int TotalReceivable { get; set; }
    public int TotalReceipt { get; set; }
    public Action RefreshReport { get; set; }
    public Action ExportCSV { get; set; }
    public Action PrintReport { get; set; }
    public bool IsPrintOrExportValid { get; set; }
    public bool IsRefreshValid { get; set; }
    protected string Title { get; set; }
    protected string SubTitle { get; set; }
    public abstract ICollectionView selectionView { get; }
    protected abstract string Where { get; }
    
    public ReportBase() {
        Dates = new ReportDates();
        RefreshReport = refreshReport;
        ExportCSV = exportCSV;
        PrintReport = printReport;
    }

    #region Commands
    void refreshReport() {
        BusyWindow.Activate("Refreshing ...");
        if (reserved == null) {
            updateReportables();
            BusyWindow.Terminate();
            return;
        }
        else if (reserved.First().Date == Dates.From && reserved.Last().Date == Dates.To) {
            updateReportables();
            BusyWindow.Terminate();
            return;
        }
        var lastEntry = reserved.LastOrDefault(x => x.Date < Dates.From);
        var newReportables = new List<ReportEntry>();
        if (lastEntry != null) {
            newReportables.Add(new ReportEntry() {
                Date = Dates.From,
                Balance = lastEntry.Balance,
                Particulars = "balance b/d",
                Narration = string.Empty
            });
        }
        var entries = reserved.Where(x => x.Date >= Dates.From && x.Date <= Dates.To).ToList();
        var receivable = entries.Sum(x => x.Receivable);
        var receipt = entries.Sum(x => x.Receipt);
        newReportables.AddRange(entries);

        if (Reportables is not null) Reportables.CollectionChanged -= onCollectionChanged;
        reportables = newReportables;
        Reportables = CollectionViewSource.GetDefaultView(reportables);
        Reportables.Filter = filter;
        Reportables.CollectionChanged += onCollectionChanged;
        OnPropertyChanged(nameof(Reportables));
        BusyWindow.Terminate();
    }
    void exportCSV() {
        var dialog = new SaveFileDialog() {
            FileName = "Report",
            Filter = "CSV files (.csv)|*.csv"
        };
        if (dialog.ShowDialog() != true) return;
        BusyWindow.Activate("Exporting ...");

        var builder = new StringBuilder();
        builder.Append("Date, Particulars, Receivable/Payment, Receipt, Balance").AppendLine();
        foreach (var item in reportables) {
            builder
                .Append(item.Date.ToShortDateString()).Append(",")
                .Append("\"").Append(item.Particulars).Append(item.Narration).Append("\"").Append(",")
                .Append(item.Receivable).Append(",")
                .Append(item.Receipt).Append(",")
                .Append(item.Balance).AppendLine();
        }
        System.IO.File.WriteAllText(System.IO.Path.GetFullPath(dialog.FileName), builder.ToString());
        BusyWindow.Terminate();
    }
    void printReport() {
        var dialog = new PrintDialog();
        if (dialog.ShowDialog() != true) return;
        BusyWindow.Activate("Printing ...");
        var size = new Size(dialog.PrintableAreaWidth, dialog.PrintableAreaHeight);
        var document = new FixedDocument();
        var pages = new List<LedgerPage>();
        var page = getPage(document, null);
        pages.Add(page);
        for (int i = 0; i < reportables.Count; i++) {
            if (!page.AddEntry(reportables[i])) {
                page.IsComplete = true;
                page.LastEntry = reportables[i - 1];
                page = getPage(document, page);
                page.AddEntry(reportables[i]);
                pages.Add(page);
            }
        }
        page.IsComplete = true;
        foreach (var p in pages) {
            p.NumberOfPage = document.Pages.Count;
        }
        document.DocumentPaginator.PageSize = size;
        dialog.PrintDocument(document.DocumentPaginator, "");
        BusyWindow.Terminate();
    }
    #endregion

    protected abstract void setTitleAndSubTitle();
    async void updateReportables() {
        if (Reportables is not null) Reportables.CollectionChanged -= onCollectionChanged;
        TotalEntry = TotalReceipt = TotalReceivable = 0;
        if (Id == null) {
            clearReportables();
            IsRefreshValid = IsPrintOrExportValid = false;
            OnPropertyChanged(nameof(IsPrintOrExportValid));
            OnPropertyChanged(nameof(IsRefreshValid));
            return;
        }
        int balance = 0;
        Heading = "requesting data";
        var request = new RentManagerRequest() {
            UserId = App.service.UserId,
            Method = (int)Function.GetLedger,
            Args = new object[] { Id, Where }
        };
        var response = await App.service.GetResponse(request);
        await Task.Delay(500);
        
        if (!response.IsSuccess) {
            Heading = LocalConstants.DownMessage;
            return;
        }
        Heading = $"received {response.Packet.Length.ToString("N0")} bytes";
        await Task.Delay(500);
        var reserved = await getEntries(response.Packet, ref balance);

        if (reserved.Count > 0) {
            Dates.Start = reserved.First().Date;
            Dates.End = reserved.Last().Date;
            Dates.From = reserved.First().Date;
            Dates.To = reserved.Last().Date;
            Heading = $"available from {Dates.From.ToString("dd MMMM, yyyy")} to {Dates.To.ToString("dd MMMM, yyyy")}";


            reportables = reserved;
            Reportables = CollectionViewSource.GetDefaultView(reserved);
            Reportables.Filter = filter;
            Reportables.CollectionChanged += onCollectionChanged;

            IsPrintOrExportValid = true;
            OnPropertyChanged(nameof(Dates));
            OnPropertyChanged(nameof(Reportables));
            OnPropertyChanged(nameof(IsPrintOrExportValid));
        }
        else {
            Heading = "no data available";
            clearReportables();
            IsPrintOrExportValid = false;
            OnPropertyChanged(nameof(IsPrintOrExportValid));
        }
        OnPropertyChanged(nameof(TotalEntry));
        OnPropertyChanged(nameof(TotalReceipt));
        OnPropertyChanged(nameof(TotalReceivable));
    }
    Task<List<ReportEntry>> getEntries(byte[] packet, ref int balance) {
        reserved = new List<ReportEntry>();
        var span = new ReadOnlySpan<byte>(packet);
        int read = 0;
        while (read < span.Length) {
            var size = BitConverter.ToInt32(span.Slice(read, 4));
            read += 4;
            var e = NetReportEntry.FromBytes(span.Slice(read, size));
            read += size;

            var entry = new ReportEntry() {
                Date = DateTime.ParseExact(e.Date, "yyyy-MM-dd", CultureInfo.CurrentCulture.DateTimeFormat),
                Particulars = e.Particulars
            };
            TotalEntry++;
            if (e.ControlId == AppData.controlIdOfReceivable || e.ControlId == AppData.controlIdOfPayment) {
                TotalReceivable += e.Amount;
                balance -= e.Amount;
                entry.Receivable = e.Amount;
            }
            else {
                TotalReceipt += e.Amount;
                balance += e.Amount;
                entry.Receipt = e.Amount;
            }
            entry.Balance = balance;
            reserved.Add(entry);
        }
        return Task.FromResult(reserved);
    }
    bool filter(object o) {
        if (string.IsNullOrWhiteSpace(ParticularsQuery)) return true;
        var entry = (ReportEntry)o;
        return entry.Particulars.Contains(ParticularsQuery, StringComparison.InvariantCultureIgnoreCase);
    }
    void onCollectionChanged(object? sender, NotifyCollectionChangedEventArgs e) {
        TotalEntry = TotalReceipt = TotalReceivable = 0;
        foreach (ReportEntry entry in Reportables) {
            TotalEntry++;
            TotalReceipt += entry.Receipt;
            TotalReceivable += entry.Receivable;
        }
        OnPropertyChanged(nameof(TotalEntry));
        OnPropertyChanged(nameof(TotalReceipt));
        OnPropertyChanged(nameof(TotalReceivable));
    }
    void clearReportables() {
        Dates.Start = Dates.End = Dates.From = Dates.To = DateTime.Today;

        reserved = null;
        reportables = null;
        Reportables = null;
        OnPropertyChanged(nameof(Dates));
        OnPropertyChanged(nameof(Reportables));
    }
    LedgerPage getPage(FixedDocument doc, LedgerPage previousPage) {
        LedgerPage page;
        if (previousPage == null) {
            setTitleAndSubTitle();
            page = new LedgerPage(doc.DocumentPaginator.PageSize) {
                Title = Title,
                SubTitle = SubTitle,
                Period = $"period from {Dates.From.ToString("dd MMMM, yyyy")} to {Dates.To.ToString("dd MMMM, yyyy")}",
                FootNote = $"Generated on {DateTime.Now.ToString("dd MMMM, yyyy | hh:mm:ss tt")}",
            };
        }
        else page = new LedgerPage(previousPage);
        doc.Pages.Add(new PageContent() { Child = page.Page });
        return page;
    }
}
