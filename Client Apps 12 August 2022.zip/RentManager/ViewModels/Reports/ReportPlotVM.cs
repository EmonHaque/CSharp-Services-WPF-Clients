﻿class ReportPlotVM : ReportBase
{
    public override ICollectionView selectionView => plots.View;
    protected override string Where => where;
    string where;
    CollectionViewSource plots;
    public ReportPlotVM() {
        where = "PlotId";
        plots = new CollectionViewSource() {
            Source = AppData.plots 
        };
        selectionView.Filter = filterPlots;
    }
    protected override void setTitleAndSubTitle() {
        var plot = AppData.plots.First(x => x.Id == Id);
        Title = plot.Name;
        SubTitle = plot.Description;
    }
    bool filterPlots(object o) {
        if (string.IsNullOrWhiteSpace(Query)) return true;
        return ((Plot)o).Name.ToLower().Contains(Query);
    }
}
