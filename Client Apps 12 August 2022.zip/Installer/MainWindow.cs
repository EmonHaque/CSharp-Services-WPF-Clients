﻿class MainWindow : Window
{
    const string folderName = "Haque Apps";
    static string startMenu = Environment.GetFolderPath(Environment.SpecialFolder.CommonStartMenu);
    const string programPath = @"C:\Program Files\" + folderName;
    string menuPath = System.IO.Path.Combine(startMenu, "Programs", folderName);

    double radius = 5;
    Border windowBorder;
    ListBox box;
    Socket client;
    List<AppInfoExtended> apps;
    Button installButton, unInstallButton;
    SolidColorBrush background;

    public MainWindow() {
        Height = 720;
        Width = 1280;
        WindowStartupLocation = WindowStartupLocation.CenterScreen;
        WindowStyle = WindowStyle.None;
        AllowsTransparency = true;
        WindowChrome.SetWindowChrome(this, new WindowChrome() {
            ResizeBorderThickness = new Thickness(5),
            CaptionHeight = 0
        });
        //background = new SolidColorBrush(Color.FromRgb(70, 70, 70));
        Control.StyleProperty.OverrideMetadata(typeof(Control), new FrameworkPropertyMetadata() {
            DefaultValue = new Style() {
                Setters = {
                    new Setter(Control.BackgroundProperty, new SolidColorBrush(Color.FromRgb(70, 70, 70))),
                    new Setter(Control.ForegroundProperty, Brushes.LightGray)
                }
            }
        });
        installButton = new Button() { 
            Content = "Install ",
            HorizontalAlignment = HorizontalAlignment.Right
        };
        unInstallButton = new Button() {
            Content = "Remove ",
            HorizontalAlignment = HorizontalAlignment.Left
        };
        box = new ListBox() {
            HorizontalContentAlignment = HorizontalAlignment.Stretch,
            ItemTemplate = new AppInfoTemplate()
        };
        Grid.SetRow(installButton, 1);
        Grid.SetRow(unInstallButton, 1);
        var grid = new Grid() {
            RowDefinitions = {
                new RowDefinition(),
                new RowDefinition(){Height = GridLength.Auto}
            },
            Children = { box, unInstallButton, installButton }
        };
        windowBorder = new Border() {
            CornerRadius = new CornerRadius(radius),
            BorderThickness = new Thickness(0.75),
            BorderBrush = Brushes.LightGray,
            Child = grid
        };
        AddVisualChild(windowBorder);
        installButton.Click += onInstall;
        unInstallButton.Click += onUninstall;
    }

    void onUninstall(object sender, RoutedEventArgs e) {
        if (System.IO.Directory.Exists(menuPath))
            System.IO.Directory.Delete(menuPath, true);
        if (System.IO.Directory.Exists(programPath)) 
            System.IO.Directory.Delete(programPath, true);
    }

    void onInstall(object sender, RoutedEventArgs e) {
        int total = 0;
        List <AppInfoExtended> selected = new();
        var bytes = new List<ArraySegment<byte>>();
        foreach (var app in apps) {
            if (app.IsSelected) {
                var a = new AppInfo() {
                    Name = app.Name,
                    Version = app.Name
                };
                var b = a.GetBytes();
                bytes.AddRange(b);
                total += b.Sum(x => x.Count);
                selected.Add(app);
            }
        }
        bytes.Insert(0, BitConverter.GetBytes(total));
        client.Send(bytes);


        var list = new Dictionary<string, List<UpdatedFile>>();
        for (int i = 0; i < selected.Count; i++) {
            var header = new byte[4];
            int read = client.Receive(header);
            while (read < header.Length) {
                read += client.Receive(header, read, header.Length - read, SocketFlags.None);
            }
            var packet = new byte[BitConverter.ToInt32(header)];
            read = client.Receive(packet);
            while (read < packet.Length) {
                read += client.Receive(packet, read, packet.Length - read, SocketFlags.None);
            }
            var span = new ReadOnlySpan<byte>(packet);
            var files = new List<UpdatedFile>();
            read = 0;
            while (read < packet.Length) {
                var length = BitConverter.ToInt32(span.Slice(read, 4));
                read += 4;
                var file = UpdatedFile.FromBytes(span.Slice(read, length).ToArray()); // use span?
                files.Add(file);
                read += length;
                
            }
            list.Add(selected[i].Name, files);
        }
        foreach (var item in list) {
            install(item);
        }
    }
    void install(KeyValuePair<string, List<UpdatedFile>> app) {
        if (!System.IO.Directory.Exists(menuPath))
            System.IO.Directory.CreateDirectory(menuPath);
        if (!System.IO.Directory.Exists(programPath)) {
            System.IO.Directory.CreateDirectory(programPath);
        }
        if (app.Key.Equals("Launcher")) {
            foreach (var file in app.Value) {
                using (var stream = new System.IO.FileStream(programPath + "\\" + file.Name, System.IO.FileMode.Create, System.IO.FileAccess.Write))
                    stream.Write(file.Content, 0, file.Content.Length);
            }
        }
        else {
            var dirPath = System.IO.Path.Combine(programPath, app.Key);
            System.IO.Directory.CreateDirectory(dirPath);
            string exePath = "";
            string iconPath = "";
            foreach (var file in app.Value) {
                using (var stream = new System.IO.FileStream(dirPath + "\\" + file.Name, System.IO.FileMode.Create, System.IO.FileAccess.Write))
                    stream.Write(file.Content, 0, file.Content.Length);

                if (file.Name.EndsWith(".exe")) {
                    exePath = System.IO.Path.Combine(dirPath, file.Name);
                }
                if (file.Name.EndsWith(".ico")) {
                    iconPath = System.IO.Path.Combine(dirPath, file.Name);
                }
            }
            string shortcutLocation = System.IO.Path.Combine(menuPath, app.Key + ".lnk");
            var shell = new WshShell();
            var shortcut = (IWshShortcut)shell.CreateShortcut(shortcutLocation);
            shortcut.IconLocation = iconPath;
            shortcut.Description = app.Key + " Client";
            shortcut.TargetPath = exePath;
            shortcut.Save();
        }
    }

    protected override void OnActivated(EventArgs e) {
        base.OnActivated(e);
        client = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        client.Connect(new IPEndPoint(IPAddress.Parse(Addresses.InstallAddress), Addresses.InstallPort));

        var header = new byte[4];
        int read = client.Receive(header);
        while (read < header.Length) {
            read += client.Receive(header, read, header.Length - read, SocketFlags.None);
        }
        var packet = new byte[BitConverter.ToInt32(header)];
        read = client.Receive(packet);
        while (read < packet.Length) {
            read += client.Receive(packet, read, packet.Length - read, SocketFlags.None);
        }
        var span = new ReadOnlySpan<byte>(packet);
        int start = 0;
        read = 0;

        apps = new List<AppInfoExtended>();
        while (read < span.Length) {
            while (span[read] != 0) read++;
            var name = Encoding.ASCII.GetString(span.Slice(start, read - start));
            start = ++read;
            while (span[read] != 0) read++;
            var version = Encoding.ASCII.GetString(span.Slice(start, read - start));
            apps.Add(new AppInfoExtended() {
                Name = name,
                Version = version
            });
            start = ++read;
        }
        box.ItemsSource = apps;
    }
    protected override int VisualChildrenCount => 1;
    protected override Visual GetVisualChild(int index) => windowBorder;
}
