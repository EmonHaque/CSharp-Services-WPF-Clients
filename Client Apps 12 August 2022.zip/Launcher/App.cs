﻿class App : Application
{
    [STAThread]
    static void Main(string[] args) => new App().Run();
    protected override void OnStartup(StartupEventArgs e) {
        var window = new LaunchWindow();
        window.Show();
    }
}
