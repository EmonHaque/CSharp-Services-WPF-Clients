﻿public abstract class ClientApp : Application
{
    public static ServicePack service;
    protected abstract string appTitle { get; }
    protected abstract IPAddress address { get; }
    protected abstract int port { get; }
    protected abstract Request initRequest { get; }
    protected abstract ImageSource appIcon { get; }
    protected abstract AppDataBase baseData { get; }
    protected abstract Window SetResourceAndWindow();

    protected static void launch(LaunchArgs lArg) {
        var launchArg = $"\"{lArg.App},{lArg.Version},{lArg.Path}\"";
        var launcherPath = System.IO.Path.GetFullPath(System.IO.Path.Combine(lArg.Path, @"..\"));

        var process = new ProcessStartInfo();
        process.FileName = launcherPath + "\\Launcher.exe";
        process.UseShellExecute = true;
        process.Arguments = launchArg;
        process.Verb = "runas";
        Process.Start(process);
    }

    protected override void OnStartup(StartupEventArgs e) {
        SetStyle();
        Constants.AppTitle = appTitle;
        service = new ServicePack() {
            Address = address,
            Port = port
        };
#if DEBUG
        service.Receiver = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        service.Sender = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        bool isConnected = false;
        try {
            service.Receiver.Connect(service.Address, service.Port);
            service.Receiver.Send(BitConverter.GetBytes(true));

            service.Sender.Connect(service.Address, service.Port);
            service.Sender.Send(BitConverter.GetBytes(false));
            
            service.Sender.Send(initRequest.GetBytes());
        }
        catch { isConnected = false; }

        var loading = new LoadingWindow(appTitle, appIcon);
        baseData.SetLoadingWindow(loading, service);
        baseData.Received += onInitialLoadComplete;
        loading.Show();
#else
        var login = new LoginWindow(Constants.AppTitle, service);
        login.LoggedIn += onLoggedIn;
        login.Show();
#endif
    }
    void onLoggedIn(LoginWindow dow, Socket socket) {
        service.Signatory = socket;
        dow.LoggedIn -= onLoggedIn;
        dow.InService += onInService;
    }
    void onInService(LoginWindow dow) {
        dow.InService -= onInService;
        service.Sender = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        service.Sender.Connect(service.Address, service.Port);
        service.Sender.Send(BitConverter.GetBytes(false));
        service.Sender.Send(initRequest.GetBytes());

        var loading = new LoadingWindow(appTitle, appIcon);
        baseData.SetLoadingWindow(loading, service);
        baseData.Received += onInitialLoadComplete;
        loading.Show();
        dow.Close();
    }
    void onInitialLoadComplete(LoadingWindow dow) {
        baseData.Received -= onInitialLoadComplete;
        Current.MainWindow = SetResourceAndWindow();
        if (appIcon is not null) Current.MainWindow.Icon = appIcon;
        //hook up UnhandledException before showing MainWindow?
        Current.DispatcherUnhandledException += unhandledHandler;
        Current.MainWindow.Show();
        dow.Close();
    }
    void SetStyle() {
        Current.Resources.Add(SystemParameters.VerticalScrollBarWidthKey, Constants.ScrollBarThickness);
        Current.Resources.Add(SystemParameters.HorizontalScrollBarHeightKey, Constants.ScrollBarThickness);

        Control.StyleProperty.OverrideMetadata(typeof(ScrollBar), new FrameworkPropertyMetadata() {
            DefaultValue = new Style() {
                Setters = { new Setter(ScrollBar.TemplateProperty, new VScrollTemplate()) },
                Triggers = {
                    new Trigger() {
                        Property = ScrollBar.OrientationProperty,
                        Value = Orientation.Horizontal,
                        Setters = { new Setter(ScrollBar.TemplateProperty, new HScrollTemplate()) }
                    }
                }
            }
        });
        ListBoxItem.StyleProperty.OverrideMetadata(typeof(ListBox), new FrameworkPropertyMetadata() {
            DefaultValue = new Style() {
                Setters = {
                    new Setter(ListBox.TemplateProperty, new ListBoxTemplate()),
                    new Setter(ListBox.BorderThicknessProperty, new Thickness(0)),
                    new Setter(ListBox.HorizontalContentAlignmentProperty, HorizontalAlignment.Stretch),
                    new Setter(ListBox.IsSynchronizedWithCurrentItemProperty, true),
                    new Setter(TextElement.ForegroundProperty, Brushes.LightGray)
                }
            }
        });
        ListBoxItem.StyleProperty.OverrideMetadata(typeof(ListBoxItem), new FrameworkPropertyMetadata() {
            DefaultValue = new Style() {
                Setters = {
                    new Setter(ListBoxItem.TemplateProperty, new ListBoxItemTemplate()),
                    new Setter(ListBoxItem.FocusVisualStyleProperty, null)
                }
            }
        });
        Separator.StyleProperty.OverrideMetadata(typeof(Separator), new FrameworkPropertyMetadata() {
            DefaultValue = new Style() {
                Setters = {
                    new Setter(Separator.BorderThicknessProperty, new Thickness(0.1))
                }
            }
        });
        ToolTip.StyleProperty.OverrideMetadata(typeof(ToolTip), new FrameworkPropertyMetadata() {
            DefaultValue = new Style() {
                Setters = {
                    new Setter(ToolTip.TemplateProperty, new ToolTipTemplate()),
                    new Setter(ToolTip.HorizontalOffsetProperty, 10d),
                    new Setter(ToolTip.VerticalOffsetProperty, 10d),
                }
            }
        });
        Control.StyleProperty.OverrideMetadata(typeof(Control), new FrameworkPropertyMetadata() {
            DefaultValue = new Style() {
                Setters = {
                    new Setter(MenuItem.BorderThicknessProperty, new Thickness(0)),
                    new Setter(MenuItem.PaddingProperty, new Thickness(0)),
                    new Setter(Control.BackgroundProperty, Constants.Background),
                    new Setter(Control.ForegroundProperty, Brushes.LightGray)
                }
            }
        });
    }
    void unhandledHandler(object sender, DispatcherUnhandledExceptionEventArgs e) {
        if (BusyWindow.IsOpened) BusyWindow.Terminate();
        InfoDialog.Activate("Exception", e.Exception.Message + "\n" + e.Exception.StackTrace);
        e.Handled = true;
    }
}
