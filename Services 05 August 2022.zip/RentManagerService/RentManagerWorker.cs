public class RentManagerWorker : BackgroundService
{
    Database db;
    Socket server;
    List<Socket> receivers;
    BlockingCollection<RawRequest> requests;
    BlockingCollection<List<ArraySegment<byte>>> responses;

    public RentManagerWorker() {
        db = new Database();
        receivers = new List<Socket>();
        requests = new BlockingCollection<RawRequest>();
        responses = new BlockingCollection<List<ArraySegment<byte>>>();
        server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        server.Bind(new IPEndPoint(IPAddress.Parse(Addresses.RentManagerAddress), Addresses.RentManagerPort));
        server.Listen(500);
        accept();
        new Thread(processRequests) { IsBackground = true }.Start();
    }

    void accept() {
        var e = new SocketAsyncEventArgs();
        e.Completed += onAccepted;
        bool started = server.AcceptAsync(e);
        if (!started) onAccepted(null, e);
    }
    void onAccepted(object sender, SocketAsyncEventArgs e) {
        e.Completed -= onAccepted;
        if (e.SocketError == SocketError.Success) {
            try {
                var socketType = new byte[1];
                e.AcceptSocket.Receive(socketType);
                var isReceiver = BitConverter.ToBoolean(socketType);
                if (isReceiver) {
                    receivers.Add(e.AcceptSocket);
                    e.Completed += onReceiverDisconnected;
                    bool started = e.AcceptSocket.ReceiveAsync(e);
                    if (!started) onReceiverDisconnected(null, e);
                }
                else {
                    e.Completed += onReceived;
                    bool started = e.AcceptSocket.ReceiveAsync(e);
                    if (!started) onReceived(null, e);
                }
            }
            catch {
                e.AcceptSocket.Close();
                e.AcceptSocket.Dispose();
            }
            finally { accept(); }
        }
        else {
            e.AcceptSocket.Close();
            e.AcceptSocket.Dispose();
            accept();
        }
    }
    void onReceived(object? sender, SocketAsyncEventArgs e) {
        var header = new byte[4];
        if (e.SocketError == SocketError.Success) {
            try {
                int read = e.AcceptSocket.Receive(header);
                while (read < header.Length) {
                    read += e.AcceptSocket.Receive(header, read, header.Length - read, SocketFlags.None);
                    // when you quit app by clicking on Stop Debugging button, it's stuck here in this loop! doesn't throw exception, why?
                    // closing app by clicking on close button, taskbar right click and Alt + F4 is ok 
                }
                var packet = new byte[BitConverter.ToInt32(header)];
                read = e.AcceptSocket.Receive(packet);
                while (read < packet.Length) {
                    read += e.AcceptSocket.Receive(packet, read, packet.Length - read, SocketFlags.None);
                }
                requests.Add(new RawRequest(e.AcceptSocket, packet));
                var started = e.AcceptSocket.ReceiveAsync(e);
                if (!started) onReceived(null, e);
            }
            catch { onSenderDisConnected(e); }
        }
        else onSenderDisConnected(e);
    }
    void onSenderDisConnected(SocketAsyncEventArgs e) {
        e.Completed -= onReceived;
        e.AcceptSocket.Close();
        e.AcceptSocket.Dispose();
        Debug.WriteLine("Sender cleaned up");
    }
    void onReceiverDisconnected(object? sender, SocketAsyncEventArgs e) {
        e.Completed -= onReceiverDisconnected;
        lock (receivers) {
            var socket = receivers.First(x => x.Equals(e.AcceptSocket));
            socket.Close();
            socket.Dispose();
            receivers.Remove(socket);
            Debug.WriteLine("Receiver cleaned up");
        }
    }
    void processRequests() {
        while (true) {
            var raw = requests.Take();
            var request = RentManagerRequest.FromBytes(raw.Packet);
            switch ((Function)request.Method) {
                case Function.AddPlot: responses.Add(db.AddPlot(request)); break;
                case Function.EditPlot: responses.Add(db.EditPlot(request)); break;
                case Function.AddSpace: responses.Add(db.AddSpace(request)); break;
                case Function.EditSpace: responses.Add(db.EditSpace(request)); break;
                case Function.AddTenant: responses.Add(db.AddTenant(request)); break;
                case Function.EditTenant: responses.Add(db.EditTenant(request)); break;
                case Function.AddHead: responses.Add(db.AddHead(request)); break;
                case Function.EditHead: responses.Add(db.EditHead(request)); break;
                case Function.AddLease: responses.Add(db.AddLease(request)); break;
                case Function.EditLease: responses.Add(db.EditLease(request)); break;
                case Function.EditTransaction: responses.Add(db.EditTransaction(request)); break;
                case Function.DeleteTransaction: responses.Add(db.DeleteTransaction(request)); break;
                case Function.AddTransactionsRegular: responses.Add(db.AddTransactionsRegular(request)); break;
                case Function.AddTransactionsIrregular: responses.Add(db.AddTransactionsIrregular(request)); break;
                case Function.AddBulkRent: responses.Add(db.AddBulkRent(request)); break;

                case Function.GetTransactions: raw.Sender.Send(db.GetTransactions(request)); break;
                case Function.GetBalance: raw.Sender.Send(db.GetBalance(request)); break;
                case Function.GetMonthlyBalance:raw.Sender.Send(db.GetMonthlyBalance(request)); break;
                case Function.GetLedger: raw.Sender.Send(db.GetLedger(request)); break;
                case Function.GetReceiptPayment: raw.Sender.Send(db.GetReceiptPayment(request)); break;
                case Function.GetPlotDueChart: raw.Sender.Send(db.GetPlotDueChart(request)); break;
                case Function.GetPlotwiseRent: raw.Sender.Send(db.GetPlotWiseRent(request)); break;
                case Function.GetTenantDetail: raw.Sender.Send(db.GetTenantDetail(request)); break;
                case Function.GetDepositDueRent: raw.Sender.Send(db.GetDepositDueRent(request)); break;
                case Function.GetInitialData: sendStartupPackets(raw.Sender); break;
                default: break;
            }
        }
    }
    void sendStartupPackets(Socket s) {
        s.Send(BitConverter.GetBytes(db.sizes.plot));
        foreach (var item in db.plotBytes) s.Send(item.Value);

        s.Send(BitConverter.GetBytes(db.sizes.space));
        foreach (var item in db.spaceBytes) s.Send(item.Value);

        s.Send(BitConverter.GetBytes(db.sizes.tenants));
        foreach (var item in db.tenantBytes) s.Send(item.Value);

        s.Send(BitConverter.GetBytes(db.sizes.leases));
        foreach (var item in db.leaseBytes) s.Send(item.Value);

        s.Send(BitConverter.GetBytes(db.sizes.receivables));
        foreach (var item in db.receivableBytes) s.Send(item.Value);

        s.Send(BitConverter.GetBytes(db.sizes.controlHeads));
        foreach (var item in db.controlHeadBytes) s.Send(item.Value);

        s.Send(BitConverter.GetBytes(db.sizes.heads));
        foreach (var item in db.headBytes) s.Send(item.Value);
    }
    protected override async Task ExecuteAsync(CancellationToken token) {
        while (!token.IsCancellationRequested) {
            var message = responses.Take();
            lock (receivers) {
                foreach (var socket in receivers) {
                    try { socket.Send(message); }
                    catch {
                        Debug.WriteLine("Broadcast catch");
                    }
                }
            }
        }
    }
}