﻿public class NetControlHead
{
    public int Id { get; set; }
    public string Name { get; set; }

    public List<ArraySegment<byte>> GetBytes() {
        return new List<ArraySegment<byte>>() {
            BitConverter.GetBytes(Id),
            Encoding.ASCII.GetBytes(Name + '\0')
        };
    }
}
