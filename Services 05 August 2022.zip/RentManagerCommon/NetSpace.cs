﻿public class NetSpace
{
    public int Id { get; set; }
    public int PlotId { get; set; }
    public string Name { get; set; }
    public string Description { get; set; }
    public bool IsVacant { get; set; }

    public List<ArraySegment<byte>> GetBytes() {
        return new List<ArraySegment<byte>>() {
            BitConverter.GetBytes(Id),
            BitConverter.GetBytes(PlotId),
            Encoding.ASCII.GetBytes(Name + '\0'),
            Encoding.ASCII.GetBytes(Description + '\0'),
            BitConverter.GetBytes(IsVacant)
        };
    }
    public static NetSpace FromBytes(ReadOnlySpan<byte> array) {
        int read = 8;
        int start = 8;
        int index = 0;
        var segments = new string[2];
        while (read < array.Length) {
            if (array[read] != 0) {
                read++;
                continue;
            }
            segments[index++] = Encoding.ASCII.GetString(array.Slice(start, read - start));
            start = ++read;
            if (index == segments.Length) break;
        }
        //read++;
        return new NetSpace() {
            Id = BitConverter.ToInt32(array.Slice(0, 4)),
            PlotId = BitConverter.ToInt32(array.Slice(4, 4)),
            Name = segments[0],
            Description = segments[1],
            IsVacant = BitConverter.ToBoolean(array.Slice(read, 1))
        };
    }
}
