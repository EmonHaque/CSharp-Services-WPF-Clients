﻿public enum Function
{
    AddPlot,
    AddSpace,
    AddTenant,
    AddHead,
    AddLease,
    AddTransactionsRegular,
    AddTransactionsIrregular,
    AddBulkRent,

    EditPlot,
    EditSpace,
    EditTenant,
    EditHead,
    EditLease,
    GetTransactions,
    EditTransaction,
    DeleteTransaction,

    GetInitialData,
    GetBalance,
    GetMonthlyBalance,
    GetLedger,
    GetReceiptPayment,
    GetPlotDueChart,
    GetPlotwiseRent,
    GetTenantDetail,
    GetDepositDueRent
}