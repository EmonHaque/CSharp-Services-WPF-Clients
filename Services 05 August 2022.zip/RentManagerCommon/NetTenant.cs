﻿public class NetTenant
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string Father { get; set; }
    public string Mother { get; set; }
    public string Husband { get; set; }
    public string Address { get; set; }
    public string NID { get; set; }
    public string ContactNo { get; set; }
    public bool HasLeft { get; set; }

    public List<ArraySegment<byte>> GetBytes() {
        return new List<ArraySegment<byte>>() {
            BitConverter.GetBytes(Id),
            Encoding.ASCII.GetBytes(Name + '\0'),
            Encoding.ASCII.GetBytes(Father + '\0'),
            Encoding.ASCII.GetBytes(Mother + '\0'),
            Encoding.ASCII.GetBytes(Husband + '\0'),
            Encoding.ASCII.GetBytes(Address + '\0'),
            Encoding.ASCII.GetBytes(NID + '\0'),
            Encoding.ASCII.GetBytes(ContactNo + '\0'),
            BitConverter.GetBytes(HasLeft)
         };
    }
    public static NetTenant FromBytes(ReadOnlySpan<byte> array) {
        int read = 4;
        int start = 4;
        int index = 0;
        var segments = new string[7];
        while (read < array.Length) {
            if (array[read] != 0) {
                read++;
                continue;
            }
            segments[index++] = Encoding.ASCII.GetString(array.Slice(start, read - start));
            start = ++read;
            if (index == segments.Length) break;
        }
        return new NetTenant() {
            Id = BitConverter.ToInt32(array.Slice(0, 4)),
            Name = segments[0],
            Father = segments[1],
            Mother = segments[2],
            Husband = segments[3],
            Address = segments[4],
            NID = segments[5],
            ContactNo = segments[6],
            HasLeft = BitConverter.ToBoolean(array.Slice(read, 1))
        };
    }
}
