﻿public class NetReportEntry
{
    public string Date { get; set; }
    public string Particulars { get; set; }
    public int Amount { get; set; }
    public int ControlId { get; set; }

    public List<ArraySegment<byte>> GetBytes() {
        var date = Encoding.ASCII.GetBytes(Date + '\0');
        var particulars = Encoding.ASCII.GetBytes(Particulars + '\0');
        var size = BitConverter.GetBytes(date.Length + particulars.Length + 8);
        return new List<ArraySegment<byte>>() {
            size, date, particulars,
            BitConverter.GetBytes(Amount),
            BitConverter.GetBytes(ControlId)
        };
    }
    public static NetReportEntry FromBytes(ReadOnlySpan<byte> array) {
        int read, start, index;
        read = start = index = 0;
        var segments = new string[2];
        while (read < array.Length) {
            if (array[read] != 0) {
                read++;
                continue;
            }
            segments[index++] = Encoding.ASCII.GetString(array.Slice(start, read - start));
            start = ++read;
            if (index == segments.Length) break;
        }
        var amount = BitConverter.ToInt32(array.Slice(start, 4));
        var controlId = BitConverter.ToInt32(array.Slice(start + 4, 4));
        return new NetReportEntry() {
            Date = segments[0],
            Particulars = segments[1],
            Amount = amount,
            ControlId = controlId
        };
    }
}