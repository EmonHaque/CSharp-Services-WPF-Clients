﻿class AppInfo
{
    public string Name { get; set; }
    public string Version { get; set; }
    public string Repository { get; set; }
}
