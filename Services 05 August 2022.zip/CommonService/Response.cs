﻿public class Response
{
    public bool IsSuccess { get; set; }
    public byte[] Packet { get; set; }
    public Response() { }
    public Response(bool success, byte[] packet) {
        IsSuccess = success;
        Packet = packet;
    }
}
