﻿public class User
{
    public string App { get; set; }
    public string UserName { get; set; }
    public string Password { get; set; }

    public List<ArraySegment<byte>> GetBytes() {
        var app = Encoding.ASCII.GetBytes(App + '\0');
        var user = Encoding.ASCII.GetBytes(UserName + '\0');
        var password = Encoding.ASCII.GetBytes(Password + '\0');
        var size = BitConverter.GetBytes(app.Length + user.Length + password.Length);
        return new List<ArraySegment<byte>>() { size, app, user, password };
    }
    public static User FromBytes(byte[] array) {
        int read, start, index;
        read = start = index = 0;
        var segments = new string[3];
        while (read < array.Length) {
            if (array[read] != 0) {
                read++;
                continue;
            }
            segments[index++] = Encoding.ASCII.GetString(array, start, read - start);
            start = ++read;
        }

        return new User() {
            App = segments[0],
            UserName = segments[1],
            Password = segments[2]
        };
    }
}
