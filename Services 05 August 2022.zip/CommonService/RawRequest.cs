﻿public class RawRequest
{
    public Socket Sender { get; set; }
    public byte[] Packet { get; set; }
    public RawRequest() { }
    public RawRequest(Socket sender, byte[] packet) {
        Sender = sender;
        Packet = packet;
    }
}
