﻿public abstract class Request
{
    public int UserId { get; set; }
    public int Method { get; set; }
    public object[] Args { get; set; }
    protected abstract List<ArraySegment<byte>> getArgBytes();
    public List<ArraySegment<byte>> GetBytes() {
        var args = Args is not null ? getArgBytes() : new List<ArraySegment<byte>>();
        int size = 4 + 4 + args.Sum(x => x.Count);
        var bytes = new List<ArraySegment<byte>>() {
            BitConverter.GetBytes(size),
            BitConverter.GetBytes(UserId),
            BitConverter.GetBytes(Method)
        };
        bytes.AddRange(args);
        return bytes;
    }  
}
