﻿class Attempt
{
    public int Id { get; set; }
    public int UserId { get; set; }
    public int AppId { get; set; }
    public int AddressId { get; set; }
    public string Port { get; set; }
    public string UserName { get; set; }
    public string Password { get; set; }
    public string DateIn { get; set; }
    public string TimeIn { get; set; }
    public bool IsSuccess { get; set; }
}
