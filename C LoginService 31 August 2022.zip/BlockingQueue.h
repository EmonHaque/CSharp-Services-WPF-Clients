#pragma once
#include <winsock2.h>
#include "Defined.h"

typedef struct {
	int count;
	int capacity;
	void* data;
	byte isWaiting;
	CRITICAL_SECTION section;
	HANDLE manualResetEvent;
} BlockingQueue;

void putInto(BlockingQueue*, void*);
void* takeOutFrom(BlockingQueue*);
//void destroyQueue(BlockingQueue* queue);