#pragma once

void SetServiceFunctions(void (*initializer)(), void (*mainRoutine)(), void (*cleaner)());
void RunServiceDebug();
void RunServiceRelease();