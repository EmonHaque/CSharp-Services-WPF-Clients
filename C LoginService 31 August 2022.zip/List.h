#pragma once
#include <malloc.h>
#include "Defined.h"

typedef struct {
	uint count;
	uint capacity;
	void* data;
} List;

void addToList(List* list, void* item);
void removeFromList(List* list, void* item);
