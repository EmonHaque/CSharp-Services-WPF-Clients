#pragma once
typedef unsigned long ulong;
typedef unsigned int uint;

#define CLIENT_SIZE sizeof(Client)
#define APP_INFO_SIZE sizeof(AppInfo)
#define APP_FILE_SIZE sizeof(AppFile)
#define POINTER_SIZE sizeof(void*)