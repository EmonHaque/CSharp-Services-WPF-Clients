#pragma once
#include <WinSock2.h>

int sendString(SOCKET, char*);
int sendNonNullString(SOCKET, char*);
int sendByte(SOCKET, byte);
int sendInt(SOCKET, int);