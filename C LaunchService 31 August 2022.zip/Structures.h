#pragma once
#include <WS2tcpip.h>
#include "List.h"

typedef struct {
	SOCKET socket;
	HANDLE thread;
} Client;

typedef struct {
	char* appName;
	char* version;
	char* repository;
	List fileList;
	int totalSize;
} AppInfo;

typedef struct {
	int fileLength;
	char* fileName;
	char* filePath;
} AppFile;