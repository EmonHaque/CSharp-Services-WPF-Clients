#include <tchar.h>
#include <Windows.h>
#include "Defined.h"

#pragma region variables
static wchar_t SERVICE_NAME[10];
static SERVICE_STATUS serviceStatus;
static SERVICE_STATUS_HANDLE serviceStatusHandle;
static HANDLE serviceStopEvent;
static void (*initializer)();
static void (*mainRoutine)();
static void (*cleaner)();
#pragma endregion

static void onStopping() {
	// Tell the service controller we are stopping
	serviceStatus.dwCurrentState = SERVICE_STOP_PENDING;
	serviceStatus.dwCheckPoint = 4;
	SetServiceStatus(serviceStatusHandle, &serviceStatus);
}
static void serviceCtrlHandler(ulong code) {
	switch (code) {
		case SERVICE_CONTROL_STOP:
			if (serviceStatus.dwCurrentState != SERVICE_RUNNING)
				break;
			//Perform tasks necessary to stop the service here
			cleaner();
			onStopping();
			// This will signal the worker thread to start shutting down
			SetEvent(serviceStopEvent);
			break;
	}
}
static void onStarting() {
	// Register our service control handler with the SCM
	serviceStatusHandle = RegisterServiceCtrlHandler(SERVICE_NAME, serviceCtrlHandler);
	// Tell the service controller we are starting
	ZeroMemory(&serviceStatus, sizeof(serviceStatus));
	serviceStatus.dwServiceType = SERVICE_WIN32_OWN_PROCESS;
	serviceStatus.dwCurrentState = SERVICE_START_PENDING;
	serviceStatus.dwCheckPoint = 0;
	SetServiceStatus(serviceStatusHandle, &serviceStatus);
}
static void onStarted() {
	// Tell the service controller we are started
	serviceStatus.dwControlsAccepted = SERVICE_ACCEPT_STOP;
	serviceStatus.dwCurrentState = SERVICE_RUNNING;
	SetServiceStatus(serviceStatusHandle, &serviceStatus);
}
static void onStopped() {
	// Tell the service controller we are stopped
	serviceStatus.dwCurrentState = SERVICE_STOPPED;
	serviceStatus.dwCheckPoint = 3;
	SetServiceStatus(serviceStatusHandle, &serviceStatus);
}
static ulong serviceWorker(void* p) {
	//  Periodically check if the service has been requested to stop
	while (WaitForSingleObject(serviceStopEvent, 0) != WAIT_OBJECT_0)
		//Perform main service function here
		mainRoutine();

	return 0;
}
static void serviceMain(ulong argc, ulong* argv) {
	onStarting();
	initializer();
	// Create a service stop event to wait on later
	serviceStopEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	onStarted();
	// Start a thread that will perform the main task of the service
	HANDLE serviceThread = CreateThread(NULL, 0, serviceWorker, NULL, 0, NULL);
	// Wait until our worker thread exits signaling that the service needs to stop
	WaitForSingleObject(serviceThread, INFINITE);
	//Perform any cleanup tasks
	CloseHandle(serviceStopEvent);
	CloseHandle(serviceThread);
	onStopped();
}

void SetServiceFunctions(void (*i)(), void (*m)(), void (*c)()) {
	initializer = i;
	mainRoutine = m;
	cleaner = c;
}
void RunServiceDebug() {
	initializer();
	mainRoutine();

	serviceStopEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	HANDLE serviceThread = CreateThread(NULL, 0, serviceWorker, NULL, 0, NULL);
	WaitForSingleObject(serviceThread, INFINITE);
	CloseHandle(serviceStopEvent);
	CloseHandle(serviceThread);

	cleaner();
}
void RunServiceRelease() {
	SERVICE_TABLE_ENTRY entry[] = {
		{SERVICE_NAME, (LPSERVICE_MAIN_FUNCTION)serviceMain},
		{NULL, NULL}
	};
	StartServiceCtrlDispatcher(entry);
}