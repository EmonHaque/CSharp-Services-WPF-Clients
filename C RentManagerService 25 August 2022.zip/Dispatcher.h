#pragma once
#include "Structures.h"
#include "Messenger.h"
#include "BlockingQueue.h"

extern byte isRunning;
extern BlockingQueue personalResponses;

extern BlockingQueue garbagePersonalResponses;
extern HANDLE dispatcherThread, freePersonalResponseThread;

void initializeDispatcher();
ulong DispatchPersonalResponse(void*);
ulong FreePersonalResponse(void*);

void sendShortMessage(ResponsePersonal*);
void sendTransactions(ResponsePersonal*);
void sendPlotDueChart(ResponsePersonal*);
void sendPlotwiseRent(ResponsePersonal*);
void sendTenantDetail(ResponsePersonal*);
void sendDepositDueRent(ResponsePersonal*);
void sendBalance(ResponsePersonal*);
void sendLedger(ResponsePersonal*);
void sendMonthlyBalance(ResponsePersonal*);
void sendReceiptPayment(ResponsePersonal*);