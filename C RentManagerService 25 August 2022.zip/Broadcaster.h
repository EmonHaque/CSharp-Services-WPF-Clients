#pragma once
#include <winsock2.h>
#include "Structures.h"
#include "List.h"
#include "BlockingQueue.h"
#include "Messenger.h"

extern CRITICAL_SECTION criticalReceiver;
extern byte isRunning;
extern List receivers, disconnectedReceivers;

extern HANDLE broadcastThread;
extern BlockingQueue publicResponses;

void initializeBroadcaster();
ulong BroadcastResponse(void*);

void sendPlot(ResponsePublic*);
void sendSpace(ResponsePublic*);
void sendEditedSpace(ResponsePublic*);
void sendTenant(ResponsePublic*);
void sendEditedTenant(ResponsePublic*);
void sendHead(ResponsePublic*);
void sendLease(ResponsePublic*);
void sendTransaction(ResponsePublic*);