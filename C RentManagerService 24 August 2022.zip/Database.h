#pragma once
#include <time.h>
#include <stdio.h>
#include "List.h"
#include "BlockingQueue.h"
#include "Messenger.h"
#include "Structures.h"
#include "sqlite3.h"

extern byte isRunning;
extern BlockingQueue requests;

extern sqlite3* connection;
extern sqlite3_stmt* command;
extern Totals total;
extern List plots, spaces, tenants, leases, receivables, controlHeads, heads;
extern BlockingQueue personalResponses;
extern BlockingQueue publicResponses;
extern BlockingQueue garbageRequests;
extern HANDLE requestProcessThread, freeRequestThread;

void initializeList();
ulong ProcessRequest(void*);
ulong FreeRequest(void*);
void initializeQueue();
int mallocate(char*, char**);

void initializeDatabase();
void sendStartupPackets(SOCKET);
void addShortPersonalResponse(Request*, ShortMessage*, int);
void addLongPersonalResponse(Request*, List, int);
void addPublicResponse(Request*, void*, int);

void addPlot(Request*);
void addSpace(Request*);
void addTenant(Request*);
void addHead(Request*);
void addLease(Request*);
void addTransactions(Request*);

void editPlot(Request*);
void editSpace(Request*);
void editTenant(Request*);
void editHead(Request*);
void editLease(Request*);
void editTransaction(Request*);
void deleteTransaction(Request*);

void getTransactions(Request* r);
void getPlotDueChart(Request*);
void getPlotWiseRent(Request*);
void getTenantDetail(Request*);
void getDepositDueRent(Request*);
void getBalance(Request*);
void getLedger(Request*);
void getMonthlyBalance(Request*);
void getReceiptPayment(Request*);