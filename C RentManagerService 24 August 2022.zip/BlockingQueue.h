#pragma once
#include <winsock2.h>
#include "Defined.h"

typedef struct {
	int count;
	int capacity;
	void* data;
	byte isWaiting;
	CRITICAL_SECTION section;
	HANDLE manualResetEvent;
} BlockingQueue;

void putIn(BlockingQueue*, void*);
void* takeOut(BlockingQueue*);
//void destroyQueue(BlockingQueue* queue);