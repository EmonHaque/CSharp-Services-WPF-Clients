﻿class PieChart : FrameworkElement
{
    VisualCollection children;
    TextBlock nameBlock, infoBlock, totalBlock, noInfoBlock;
    StackPanel infoPanel;
    Run value, percentage;
    Path ellipse;
    DoubleAnimation ellipseAnim, infoAnim;
    ScaleTransform infoScale, ellipseScale;
    double total;
    bool isSliceOpen, hasData;
    List<int> values;
    public string SelectedValuePath { get; set; }

    public PieChart() {
        children = new VisualCollection(this);
        Margin = new Thickness(10, 10, 10, 0);
        totalBlock = new TextBlock() {
            HorizontalAlignment = HorizontalAlignment.Center,
            Foreground = Brushes.CornflowerBlue,
            FontWeight = FontWeights.Bold,
            Margin = new Thickness(0, 10, 0, 5),
            IsHitTestVisible = false
        };
        value = new Run() { FontSize = 18, FontWeight = FontWeights.Bold, Foreground = Brushes.Gray };
        percentage = new Run() { Foreground = Brushes.LightGray };
        infoScale = new ScaleTransform(0, 0);
        nameBlock = new TextBlock() {
            TextAlignment = TextAlignment.Center,
            FontWeight = FontWeights.Bold,
            TextWrapping = TextWrapping.Wrap
        };
        infoBlock = new TextBlock() {
            TextAlignment = TextAlignment.Center,
            Inlines = { value, new LineBreak(), percentage }
        };
        noInfoBlock = new TextBlock() {
            TextAlignment = TextAlignment.Center,
            FontSize = 18,
            FontWeight = FontWeights.Bold,
            Foreground = Brushes.Gray,
            Inlines = {
                    new Run(){ Text = "No data"},
                    new LineBreak(),
                    new Run(){ Text = "available" }
                }
        };
        infoPanel = new StackPanel() {
            VerticalAlignment = VerticalAlignment.Center,
            RenderTransform = infoScale,
            Children = { nameBlock, infoBlock }
        };
        ellipseScale = new ScaleTransform(0, 0);
        ellipse = new Path() {
            Fill = Constants.Background,
            Data = new EllipseGeometry(),
            RenderTransform = ellipseScale
        };
        ellipseAnim = new DoubleAnimation() {
            BeginTime = TimeSpan.FromSeconds(0.5),
            Duration = TimeSpan.FromSeconds(1),
            EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
        };
        infoAnim = new DoubleAnimation() {
            Duration = TimeSpan.FromSeconds(0.5),
            EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
        };
    }

    void updateInfo(List<PlotSummary> summary) {
        if (!hasData) {
            //totalBlock.Visibility = Visibility.Collapsed;
            infoPanel.Visibility = Visibility.Collapsed;
            children.Add(noInfoBlock);
            return;
        }
        else infoPanel.Visibility = Visibility.Visible;
        totalBlock.Text = "Total " + total.ToString("N0") + " in " + values.Count.ToString("N0") + " plots";
        children.Add(totalBlock);
        children.Add(ellipse);
        children.Add(infoPanel);
        value.Text = percentage.Text = string.Empty;

        if (infoAnim.To != 1) return;
        foreach (var item in summary) {
            if (string.Equals(item.Name, nameBlock.Text)) {
                value.Text = item.Total.ToString("N0");
                percentage.Text = (item.Total / total * 100).ToString("N2") + "%";
                foreach (var slice in children.OfType<PieSlice>()) {
                    var s = (PlotSummary)slice.value;
                    if (string.Equals(s.Name, item.Name)) {
                        slice.IsSelected = true;
                        break;
                    }
                }
                break;
            }
        }
    }
    protected override Size ArrangeOverride(Size finalSize) {
        Point center = new();
        if (!hasData) {
            noInfoBlock.Measure(finalSize);
            center = new Point(finalSize.Width / 2, finalSize.Height / 2);
            var point = new Point(center.X - noInfoBlock.DesiredSize.Width / 2, center.Y - noInfoBlock.DesiredSize.Height / 2);
            noInfoBlock.Arrange(new Rect(point, noInfoBlock.DesiredSize));
            return finalSize;
        }
        totalBlock.Measure(finalSize);
        var availableHeight = finalSize.Height - totalBlock.DesiredSize.Height;
        center = new Point(finalSize.Width / 2, availableHeight / 2);
        double radius, startAngle, sweepAngle, endAngle;
        startAngle = sweepAngle = endAngle = 0d;
        radius = center.X > center.Y ? center.Y : center.X;
        int index = 0;
        foreach (PieSlice item in children.OfType<PieSlice>()) {
            var value = values[index];
            startAngle += sweepAngle;
            sweepAngle = 2 * Math.PI * value / total;
            endAngle = startAngle + sweepAngle;
            bool isLarge = (double)value / total > 0.5;
            item.SetParameters(center, radius, startAngle, sweepAngle, isLarge);
            item.Arrange(new Rect(item.DesiredSize));
            index++;
        }
        var geo = (EllipseGeometry)ellipse.Data;
        geo.RadiusX = geo.RadiusY = radius - 0.3 * radius;
        geo.Center = center;
        ellipse.Measure(finalSize);
        ellipse.Arrange(new Rect(ellipse.DesiredSize));
        ellipseScale.CenterX = center.X;
        ellipseScale.CenterY = center.Y;

        infoPanel.Width = geo.RadiusX;
        infoPanel.Measure(finalSize);
        infoScale.CenterX = infoPanel.DesiredSize.Width / 2;
        infoScale.CenterY = infoPanel.DesiredSize.Height / 2;
        double totalX = center.X - totalBlock.DesiredSize.Width / 2;
        infoPanel.Arrange(new Rect(new Point(center.X - infoScale.CenterX, center.Y - infoScale.CenterY), infoPanel.DesiredSize));
        totalBlock.Arrange(new Rect(new Point(totalX, availableHeight), totalBlock.DesiredSize));
        return finalSize;
    }
    protected override void OnMouseEnter(MouseEventArgs e) {
        var point = e.GetPosition(this);
        var result = VisualTreeHelper.HitTest(this, point);
        if (result != null) {
            if (result.VisualHit is PieSlice) {
                var slice = (PieSlice)result.VisualHit;
                var summary = (PlotSummary)slice.value;
                double val = Convert.ToDouble(summary.Total);
                nameBlock.Text = summary.Name;
                value.Text = val.ToString("N0");
                percentage.Text = (val / total * 100).ToString("N2") + "%";
                animate(1);
            }
        }
    }
    protected override void OnMouseLeave(MouseEventArgs e) {
        if (!isSliceOpen)
            animate(0);
    }
    protected override void OnPreviewMouseLeftButtonUp(MouseButtonEventArgs e) {
        if (e.OriginalSource is not PieSlice) {
            foreach (var piece in children.OfType<PieSlice>()) {
                if (piece.IsSelected) piece.IsSelected = false;
            }
            isSliceOpen = false;
            SelectedValue = null;
            return;
        }
        foreach (var piece in children.OfType<PieSlice>()) {
            if (piece.IsSelected) piece.IsSelected = false;
        }
        var slice = ((PieSlice)e.OriginalSource);
        slice.IsSelected = true;
        isSliceOpen = true;
        SelectedValue = (int?)slice.value.GetType().GetProperty(SelectedValuePath).GetValue(slice.value);

    }
    protected override Visual GetVisualChild(int index) => children[index];
    protected override int VisualChildrenCount => children.Count;
    void animate(double scale) {
        if (scale == 1) infoAnim.BeginTime = TimeSpan.FromSeconds(1);
        else infoAnim.BeginTime = TimeSpan.FromSeconds(0.5);
        ellipseAnim.To = infoAnim.To = scale;
        ellipse.RenderTransform.BeginAnimation(ScaleTransform.ScaleXProperty, ellipseAnim);
        ellipse.RenderTransform.BeginAnimation(ScaleTransform.ScaleYProperty, ellipseAnim);
        infoScale.BeginAnimation(ScaleTransform.ScaleXProperty, infoAnim);
        infoScale.BeginAnimation(ScaleTransform.ScaleYProperty, infoAnim);
    }
    public IEnumerable ItemsSource {
        get { return (IEnumerable)GetValue(ItemsSourceProperty); }
        set { SetValue(ItemsSourceProperty, value); }
    }
    public int? SelectedValue {
        get { return (int?)GetValue(SelectedValueProperty); }
        set { SetValue(SelectedValueProperty, value); }
    }
    public static readonly DependencyProperty SelectedValueProperty =
        DependencyProperty.Register("SelectedValue", typeof(int?), typeof(PieChart), new FrameworkPropertyMetadata() {
            DefaultValue = null,
            BindsTwoWayByDefault = true
        });

    public static readonly DependencyProperty ItemsSourceProperty =
        DependencyProperty.Register("ItemsSource", typeof(IEnumerable), typeof(PieChart), new PropertyMetadata(null, onSourceChanged));

    static void onSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
        var o = d as PieChart;
        if (e.OldValue != null) o.children.Clear();

        var items = ((IEnumerable<PlotSummary>)e.NewValue).ToList();
        Random rand = new();
        o.values = new List<int>();
        o.total = 0;
        foreach (PlotSummary item in items) {
            if (item.Total > 0) {
                o.total += item.Total;
                o.values.Add(item.Total);
                var color = Color.FromRgb((byte)rand.Next(0, 128), (byte)rand.Next(0, 128), (byte)rand.Next(0, 128));
                var slice = new PieSlice(new SolidColorBrush(color), item);
                o.children.Add(slice);
            }
        }
        o.hasData = o.total > 0;
        o.updateInfo(items);
        o.InvalidateArrange();
    }
}
