﻿class PlotDue : CardView
{
    public override string Header => "Due & Tenants";

    BarChart chart;
    ActionButton refresh;
    BiState state;
    TextBlock info, status;
    PlotDueVM viewModel;

    public override void OnFirstSight() {
        base.OnFirstSight();
        viewModel = new PlotDueVM();
        DataContext = viewModel;
        initializeUI();
        bind();
    }
    void refreshCommand() {
        if (BusyWindow.IsOpened) return;
        var position = PointToScreen(new Point(0, 0));
        var dpi = VisualTreeHelper.GetDpi(this);
        position.X /= dpi.DpiScaleX;
        position.Y /= dpi.DpiScaleY;
        position.X += Constants.CardMargin;
        position.Y += Constants.CardMargin;
        var width = ActualWidth - 2 * Constants.CardMargin;
        var height = ActualHeight - 2 * Constants.CardMargin;

        BusyWindow.Activate(position.X, position.Y, width, height, "Reloading ...");
        viewModel.Refresh.Invoke();
        BusyWindow.Terminate();
    }
    void initializeUI() {
        status = new TextBlock() {
            Margin = new Thickness(0, 0, 10, 0),
            VerticalAlignment = VerticalAlignment.Center
        };
        refresh = new ActionButton() {
            Command = refreshCommand,
            Icon = Icons.Refresh,
            ToolTip = "Reload"
        };
        state = new BiState() {
            IsTrue = true,
            Text = "All",
            Margin = new Thickness(0, 0, 5, 0)
        };
        addActions(new UIElement[] { status, state, refresh });

        chart = new BarChart();
        info = new TextBlock() {
            HorizontalAlignment = HorizontalAlignment.Right,
            Margin = new Thickness(0, 0, 10, 0),
            FontWeight = FontWeights.Bold
        };
        Grid.SetRow(chart, 1);
        var grid = new Grid() {
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { chart, info }
        };
        setContent(grid);
    }
    void bind() {
        status.SetBinding(TextBlock.TextProperty, new Binding(nameof(viewModel.Status)));
        chart.SetBinding(BarChart.ItemSourceProperty, new Binding(nameof(viewModel.Data)));
        state.SetBinding(BiState.IsTrueProperty, new Binding(nameof(viewModel.State)));
        info.SetBinding(TextBlock.TextProperty, new Binding(nameof(viewModel.Name)));
    }
}
