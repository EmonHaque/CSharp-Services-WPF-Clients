﻿class ReportMonthlyBalance : CardView
{
    ListBox list;
    MultiState state;
    CommandButton refresh;
    Border header, footer;
    TextBlock totalDue, totalLastDue, totalPaid, totalShortOrLong, totalEntry, status;
    Run entryCount;
    MonthPicker month;
    ReportMonthlyBalanceVM vm;

    public override void OnFirstSight() {
        base.OnFirstSight();
        vm = new ReportMonthlyBalanceVM();
        DataContext = vm;
        initializeUI();
        bind();
        vm.CoordinateRequested += updatePosition;
    }
    void onUnloaded(object sender, RoutedEventArgs e) {
        vm.CoordinateRequested -= updatePosition;
    }
    void initializeHeader() {
        var particulars = new TextBlock() { Text = "Particulars", VerticalAlignment = VerticalAlignment.Center };
        var date = new TextBlock() { Text = "Paid on", HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
        var due = new TextBlock() { Text = "Due", HorizontalAlignment = HorizontalAlignment.Right };
        var lastDue = new TextBlock() { Text = "Charge", HorizontalAlignment = HorizontalAlignment.Right };
        var payment = new TextBlock() { Text = "Receipt", HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center };
        var shortOrLong = new TextBlock() { Text = "Short", HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center };

        Grid.SetColumn(date, 1);
        Grid.SetColumn(due, 2);
        Grid.SetColumn(lastDue, 3);
        Grid.SetColumn(payment, 4);
        Grid.SetColumn(shortOrLong, 5);

        var grid = new Grid() {
            Margin = new Thickness(0, 0, Constants.ScrollBarThickness + Constants.ScrollPresenterMargin, 0),
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = new GridLength(80) },
                new ColumnDefinition(){ Width = new GridLength(70) },
                new ColumnDefinition(){ Width = new GridLength(70) },
                new ColumnDefinition(){ Width = new GridLength(70) },
                new ColumnDefinition(){ Width = new GridLength(70) }
            },
            Children = { particulars, date, due, lastDue, payment, shortOrLong }
        };

        header = new Border() {
            Padding = new Thickness(4, 2, 5, 2),
            BorderThickness = new Thickness(0, Constants.BottomLineThickness, 0, Constants.BottomLineThickness),
            BorderBrush = Brushes.LightGray,
            Child = grid
        };
        header.Resources.Add(typeof(TextBlock), new Style() {
            Setters = {
                    new Setter(TextBlock.FontWeightProperty, FontWeights.Bold)
                }
        });
    }
    void initializeFooter() {
        entryCount = new Run();
        totalEntry = new TextBlock() { Inlines = { "Total of ", entryCount } };
        totalDue = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };
        totalLastDue = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };
        totalPaid = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };
        totalShortOrLong = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Right };

        Grid.SetColumn(totalDue, 1);
        Grid.SetColumn(totalLastDue, 2);
        Grid.SetColumn(totalPaid, 3);
        Grid.SetColumn(totalShortOrLong, 4);

        var grid = new Grid() {
            Margin = new Thickness(0, 0, Constants.ScrollBarThickness + Constants.ScrollPresenterMargin, 0),
            ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = new GridLength(70) },
                    new ColumnDefinition(){ Width = new GridLength(70) },
                    new ColumnDefinition(){ Width = new GridLength(70) },
                    new ColumnDefinition(){ Width = new GridLength(70) }
                },
            Children = { totalEntry, totalDue, totalLastDue, totalPaid, totalShortOrLong }
        };
        footer = new Border() {
            Padding = new Thickness(4, 2, 5, 2),
            BorderThickness = new Thickness(0, Constants.BottomLineThickness, 0, 0),
            BorderBrush = Brushes.LightGray,
            Child = grid
        };
        footer.Resources.Add(typeof(TextBlock), new Style() {
            Setters = {
                    new Setter(TextBlock.FontWeightProperty, FontWeights.Bold)
                }
        });
    }
    void initializeUI() {
        month = new() { IsBottomTrimmed = true, Width = 175 };
        status = new TextBlock() { 
            HorizontalAlignment = HorizontalAlignment.Right,
            VerticalAlignment = VerticalAlignment.Center
        };
        state = new MultiState() {
            Margin = new Thickness(10, 0, 0, 0),
            Texts = new string[] { "All", "Paid", "Due" },
            Icons = new string[] { Icons.All, Icons.Checked, Icons.CloseCircle }
        };
        refresh = new CommandButton() {
            Icon = Icons.Refresh,
            Command =  vm.Refresh,
            Margin = new Thickness(10, 0, 0, 0),
            ToolTip = "Refresh"
        };
        Grid.SetColumn(status, 1);
        Grid.SetColumn(state, 2);
        Grid.SetColumn(refresh, 3);
        var topRow = new Grid() {
            Margin = new Thickness(0, -Constants.ControlMargin.Top, 0, 0),
            ColumnDefinitions = {
                new ColumnDefinition(){Width = GridLength.Auto},
                new ColumnDefinition(),
                new ColumnDefinition(){Width = GridLength.Auto},
                new ColumnDefinition(){Width = GridLength.Auto}
            },
            Children = {month, status, state, refresh}
        };
        list = new ListBox() {
            Margin = new Thickness(0, 3, 0, 3),
            ItemTemplate = new CurrentMonthTemplate(),
            GroupStyle = {
                new GroupStyle() {
                    ContainerStyle = new Style(typeof(GroupItem)) {
                        Setters = {
                            new Setter(GroupItem.TemplateProperty, new GroupedCurrentMonthTemplate())
                        }
                    }
                }
            },
            Resources = {{
                    typeof(ScrollViewer),
                    new Style() {
                        Setters = {
                            new Setter(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled),
                            new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate(false)),
                        }
                    }
                }
            }
        };
        initializeHeader();
        initializeFooter();
        Grid.SetRow(header, 1);
        Grid.SetRow(list, 2);
        Grid.SetRow(footer, 3);
        var grid = new Grid() {
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(),
                new RowDefinition(){Height = GridLength.Auto}
            },
            Children = { topRow, header, list, footer }
        };
        setContent(grid);
    }
    void bind() {
        status.SetBinding(TextBlock.TextProperty, new Binding(nameof(vm.Status)));
        month.SetBinding(MonthPicker.SelectedDateProperty, new Binding(nameof(vm.SelectedDate)));
        list.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(vm.Payments)));
        state.SetBinding(MultiState.StateProperty, new Binding(nameof(vm.State)));
        entryCount.SetBinding(Run.TextProperty, new Binding("Items.Count") { 
            Source = list, 
            StringFormat = "N0",
            Mode = BindingMode.OneWay
        });
        totalDue.SetBinding(TextBlock.TextProperty, new Binding(nameof(vm.TotalDue)) { StringFormat = Constants.NumberFormat });
        totalLastDue.SetBinding(TextBlock.TextProperty, new Binding(nameof(vm.TotalLastDue)) { StringFormat = Constants.NumberFormat });
        totalPaid.SetBinding(TextBlock.TextProperty, new Binding(nameof(vm.TotalPaid)) { StringFormat = Constants.NumberFormat });
        totalShortOrLong.SetBinding(TextBlock.TextProperty, new Binding(nameof(vm.TotalShort)) { StringFormat = Constants.NumberFormat });
    }

    void updatePosition() {
        var dpi = VisualTreeHelper.GetDpi(this);
        var topLeft = base.card.TransformToAncestor(this).Transform(new Point(0, 0));
        var position = PointToScreen(topLeft);

        position.X /= dpi.DpiScaleX;
        position.Y /= dpi.DpiScaleY;

        vm.Top = position.Y;
        vm.Left = position.X;
        vm.Width = base.card.ActualWidth;
        vm.Height = base.card.ActualHeight;
    }
}
