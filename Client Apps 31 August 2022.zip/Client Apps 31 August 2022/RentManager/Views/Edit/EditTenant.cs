﻿class EditTenant : CardView
{
    public override string Icon => Icons.Tenant;
    public override string Header => "Tenant";

    ComboText name, father, mother, husband, address, nid, contactNo;
    ComboBiState hasLeft;
    DayPicker leftOn;
    ComboButton buttons;
    ListBox tenantList;
    Grid editableGrid;
    EditText search;
    MultiState filter;
    CountBlock counter;
    EditTenantVM viewModel;

    public override void OnFirstSight() {
        base.OnFirstSight();
        viewModel = new EditTenantVM();
        DataContext = viewModel;
        initializeUI();
        bind();
    }
    void initializeUI() {
        search = new EditText() {
            Icon = Icons.SearchTenant,
            Hint = "Tenant",
            IsTrimBottomRequested = true
        };
        filter = new MultiState() {
            Icons = new string[] { Icons.Existing, Icons.LeftOrExpired, Icons.All },
            Tips = new string[] { "Existing", "Left", "All" },
            VerticalAlignment = VerticalAlignment.Center
        };
        counter = new CountBlock() {
            VerticalAlignment = VerticalAlignment.Center,
            Margin = new Thickness(5, 0, 0, 0)
        };
        Grid.SetColumn(filter, 1);
        Grid.SetColumn(counter, 2);
        var searchGrid = new Grid() {
            ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = GridLength.Auto },
                    new ColumnDefinition(){ Width = GridLength.Auto },
                },
            Children = { search, filter, counter }
        };
        tenantList = new ListBox() {
            BorderBrush = Brushes.LightGray,
            BorderThickness = new Thickness(0, 0, 1, 0),
            ItemTemplate = new TenantTemplate(nameof(viewModel.FilterName), viewModel, true)
        };
        Grid.SetRow(tenantList, 1);
        initializeEditables();

        var grid = new Grid() {
            RowDefinitions = {
                    new RowDefinition(){Height = GridLength.Auto},
                    new RowDefinition()
                },
            ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition()
                },
            Children = { searchGrid, tenantList, editableGrid }
        };
        setContent(grid);
    }

    void initializeEditables() {
        name = new ComboText() {
            Hint = "Name",
            Icon = Icons.Tenant,
            IsRequired = true,
            Editable = $"{nameof(viewModel.Edited)}.{nameof(Tenant.Name)}",
            NonEditable = $"{nameof(viewModel.Selected)}.{nameof(Tenant.Name)}",
            Error = nameof(viewModel.ErrorName)
        };
        father = new ComboText() {
            Hint = "Father",
            Icon = Icons.Father,
            IsRequired = true,
            Editable = $"{nameof(viewModel.Edited)}.{nameof(Tenant.Father)}",
            NonEditable = $"{nameof(viewModel.Selected)}.{nameof(Tenant.Father)}",
            Error = nameof(viewModel.ErrorFather)
        };
        mother = new ComboText() {
            Hint = "Mother",
            Icon = Icons.Mother,
            Editable = $"{nameof(viewModel.Edited)}.{nameof(Tenant.Mother)}",
            NonEditable = $"{nameof(viewModel.Selected)}.{nameof(Tenant.Mother)}"
        };
        husband = new ComboText() {
            Hint = "Husband",
            Icon = Icons.Husband,
            Editable = $"{nameof(viewModel.Edited)}.{nameof(Tenant.Husband)}",
            NonEditable = $"{nameof(viewModel.Selected)}.{nameof(Tenant.Husband)}"
        };
        address = new ComboText() {
            Hint = "Address",
            Icon = Icons.Address,
            IsRequired = true,
            IsMultiline = true,
            Editable = $"{nameof(viewModel.Edited)}.{nameof(Tenant.Address)}",
            NonEditable = $"{nameof(viewModel.Selected)}.{nameof(Tenant.Address)}",
            Error = nameof(viewModel.ErrorAddress)
        };
        nid = new ComboText() {
            Hint = "NID",
            Icon = Icons.ID,
            Editable = $"{nameof(viewModel.Edited)}.{nameof(Tenant.NID)}",
            NonEditable = $"{nameof(viewModel.Selected)}.{nameof(Tenant.NID)}"
        };
        contactNo = new ComboText() {
            Hint = "Phone",
            Icon = Icons.Phone,
            IsRequired = true,
            Editable = $"{nameof(viewModel.Edited)}.{nameof(Tenant.ContactNo)}",
            NonEditable = $"{nameof(viewModel.Selected)}.{nameof(Tenant.ContactNo)}",
            Error = nameof(viewModel.ErrorContactNo)
        };
        hasLeft = new ComboBiState() {
            Text = "Has Left?",
            Editable = $"{nameof(viewModel.Edited)}.{nameof(Tenant.HasLeft)}",
            NonEditable = $"{nameof(viewModel.Selected)}.{nameof(Tenant.HasLeft)}",
            VerticalAlignment = VerticalAlignment.Center
        };
        leftOn = new DayPicker() {
            Hint = "Left on",
            DateFormat = "dd/MM/yyyy",
            IsRequired = true,
            Visibility = Visibility.Hidden
        };
        Grid.SetColumn(leftOn, 1);
        var leftGrid = new Grid() {
            ColumnDefinitions = {
                    new ColumnDefinition(){ Width = new GridLength(1, GridUnitType.Star) },
                    new ColumnDefinition(){ Width = new GridLength(3, GridUnitType.Star) },
                },
            Children = { hasLeft, leftOn }
        };
        buttons = new ComboButton() {
            EditCommand = viewModel.SetIsOnEdit,
            CancelCommand = viewModel.ResetIsOnEdit,
            SaveCommand = viewModel.Save,
            IsValid = nameof(viewModel.IsValid)
        };
        Grid.SetRow(father, 1);
        Grid.SetRow(mother, 2);
        Grid.SetRow(husband, 3);
        Grid.SetRow(address, 4);
        Grid.SetRow(nid, 5);
        Grid.SetRow(contactNo, 6);
        Grid.SetRow(leftGrid, 7);
        Grid.SetRow(buttons, 8);
        editableGrid = new Grid() {
            Margin = new Thickness(10, 0, 0, 0),
            RowDefinitions = {
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(),
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto }
                },
            Children = { name, father, mother, husband, address, nid, contactNo, leftGrid, buttons }
        };
        Grid.SetColumn(editableGrid, 1);
        Grid.SetRow(editableGrid, 1);
    }

    void bind() {
        tenantList.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(viewModel.Editables)));
        tenantList.SetBinding(ListBox.SelectedItemProperty, new Binding(nameof(viewModel.Selected)));

        var binding = new Binding(nameof(viewModel.IsOnEdit));
        name.SetBinding(ComboText.IsOnEditProperty, binding);
        father.SetBinding(ComboText.IsOnEditProperty, binding);
        mother.SetBinding(ComboText.IsOnEditProperty, binding);
        husband.SetBinding(ComboText.IsOnEditProperty, binding);
        address.SetBinding(ComboText.IsOnEditProperty, binding);
        nid.SetBinding(ComboText.IsOnEditProperty, binding);
        contactNo.SetBinding(ComboText.IsOnEditProperty, binding);
        hasLeft.SetBinding(ComboBiState.IsOnEditProperty, binding);
        buttons.SetBinding(ComboButton.IsOnEditProperty, binding);

        leftOn.SetBinding(DayPicker.VisibilityProperty, new MultiBinding() {
            Bindings = {
                    binding,
                    new Binding($"{nameof(viewModel.Selected)}.{nameof(Tenant.HasLeft)}"),
                    new Binding($"{nameof(viewModel.Edited)}.{nameof(Tenant.HasLeft)}")
                },
            Converter = Converters.leaseExpiryDate
        });
        leftOn.SetBinding(DayPicker.SelectedDateProperty, new Binding(nameof(viewModel.LeftOn)));
        leftOn.SetBinding(DayPicker.ErrorProperty, new Binding(nameof(viewModel.ErrorLeftOn)));

        filter.SetBinding(MultiState.StateProperty, new Binding(nameof(viewModel.FilterState)));
        search.SetBinding(EditText.TextProperty, new Binding(nameof(viewModel.FilterName)) { Mode = BindingMode.OneWayToSource });
        counter.SetBinding(CountBlock.CountProperty, new Binding("Items.Count") { Source = tenantList });
    }
}
