﻿class AppData : AppDataBase
{
    public static ObservableCollection<Plot> plots;
    public static ObservableCollection<Space> spaces;
    public static ObservableCollection<Tenant> tenants;
    public static ObservableCollection<Lease> leases;
    public static ObservableCollection<ControlHead> controlHeads;
    public static ObservableCollection<Head> heads;
    public static int? controlIdOfReceivable, controlIdOfPayment;

    public event Action<Plot> PlotAdded, PlotEdited;
    public event Action<Space> SpaceAdded;
    public event Action<Tenant> TenantAdded, TenantEdited;
    public event Action<Head> HeadAdded;
    public event Action<string> LeaseExpired;
    public event Action RegularTransactionAdded, IrregularTransactionAdded;
    public event Action<NetTransaction> TransactionEdited, TransactionDeleted;

    override protected void initializeCollections() {
        plots = new ObservableCollection<Plot>();
        spaces = new ObservableCollection<Space>();
        tenants = new ObservableCollection<Tenant>();
        leases = new ObservableCollection<Lease>();
        controlHeads = new ObservableCollection<ControlHead>();
        heads = new ObservableCollection<Head>();
        BindingOperations.EnableCollectionSynchronization(plots, plots);
        BindingOperations.EnableCollectionSynchronization(spaces, spaces);
        BindingOperations.EnableCollectionSynchronization(tenants, tenants);
        BindingOperations.EnableCollectionSynchronization(leases, leases);
        BindingOperations.EnableCollectionSynchronization(controlHeads, controlHeads);
        BindingOperations.EnableCollectionSynchronization(heads, heads);
    }
    override protected void populateCollections() {
        var receivables = new List<Receivable>();
        ReadOnlySpan<byte> plotSpan, spaceSpan, tenantSpan, leaseSpan, receivableSpan, controlHeadSpan, headSpan;

        try {
            plotSpan = new ReadOnlySpan<byte>(getPacket());
            spaceSpan = new ReadOnlySpan<byte>(getPacket());
            tenantSpan = new ReadOnlySpan<byte>(getPacket());
            leaseSpan = new ReadOnlySpan<byte>(getPacket());
            receivableSpan = new ReadOnlySpan<byte>(getPacket());
            controlHeadSpan = new ReadOnlySpan<byte>(getPacket());
            headSpan = new ReadOnlySpan<byte>(getPacket());
        }
        catch {
            patch.Invoke(() => { window.Text = "service down"; });
            Thread.Sleep(2000);
            patch.Invoke(() => { window.Text = "quitting"; });
            Thread.Sleep(2000);
            patch.Invoke(() => {
                window.Close();
                App.Current.Shutdown();
            });
            return;
        }

        patch.Invoke(() => { window.Text = "listing plot"; });
        Thread.Sleep(250);
        #region Plot
        int read = 0;
        int start = 0;
        while (read < plotSpan.Length) {
            int id = BitConverter.ToInt32(plotSpan.Slice(start, 4));
            read += 4;
            start = read;
            while (plotSpan[read] != 0) read++;
            var name = Encoding.ASCII.GetString(plotSpan.Slice(start, read - start));

            start = ++read;
            while (plotSpan[read] != 0) read++;
            var description = Encoding.ASCII.GetString(plotSpan.Slice(start, read - start));
            patch.Invoke(() => {
                plots.Add(new Plot() {
                    Id = id,
                    Name = name,
                    Description = description
                });
            });

            start = ++read;
        }
        #endregion

        patch.Invoke(() => { window.Text = "listing space"; });
        Thread.Sleep(250);
        #region Space
        start = read = 0;
        while (read < spaceSpan.Length) {
            int id = BitConverter.ToInt32(spaceSpan.Slice(start, 4));
            int plotId = BitConverter.ToInt32(spaceSpan.Slice(start + 4, 4));
            read += 8;
            start = read;
            while (spaceSpan[read] != 0) read++;
            var name = Encoding.ASCII.GetString(spaceSpan.Slice(start, read - start));

            start = ++read;
            while (spaceSpan[read] != 0) read++;
            var description = Encoding.ASCII.GetString(spaceSpan.Slice(start, read - start));
            read++;
            var isVacant = BitConverter.ToBoolean(spaceSpan.Slice(read, 1));
            App.Current.Dispatcher.Invoke(() => {
                spaces.Add(new Space() {
                    Id = id,
                    PlotId = plotId,
                    Name = name,
                    Description = description,
                    IsVacant = isVacant
                });
            });
            start = ++read;
        }
        #endregion

        patch.Invoke(() => { window.Text = "listing tenant"; });
        Thread.Sleep(250);
        #region Tenant
        start = read = 0;
        while (read < tenantSpan.Length) {
            int id = BitConverter.ToInt32(tenantSpan.Slice(start, 4));
            read += 4;
            start = read;
            int index = 0;
            var segments = new string[7];
            while (read < tenantSpan.Length) {
                if (tenantSpan[read] != 0) {
                    read++;
                    continue;
                }
                segments[index++] = Encoding.ASCII.GetString(tenantSpan.Slice(start, read - start));
                start = ++read;
                if (index == segments.Length) break;
            }
            var hasLeft = BitConverter.ToBoolean(tenantSpan.Slice(read, 1));
            start = ++read;
            App.Current.Dispatcher.Invoke(() => {
                tenants.Add(new Tenant() {
                    Id = id,
                    Name = segments[0],
                    Father = segments[1],
                    Mother = segments[2],
                    Husband = segments[3],
                    Address = segments[4],
                    NID = segments[5],
                    ContactNo = segments[6],
                    HasLeft = hasLeft
                });
            });
        }
        #endregion

        patch.Invoke(() => { window.Text = "listing lease"; });
        Thread.Sleep(250);
        #region Lease
        start = read = 0;
        while (read < leaseSpan.Length) {
            int id = BitConverter.ToInt32(leaseSpan.Slice(start, 4));
            int plotId = BitConverter.ToInt32(leaseSpan.Slice(start + 4, 4));
            int spaceId = BitConverter.ToInt32(leaseSpan.Slice(start + 8, 4));
            int tenantId = BitConverter.ToInt32(leaseSpan.Slice(start + 12, 4));

            read += 16;
            start = read;
            while (leaseSpan[read] != 0) read++;
            var startDate = Encoding.ASCII.GetString(leaseSpan.Slice(start, read - start));
            var dateStart = DateTime.ParseExact(startDate, "yyyy-MM-dd", CultureInfo.InvariantCulture.DateTimeFormat);

            start = ++read;
            while (leaseSpan[read] != 0) read++;
            var endDate = Encoding.ASCII.GetString(leaseSpan.Slice(start, read - start));
            DateTime? dateEnd = string.IsNullOrWhiteSpace(endDate) ? null :
               DateTime.ParseExact(endDate, "yyyy-MM-dd", CultureInfo.InvariantCulture.DateTimeFormat);

            start = ++read;
            while (leaseSpan[read] != 0) read++;
            var business = Encoding.ASCII.GetString(leaseSpan.Slice(start, read - start));

            read++;
            var isExpired = BitConverter.ToBoolean(leaseSpan.Slice(read, 1));
            App.Current.Dispatcher.Invoke(() => {
                leases.Add(new Lease() {
                    Id = id,
                    PlotId = plotId,
                    SpaceId = spaceId,
                    TenantId = tenantId,
                    DateStart = dateStart,
                    DateEnd = dateEnd,
                    Business = business,
                    IsExpired = isExpired
                });
            });
            start = ++read;
        }
        #endregion

        patch.Invoke(() => { window.Text = "listing receivable"; });
        Thread.Sleep(250);
        #region Receivables
        start = read = 0;
        while (read < receivableSpan.Length) {
            var leaseId = BitConverter.ToInt32(receivableSpan.Slice(read, 4));
            var headId = BitConverter.ToInt32(receivableSpan.Slice(read + 4, 4));
            var amount = BitConverter.ToInt32(receivableSpan.Slice(read + 8, 4));

            receivables.Add(new Receivable() {
                LeaseId = leaseId,
                HeadId = headId,
                Amount = amount
            });
            read += 12;
        }
        #endregion

        patch.Invoke(() => { window.Text = "listing control control head"; });
        Thread.Sleep(250);
        #region ControlHead
        start = read = 0;
        while (read < controlHeadSpan.Length) {
            int id = BitConverter.ToInt32(controlHeadSpan.Slice(start, 4));
            read += 4;
            start = read;
            while (controlHeadSpan[read] != 0) read++;
            var name = Encoding.ASCII.GetString(controlHeadSpan.Slice(start, read - start));
            App.Current.Dispatcher.Invoke(() => {
                controlHeads.Add(new ControlHead() {
                    Id = id,
                    Name = name
                });
            });
            start = ++read;
        }
        #endregion

        patch.Invoke(() => { window.Text = "listing head"; });
        Thread.Sleep(250);
        #region Head
        start = read = 0;
        while (read < headSpan.Length) {
            int id = BitConverter.ToInt32(headSpan.Slice(start, 4));
            int controlId = BitConverter.ToInt32(headSpan.Slice(start + 4, 4));
            read += 8;
            start = read;
            while (headSpan[read] != 0) read++;
            var name = Encoding.ASCII.GetString(headSpan.Slice(start, read - start));

            start = ++read;
            while (headSpan[read] != 0) read++;
            var description = Encoding.ASCII.GetString(headSpan.Slice(start, read - start));
            App.Current.Dispatcher.Invoke(() => {
                heads.Add(new Head() {
                    Id = id,
                    ControlId = controlId,
                    Name = name,
                    Description = description
                });
            });
            start = ++read;
        }
        #endregion

        if (receivables.Count > 0) {
            foreach (var item in leases)
                item.FixedReceivables = new ObservableCollection<Receivable>(receivables.Where(x => x.LeaseId == item.Id));
        }
        for (int i = 0; i < leases.Count; i++) {
            leases[i].PlotName = plots.First(x => x.Id == leases[i].PlotId).Name;
            leases[i].SpaceName = spaces.First(x => x.Id == leases[i].SpaceId).Name;
            leases[i].TenantName = tenants.First(x => x.Id == leases[i].TenantId).Name;
        }
        for (int i = 0; i < spaces.Count; i++)
            spaces[i].PlotName = plots.First(x => x.Id == spaces[i].PlotId).Name;

        foreach (var control in controlHeads) {
            if (string.Equals(control.Name, "Receivable"))
                controlIdOfReceivable = control.Id;
            else if (string.Equals(control.Name, "Payment"))
                controlIdOfPayment = control.Id;
        }
    }
    override protected void processMessage() {
        while (isConnected) {
            var packet = new ReadOnlySpan<byte>(messages.Take());
            var message = (Function)BitConverter.ToInt32(packet.Slice(0, 4));
            var slice = packet.Slice(4);
            switch (message) {
                case Function.AddPlot: plotAdd(slice); break;
                case Function.EditPlot: plotEdit(slice); break;
                case Function.AddSpace: spaceAdd(slice); break;
                case Function.EditSpace: spaceEdit(slice); break;
                case Function.AddTenant: tenantAdd(slice); break;
                case Function.EditTenant: tenantEdit(slice); break;
                case Function.AddHead: headAdd(slice); break;
                case Function.EditHead: headEdit(slice); break;
                case Function.AddLease: leaseAdd(slice); break;
                case Function.EditLease: leaseEdit(slice); break;
                case Function.AddTransactionsRegular: regularAdd(slice); break;
                case Function.AddTransactionsIrregular: irregularAdd(slice); break;
                case Function.EditTransaction: transactionEdit(slice); break;
                case Function.DeleteTransaction: transactionDelete(slice); break;
            }
        }
    }

    void plotAdd(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var nPlot = NetPlot.FromBytes(array.Slice(4));
        patch.Invoke(() => {
            var plot = new Plot() {
                Id = nPlot.Id,
                Name = nPlot.Name,
                Description = nPlot.Description
            };
            plots.Add(plot);
            if (userId != App.service.UserId) return;
            PlotAdded?.Invoke(plot);
        });
    }
    void plotEdit(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var nPlot = NetPlot.FromBytes(array.Slice(4));
        var plot = plots.First(x => x.Id == nPlot.Id);
        patch.Invoke(() => {
            plot.Description = nPlot.Description;
            if (!nPlot.Name.Equals(plot.Name)) {
                plot.Name = nPlot.Name;
                foreach (var lease in leases) {
                    if (lease.PlotId == plot.Id)
                        lease.PlotName = plot.Name;
                }
                foreach (var space in spaces) {
                    if (space.PlotId == plot.Id)
                        space.PlotName = plot.Name;
                }
                PlotEdited?.Invoke(plot);
            }
        });
    }
    void spaceAdd(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var nSpace = NetSpace.FromBytes(array.Slice(4));
        patch.Invoke(() => {
            var space = new Space() {
                Id = nSpace.Id,
                PlotId = nSpace.PlotId,
                Name = nSpace.Name,
                Description = nSpace.Description,
                IsVacant = nSpace.IsVacant,
                PlotName = plots.First(x => x.Id == nSpace.PlotId).Name
            };
            spaces.Add(space);
            if (userId == App.service.UserId) SpaceAdded?.Invoke(space);
        });
    }
    void spaceEdit(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var leaseId = BitConverter.ToInt32(array.Slice(4, 4));
        int read = 8;
        string message = "";
        if (leaseId > 0) {
            int start = read;
            while (read < array.Length) {
                if (array[read] != 0) {
                    read++;
                    continue;
                }
                break;
            }
            var vaccatedOn = Encoding.ASCII.GetString(array.Slice(start, read - start));
            var lease = leases.First(x => x.Id == leaseId);
            lease.IsExpired = true;
            lease.DateEnd = DateTime.ParseExact(vaccatedOn, "yyyy-MM-dd", CultureInfo.CurrentCulture.DateTimeFormat);

            var tenantName = tenants.First(x => x.Id == lease.TenantId).Name;
            var spaceName = spaces.First(x => x.Id == lease.SpaceId).Name;
            message = $"{spaceName} was let out to {tenantName}\r\nNow is vacant and available to let out";
        }
        read++;
        var nSpace = NetSpace.FromBytes(array.Slice(read));
        var space = spaces.First(x => x.Id == nSpace.Id);
        patch.Invoke(() => {
            space.PlotId = nSpace.PlotId;
            space.Description = nSpace.Description;
            space.IsVacant = nSpace.IsVacant;
            space.PlotName = plots.First(x => x.Id == nSpace.PlotId).Name;
            if (!nSpace.Name.Equals(space.Name)) {
                space.Name = nSpace.Name;
                foreach (var lease in leases) {
                    if (lease.SpaceId == space.Id)
                        lease.SpaceName = space.Name;
                }
            }
        });
        if (userId == App.service.UserId) {
            if (!string.IsNullOrEmpty(message)) {
                patch.Invoke(() => { InfoDialog.Activate("Space", message); });
            }
        }
    }
    void tenantAdd(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var nTenant = NetTenant.FromBytes(array.Slice(4));
        patch.Invoke(() => {
            var tenant = new Tenant() {
                Id = nTenant.Id,
                Name = nTenant.Name,
                Father = nTenant.Father,
                Mother = nTenant.Mother,
                Husband = nTenant.Husband,
                Address = nTenant.Address,
                NID = nTenant.NID,
                ContactNo = nTenant.ContactNo,
                HasLeft = nTenant.HasLeft
            };
            tenants.Add(tenant);
            if (userId == App.service.UserId) {
                TenantAdded?.Invoke(tenant);
            }
        });
    }
    void tenantEdit(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        int read = 4;
        int start = read;
        while (read < array.Length) {
            if (array[read] != 0) {
                read++;
                continue;
            }
            break;
        }
        var leftOn = Encoding.ASCII.GetString(array.Slice(start, read - start));
        read++;
        var nTenant = NetTenant.FromBytes(array.Slice(read));
        var tenant = tenants.First(x => x.Id == nTenant.Id);
        string message = "";

        if (!string.IsNullOrWhiteSpace(leftOn)) {
            var date = DateTime.ParseExact(leftOn, "yyyy-MM-dd", CultureInfo.CurrentCulture.DateTimeFormat);
            var leaseList = leases.Where(x => !x.IsExpired && x.TenantId == nTenant.Id).ToList();
            if (leaseList.Count > 0) {
                message = "Space(s) occupied:";
                foreach (var lease in leaseList) {
                    var space = spaces.FirstOrDefault(x => x.Id == lease.SpaceId);
                    space.IsVacant = true;
                    lease.IsExpired = true;
                    lease.DateEnd = date;
                    message += $"\r\n\t{space.Name} of {plots.First(x => x.Id == space.PlotId).Name}";
                }
                message += $"\r\n\r\nby {nTenant.Name} now available to let out";
            }
        }

        patch.Invoke(() => {
            tenant.Father = nTenant.Father;
            tenant.Mother = nTenant.Mother;
            tenant.Husband = nTenant.Husband;
            tenant.Address = nTenant.Address;
            tenant.ContactNo = nTenant.ContactNo;
            tenant.NID = nTenant.NID;
            tenant.HasLeft = nTenant.HasLeft;

            if (!tenant.Name.Equals(nTenant.Name)) {
                tenant.Name = nTenant.Name;
                foreach (var lease in leases) {
                    if (lease.TenantId == tenant.Id)
                        lease.TenantName = tenant.Name;
                }
                TenantEdited?.Invoke(tenant);
            }
        });

        if (userId == App.service.UserId) {
            if (!string.IsNullOrEmpty(message)) {
                patch.Invoke(() => { InfoDialog.Activate("Tenant", message); });
            }
        }
    }
    void headAdd(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var nHead = NetHead.FromBytes(array.Slice(4));
        patch.Invoke(() => {
            var head = new Head() {
                Id = nHead.Id,
                ControlId = nHead.ControlId,
                Name = nHead.Name,
                Description = nHead.Description
            };
            heads.Add(head);
            if (userId == App.service.UserId) {
                HeadAdded?.Invoke(head);
            }
        });
    }
    void headEdit(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var nHead = NetHead.FromBytes(array.Slice(4));
        var head = heads.First(x => x.Id == nHead.Id);
        patch.Invoke(() => {
            head.ControlId = nHead.ControlId;
            head.Name = nHead.Name;
            head.Description = nHead.Description;
        });
    }
    void leaseAdd(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        // you could convert it in to Lease instead of NetLease in App.Current.Dispatcher
        var newLease = new NetLease() {
            Id = BitConverter.ToInt32(array.Slice(4, 4)),
            PlotId = BitConverter.ToInt32(array.Slice(8, 4)),
            SpaceId = BitConverter.ToInt32(array.Slice(12, 4)),
            TenantId = BitConverter.ToInt32(array.Slice(16, 4)),
        };
        int index = 0;
        int read = 20;
        int start = 20;
        var segments = new string[3];
        while (read < array.Length) {
            if (array[read] != 0) {
                read++;
                continue;
            }
            segments[index++] = Encoding.ASCII.GetString(array.Slice(start, read - start));
            start = ++read;
            if (index == segments.Length) break;
        }
        newLease.DateStart = segments[0];
        newLease.DateEnd = null;
        newLease.Business = segments[2];

        newLease.IsExpired = BitConverter.ToBoolean(array.Slice(read, 1));
        read++;

        var balance = array.Length - read;
        var numReceivable = balance / 12;
        var newReceivables = new List<NetReceivable>();

        for (int i = 0; i < numReceivable; i++) {
            newReceivables.Add(NetReceivable.FromBytes(array.Slice(read, 12)));
            read += 12;
        }
        var plot = plots.First(x => x.Id == newLease.PlotId).Name;
        var space = spaces.First(x => x.Id == newLease.SpaceId).Name;
        var tenant = tenants.First(x => x.Id == newLease.TenantId).Name;
        spaces.First(x => x.Id == newLease.SpaceId).IsVacant = false;

        patch.Invoke(() => {
            var receivables = new ObservableCollection<Receivable>();
            foreach (var item in newReceivables) {
                receivables.Add(new Receivable() {
                    LeaseId = item.LeaseId,
                    HeadId = item.HeadId,
                    Amount = item.Amount
                });
            };
            var lease = new Lease() {
                Id = newLease.Id,
                PlotId = newLease.PlotId,
                SpaceId = newLease.SpaceId,
                TenantId = newLease.TenantId,
                DateStart = DateTime.ParseExact(newLease.DateStart, "yyyy-MM-dd", CultureInfo.CurrentCulture.DateTimeFormat),
                DateEnd = null,
                Business = newLease.Business,
                IsExpired = newLease.IsExpired,
                FixedReceivables = receivables,
                PlotName = plot,
                SpaceName = space,
                TenantName = tenant
            };
            leases.Add(lease);
        });
    }
    void leaseEdit(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        // conversion is same as handleLeaseAdd
        var newLease = new NetLease() {
            Id = BitConverter.ToInt32(array.Slice(4, 4)),
            PlotId = BitConverter.ToInt32(array.Slice(8, 4)),
            SpaceId = BitConverter.ToInt32(array.Slice(12, 4)),
            TenantId = BitConverter.ToInt32(array.Slice(16, 4)),
        };
        int index = 0;
        int read = 20;
        int start = 20;
        var segments = new string[3];
        while (read < array.Length) {
            if (array[read] != 0) {
                read++;
                continue;
            }
            segments[index++] = Encoding.ASCII.GetString(array.Slice(start, read - start));
            start = ++read;
            if (index == segments.Length) break;
        }
        newLease.DateStart = segments[0];
        newLease.DateEnd = null;
        newLease.Business = segments[2];

        newLease.IsExpired = BitConverter.ToBoolean(array.Slice(read, 1));
        read++;

        var balance = array.Length - read;
        var numReceivable = balance / 12;
        var newReceivables = new List<NetReceivable>();

        for (int i = 0; i < numReceivable; i++) {
            newReceivables.Add(NetReceivable.FromBytes(array.Slice(read, 12)));
            read += 12;
        }

        var original = leases.First(x => x.Id == newLease.Id);
        if (newLease.IsExpired && !original.IsExpired) {
            var vacated = spaces.First(x => x.Id == original.SpaceId);
            vacated.IsVacant = true;
            if (App.service.UserId == userId) {
                patch.Invoke(() => LeaseExpired?.Invoke(vacated.Name));
            }
        }
        if (newLease.SpaceId != original.SpaceId) {
            spaces.FirstOrDefault(x => x.Id == original.SpaceId).IsVacant = true;
            spaces.FirstOrDefault(x => x.Id == newLease.SpaceId).IsVacant = false;
        }

        var plot = plots.First(x => x.Id == newLease.PlotId).Name;
        var space = spaces.First(x => x.Id == newLease.SpaceId).Name;
        var tenant = tenants.First(x => x.Id == newLease.TenantId).Name;
        patch.Invoke(() => {
            var receivables = new ObservableCollection<Receivable>();
            foreach (var item in newReceivables) {
                receivables.Add(new Receivable() {
                    LeaseId = item.LeaseId,
                    HeadId = item.HeadId,
                    Amount = item.Amount
                });
            };

            original.Id = newLease.Id;
            original.PlotId = newLease.PlotId;
            original.SpaceId = newLease.SpaceId;
            original.TenantId = newLease.TenantId;
            original.DateStart = DateTime.ParseExact(newLease.DateStart, "yyyy-MM-dd", CultureInfo.CurrentCulture.DateTimeFormat);
            original.DateEnd = string.IsNullOrEmpty(newLease.DateEnd) ? null : DateTime.ParseExact(newLease.DateEnd, "yyyy-MM-dd", CultureInfo.CurrentCulture.DateTimeFormat);
            original.Business = newLease.Business;
            original.IsExpired = newLease.IsExpired;
            original.FixedReceivables = receivables;
            original.PlotName = plot;
            original.SpaceName = space;
            original.TenantName = tenant;
            original.FixedReceivables = receivables;
        });
    }

    void regularAdd(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        if (userId == App.service.UserId) {
            patch.Invoke(() => RegularTransactionAdded?.Invoke());
        }
    }
    void irregularAdd(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        if (userId == App.service.UserId) {
            patch.Invoke(() => IrregularTransactionAdded?.Invoke());
        }
    }
    void transactionEdit(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var nTransaction = NetTransaction.FromBytes(array.Slice(4));
        TransactionEdited?.Invoke(nTransaction);
    }
    void transactionDelete(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var nTransaction = NetTransaction.FromBytes(array.Slice(4));
        patch.Invoke(() => TransactionDeleted?.Invoke(nTransaction));
    }
}
