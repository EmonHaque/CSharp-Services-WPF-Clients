﻿class CurrentMonthSummaryTemplate : DataTemplate
{
    public CurrentMonthSummaryTemplate() {
        var grid = new FrameworkElementFactory(typeof(Grid));
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col3 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col4 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col5 = new FrameworkElementFactory(typeof(ColumnDefinition));

        var row1 = new FrameworkElementFactory(typeof(RowDefinition));
        var row2 = new FrameworkElementFactory(typeof(RowDefinition));
        var separator = new FrameworkElementFactory(typeof(Separator)) { Name = "separator" };
        var totalDue = new FrameworkElementFactory(typeof(TextBlock));
        var totalLastDue = new FrameworkElementFactory(typeof(TextBlock));
        var totalPaid = new FrameworkElementFactory(typeof(TextBlock));
        var totalShortOrLong = new FrameworkElementFactory(typeof(TextBlock));

        Resources.Add(typeof(TextBlock), new Style() {
            Setters = {
                new Setter(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right),
                new Setter(Grid.RowProperty, 1)
            }
        });
        col2.SetValue(ColumnDefinition.WidthProperty, new GridLength(70));
        col3.SetValue(ColumnDefinition.WidthProperty, new GridLength(70));
        col4.SetValue(ColumnDefinition.WidthProperty, new GridLength(70));
        col5.SetValue(ColumnDefinition.WidthProperty, new GridLength(70));
        row1.SetValue(RowDefinition.HeightProperty, GridLength.Auto);

        separator.SetValue(Grid.ColumnProperty, 1);
        separator.SetValue(Grid.ColumnSpanProperty, 4);
        totalDue.SetValue(Grid.ColumnProperty, 1);
        totalLastDue.SetValue(Grid.ColumnProperty, 2);
        totalPaid.SetValue(Grid.ColumnProperty, 3);
        totalShortOrLong.SetValue(Grid.ColumnProperty, 4);
        separator.SetValue(Separator.BackgroundProperty, Brushes.LightGray);
        separator.SetValue(Separator.HeightProperty, Constants.SeparatorHeight);

        totalDue.SetBinding(TextBlock.TextProperty, new Binding("Item1") { StringFormat = Constants.NumberFormat });
        totalLastDue.SetBinding(TextBlock.TextProperty, new Binding("Item2") { StringFormat = Constants.NumberFormat });
        totalPaid.SetBinding(TextBlock.TextProperty, new Binding("Item3") { StringFormat = Constants.NumberFormat });
        totalShortOrLong.SetBinding(TextBlock.TextProperty, new Binding("Item4") { StringFormat = Constants.NumberFormat });

        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(col3);
        grid.AppendChild(col4);
        grid.AppendChild(col5);
        grid.AppendChild(row1);
        grid.AppendChild(row2);
        grid.AppendChild(separator);
        grid.AppendChild(totalDue);
        grid.AppendChild(totalLastDue);
        grid.AppendChild(totalPaid);
        grid.AppendChild(totalShortOrLong);
        VisualTree = grid;
    }
}