﻿class AppInfoTemplate : DataTemplate
{
	public AppInfoTemplate() {
		var grid = new FrameworkElementFactory(typeof(Grid));
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col3 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var select = new FrameworkElementFactory(typeof(CheckBox));
        var name = new FrameworkElementFactory(typeof(TextBlock));
        var version = new FrameworkElementFactory(typeof(TextBlock));

        col1.SetValue(ColumnDefinition.WidthProperty, GridLength.Auto);
        col3.SetValue(ColumnDefinition.WidthProperty, GridLength.Auto);
        select.SetValue(CheckBox.MarginProperty, new Thickness(5, 0, 5, 0));
        version.SetValue(TextBlock.MarginProperty, new Thickness(5, 0, 5, 0));
        select.SetValue(CheckBox.VerticalAlignmentProperty, VerticalAlignment.Center);
        version.SetValue(CheckBox.VerticalAlignmentProperty, VerticalAlignment.Center);
        name.SetValue(TextBlock.TextWrappingProperty, TextWrapping.Wrap);
        name.SetValue(Grid.ColumnProperty, 1);
        version.SetValue(Grid.ColumnProperty, 2);

        name.SetBinding(TextBlock.TextProperty, new Binding(nameof(AppInfoExtended.Name)));
        version.SetBinding(TextBlock.TextProperty, new Binding(nameof(AppInfoExtended.Version)));
        select.SetBinding(CheckBox.IsCheckedProperty, new Binding(nameof(AppInfoExtended.IsSelected)) { Mode = BindingMode.OneWayToSource});

        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(col3);
        grid.AppendChild(select);
        grid.AppendChild(name);
        grid.AppendChild(version);

        VisualTree = grid;
    }
}
