﻿using System.ComponentModel.DataAnnotations;
using System.Windows.Media.Media3D;

class PurchaseSellValidator
{
    EntryPurchaseSell entry;
    public List<ValidationError> Errors { get; set; }
    
    public PurchaseSellValidator() { }
    public PurchaseSellValidator(EntryPurchaseSell entry) {
        this.entry = entry;
    }
    public bool IsValid() {
        Errors = new List<ValidationError>();
        if (entry.Date is null) {
            Errors.Add(new ValidationError() {
                Head = nameof(entry.Date),
                Error = Constants.CannotBeEmpty
            });
        }
        if (string.IsNullOrWhiteSpace(entry.Site)) {
            Errors.Add(new ValidationError() {
                Head = nameof(entry.Site),
                Error = Constants.CannotBeEmpty
            });
        }
        if (string.IsNullOrWhiteSpace(entry.Party)) {
            Errors.Add(new ValidationError() {
                Head = nameof(entry.Party),
                Error = Constants.CannotBeEmpty
            });
        }
        if (string.IsNullOrWhiteSpace(entry.Head)) {
            Errors.Add(new ValidationError() {
                Head = nameof(entry.Head),
                Error = Constants.CannotBeEmpty
            });
        }
        if (string.IsNullOrWhiteSpace(entry.Amount)) {
            Errors.Add(new ValidationError() {
                Head = nameof(entry.Amount),
                Error = Constants.CannotBeEmpty
            });
        }
        else {
            int x;
            if (!int.TryParse(entry.Amount, NumberStyles.Number, CultureInfo.CurrentCulture.NumberFormat, out x)) {
                Errors.Add(new ValidationError() {
                    Head = nameof(entry.Amount),
                    Error = Constants.IsntValid
                });
            }
            else if (x <= 0) {
                Errors.Add(new ValidationError() {
                    Head = nameof(entry.Amount),
                    Error = Constants.MustBePositive
                });
            }
        }
        if (!string.IsNullOrWhiteSpace(entry.Quantity)) {
            double x;
            if (!double.TryParse(entry.Quantity, out x)) {
                Errors.Add(new ValidationError() {
                    Head = nameof(entry.Quantity),
                    Error = Constants.IsntValid
                });
            }
            else if (x <= 0) {
                Errors.Add(new ValidationError() {
                    Head = nameof(entry.Quantity),
                    Error = Constants.MustBePositive
                });
            }

            if (string.IsNullOrWhiteSpace(entry.Unit)) {
                Errors.Add(new ValidationError() {
                    Head = nameof(entry.Unit),
                    Error = Constants.CannotBeEmpty
                });
            }
        }
        return Errors.Count == 0;
    }
    public bool DoesExist() {
        Errors = new List<ValidationError>();
        if (!AppData.HasSite(entry.Site)) {
            Errors.Add(new ValidationError() {
                Head = nameof(entry.Site),
                Error = Constants.DoesntExist
            });
        }
        else entry.SiteId = AppData.GetSite().Id;

        if (!AppData.HasParty(entry.Party)) {
            Errors.Add(new ValidationError() {
                Head = nameof(entry.Party),
                Error = Constants.DoesntExist
            });
        }
        else entry.PartyId = AppData.GetParty().Id;

        if (!AppData.HasHead(entry.Head)) {
            Errors.Add(new ValidationError() {
                Head = nameof(entry.Head),
                Error = Constants.DoesntExist
            });
        }
        else entry.HeadId = AppData.GetHead().Id;

        if (!string.IsNullOrWhiteSpace(entry.SubHead)) {
            if (!AppData.HasSubHead(entry.SubHead)) {
                Errors.Add(new ValidationError() {
                    Head = nameof(entry.SubHead),
                    Error = Constants.DoesntExist
                });
            }
        }
        else entry.SubHeadId = AppData.GetSubHead().Id;

        if (!string.IsNullOrWhiteSpace(entry.Quantity)) {
            if (!AppData.HasUnit(entry.Unit)) {
                Errors.Add(new ValidationError() {
                    Head = nameof(entry.Unit),
                    Error = Constants.DoesntExist
                });
            }
            else entry.UnitId = AppData.GetUnit().Id;
        }
        return Errors.Count == 0;
    }
    public bool IsEqual(EntryPurchaseSell e) {
        if (e.IsSell != entry.IsSell) {
            if (e.IsSell == 0) entry.Title = "Sell";
            else entry.Title = "Purchase";
            return false;
        }
        if (e.Date != entry.Date) return false;
        if (e.IsConstruction != entry.IsConstruction) return false;
        if (!e.Site.Equals(entry.Site, StringComparison.InvariantCultureIgnoreCase)) return false;
        if (!e.Party.Equals(entry.Party, StringComparison.InvariantCultureIgnoreCase)) return false;
        if (!e.Head.Equals(entry.Head, StringComparison.InvariantCultureIgnoreCase)) return false;
        if (!e.SubHead.Equals(entry.SubHead, StringComparison.InvariantCultureIgnoreCase)) return false;
        if (!e.Unit.Equals(entry.Unit, StringComparison.InvariantCultureIgnoreCase)) return false;
        if (!e.Narration.Equals(entry.Narration, StringComparison.InvariantCultureIgnoreCase)) return false;

        int originalAmount, editedAmount;
        int.TryParse(e.Amount, NumberStyles.Number, CultureInfo.CurrentCulture.NumberFormat, out originalAmount);
        int.TryParse(entry.Amount, NumberStyles.Number, CultureInfo.CurrentCulture.NumberFormat, out editedAmount);
        if (originalAmount != editedAmount) return false;

        double originalQuantity, editedQuantity;
        double.TryParse(e.Quantity, out originalQuantity);
        double.TryParse(entry.Quantity, out editedQuantity);
        if (originalQuantity != editedQuantity) return false;

        return true;
    }
    public async Task<bool> Resolve(double left, double top, double width, double height) {
        bool isSuccess = true;
        var request = new CDRMRequest() { UserId = App.service.UserId };
        Response response = null;

        foreach (var e in Errors) {
            switch (e.Head) {
                case nameof(entry.Site): {
                        var name = entry.Site.Trim();
                        var dialog = new CreateSiteDialog(left, top, width, height, entry.Site);
                        dialog.ShowDialog();
                        var site = new NetSite() {
                            Name = name,
                            Address = dialog.GetAddress().Trim()
                        };
                        request.Method = (int)Function.AddSite;
                        request.Args = new object[] { site };
                        response = await App.service.GetResponse(request);
                        if (response.IsSuccess) {
                            entry.SiteId = BitConverter.ToInt32(response.Packet.Skip(1).ToArray());
                            entry.Site = name;
                        }
                        else {
                            isSuccess = false;
                            break;
                        }
                    }
                    break;
                case nameof(entry.Party): {
                        var name = entry.Party.Trim();
                        var dialog = new CreatePartyDialog(left, top, width, height, entry.Party);
                        dialog.ShowDialog();
                        var (address, phone) = dialog.GetAddressAndPhone();
                        var party = new NetParty() {
                            Name = name,
                            Address = address.Trim(),
                            Phone = phone?.Trim()
                        };
                        request.Method = (int)Function.AddParty;
                        request.Args = new object[] { party };
                        response = await App.service.GetResponse(request);
                        if (response.IsSuccess) {
                            entry.PartyId = BitConverter.ToInt32(response.Packet.Skip(1).ToArray());
                            entry.Party = party.Name;
                        }
                        else {
                            isSuccess = false;
                            break;
                        }
                    }
                    break;
                case nameof(entry.Head): {
                        var name = entry.Head.Trim();
                        request.Method = (int)Function.AddHead;
                        request.Args = new object[] { new NetHead() { Name = name } };
                        response = await App.service.GetResponse(request);
                        if (response.IsSuccess) {
                            entry.HeadId = BitConverter.ToInt32(response.Packet.Skip(1).ToArray());
                            entry.Head = name;
                        }
                        else {
                            isSuccess = false;
                            break;
                        }
                    }
                    break;
                case nameof(entry.SubHead): {
                        var name = entry.SubHead.Trim();
                        request.Method = (int)Function.AddSubHead;
                        request.Args = new object[] { new NetSubHead() { Name = name } };
                        response = await App.service.GetResponse(request);
                        if (response.IsSuccess) {
                            entry.SubHeadId = BitConverter.ToInt32(response.Packet.Skip(1).ToArray());
                            entry.SubHead = name;
                        }
                        else {
                            isSuccess = false;
                            break;
                        }
                    }
                    break;
                case nameof(entry.Unit): {
                        var name = entry.Unit.Trim();
                        request.Method = (int)Function.AddUnit;
                        request.Args = new object[] { new NetUnit() { Name = name } };
                        response = await App.service.GetResponse(request);
                        if (response.IsSuccess) {
                            entry.UnitId = BitConverter.ToInt32(response.Packet.Skip(1).ToArray());
                            entry.Unit = name;
                        }
                        else {
                            isSuccess = false;
                            break;
                        }
                    }
                    break;
            }
        }

        return isSuccess;
    }
}
