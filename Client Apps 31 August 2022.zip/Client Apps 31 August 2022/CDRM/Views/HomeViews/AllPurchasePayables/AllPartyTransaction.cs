﻿class AllPartyTransaction : AllPurchaseBase
{
    public override string Icon => Icons.Tenant;
    protected override string searchHint => "Party";

    AllPartyTransactionVM viewModel;
    protected override AllPurchaseBaseVM vm {
        get {
            if(viewModel is null) {
                viewModel = new AllPartyTransactionVM();
            }
            return viewModel;
        }
    }
    
    ActionButton sortPayment, sortDue;

    public override void OnFirstSight() {
        base.OnFirstSight();
        secondRow.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
        secondRow.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
        sortPayment = new ActionButton() {
            ToolTip = "Payment",
            Margin = new Thickness(5, 0, 5, 0),
            Icon = Icons.SortSwap,
            Command = viewModel.SortPayment,
            VerticalAlignment = VerticalAlignment.Center
        };
        sortDue = new ActionButton() {
            ToolTip = "Due",
            Margin = new Thickness(5, 0, 5, 0),
            Icon = Icons.SortSwap,
            Command = viewModel.SortDue,
            VerticalAlignment = VerticalAlignment.Center
        };
        Grid.SetColumn(sortPayment, 2);
        Grid.SetColumn(sortDue, 3);
        secondRow.Children.Add(sortPayment);
        secondRow.Children.Add(sortDue);
    }
}
