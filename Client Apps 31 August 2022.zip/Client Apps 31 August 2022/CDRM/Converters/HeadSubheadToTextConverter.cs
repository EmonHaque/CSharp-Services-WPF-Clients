﻿class HeadSubheadToTextConverter : IMultiValueConverter
{
    public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture) {
        if (values[1].Equals(0)) return AppData.heads.First(x => x.Id == (int)values[0]).Name;
        return AppData.heads.First(x => x.Id == (int)values[0]).Name
            + " - " +
            AppData.subHeads.First(x => x.Id == (int)values[1]).Name;
    }

    public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture) {
        throw new NotImplementedException();
    }
}
