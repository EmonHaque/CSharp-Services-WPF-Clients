﻿public class LoginWindow : Window
{
    string app;
    double radius = 5;
    Border windowBorder;
    Grid container;
    EditText userName;
    EditPassword password;
    TextBlock loginTo, appName, info, loggedIn;
    CommandButton login, connect;
    Socket loginSocket;
    ServicePack pack;
    DependencyPropertyDescriptor nameDescriptor, passwordDescriptor;

    public event Action<LoginWindow, Socket> LoggedIn;
    public event Action<LoginWindow> InService;

    public LoginWindow(string app, ServicePack pack) {
        this.app = app;
        this.pack = pack;
        Height = 640;
        Width = 320;
        WindowStartupLocation = WindowStartupLocation.CenterScreen;
        WindowStyle = WindowStyle.None;
        AllowsTransparency = true;
        initializeUI();
        windowBorder = new Border() {
            Background = Constants.Background,
            Padding = new Thickness(10),
            CornerRadius = new CornerRadius(radius),
            BorderThickness = new Thickness(0.75),
            BorderBrush = Brushes.LightGray,
            Child = container
        };
        AddVisualChild(windowBorder);

        Loaded += onLoaded;
        Unloaded += onUnloaded;
    }

    void onLoaded(object sender, RoutedEventArgs e) {
        nameDescriptor = DependencyPropertyDescriptor.FromProperty(EditText.TextProperty, typeof(EditText));
        passwordDescriptor = DependencyPropertyDescriptor.FromProperty(EditPassword.TextProperty, typeof(EditPassword));
        nameDescriptor.AddValueChanged(userName, onNameOrPassChanged);
        passwordDescriptor.AddValueChanged(password, onNameOrPassChanged);
    }
    void onUnloaded(object sender, RoutedEventArgs e) {
        Loaded -= onLoaded;
        Unloaded -= onUnloaded;
        nameDescriptor.RemoveValueChanged(userName, onNameOrPassChanged);
        passwordDescriptor.RemoveValueChanged(password, onNameOrPassChanged);
    }
    void onNameOrPassChanged(object? sender, EventArgs e) {
        if (string.IsNullOrWhiteSpace(userName.Text)
            || string.IsNullOrWhiteSpace(password.Text)) {
            login.IsEnabled = false;
        }
        else login.IsEnabled = true;
    }
    void initializeUI() {
        loginTo = new TextBlock() {
            Text = "Log in to",
            HorizontalAlignment = HorizontalAlignment.Center,
            FontSize = 14,
            FontWeight = FontWeights.Bold
        };
        appName = new TextBlock() {
            Text = app,
            HorizontalAlignment = HorizontalAlignment.Center,
            FontSize = 18,
            FontWeight = FontWeights.Bold
        };
        var topPanel = new StackPanel() {
            HorizontalAlignment = HorizontalAlignment.Center,
            VerticalAlignment = VerticalAlignment.Center,
            Children = { loginTo, appName }
        };
        userName = new EditText() {
            Icon = Icons.Tenant,
            Hint = "Name",
            IsRequired = true
        };
        password = new EditPassword() {
            Icon = Icons.Key,
            Hint = "Password",
            IsRequired = true
        };
        login = new CommandButton() {
            IsEnabled = false,
            Width = 24,
            Height = 24,
            Icon = Icons.Send,
            Command = validate
        };
        info = new TextBlock() {
            HorizontalAlignment = HorizontalAlignment.Center,
            Margin = new Thickness(0, 10, 0, 0)
        };
        loggedIn = new TextBlock() {
            HorizontalAlignment = HorizontalAlignment.Center,
            VerticalAlignment = VerticalAlignment.Bottom,
            Margin = new Thickness(0, 0, 0, 5)
        };
        connect = new CommandButton() {
            Visibility = Visibility.Collapsed,
            Width = 16,
            Height = 16,
            Icon = Icons.PlugIn,
            HorizontalAlignment = HorizontalAlignment.Right,
            VerticalAlignment = VerticalAlignment.Bottom,
            Margin = new Thickness(0,0,5,5),
            Command = reconnect
        };

        Grid.SetRow(userName, 1);
        Grid.SetRow(password, 2);
        Grid.SetRow(login, 3);
        Grid.SetRow(info, 4);
        Grid.SetRow(loggedIn, 5);
        Grid.SetRow(connect, 5);

        container = new Grid() {
            RowDefinitions = {
                new RowDefinition(),
                new RowDefinition() { Height = GridLength.Auto },
                new RowDefinition() { Height = GridLength.Auto },
                new RowDefinition() { Height = GridLength.Auto },
                new RowDefinition() { Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { topPanel, userName, password, login, info, loggedIn, connect }
        };
    }
    async void validate() {
        login.IsEnabled = false;
        var result = await getResult();
        if (result.IsSuccess) {
            info.Text = "logged in";
            loggedIn.Text = $"connecting to {app} service";
            pack.Role = result.Role;
            pack.UserId = result.UserId;

            await Task.Delay(2000);
            LoggedIn?.Invoke(this, loginSocket);
            bool isConnected = await connectToService();
            if (isConnected) {
                await Task.Delay(2000);
                InService?.Invoke(this);
            }
            else {
                connect.Visibility = Visibility.Visible;
            }
        }
        else {
            await Task.Delay(1000);
            info.Text = "try again";
            login.IsEnabled = true;
        }
    }
    async Task<LoginResult> getResult() {
        info.Text = "connecting to login server";
        await Task.Delay(1000);
        bool isConnected = false;
        loginSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        try {
            loginSocket.Connect(new IPEndPoint(IPAddress.Parse(Addresses.LoginAddress), Addresses.LoginPort));
            isConnected = true;
        }
        catch {
            info.Text = "failed to connect";
            await Task.Delay(1000);
            isConnected = false;
            loginSocket.Close();
            loginSocket.Dispose();

        }
        if (!isConnected) {
            var r = new LoginResult() { IsSuccess = false };
            return await Task.FromResult(r);
        }
        var user = new User() {
            App = app,
            UserName = userName.Text,
            Password = password.Text
        };
        await Task.Delay(2000);

        info.Text = "sending login information";
        await Task.Delay(2000);
        loginSocket.Send(user.GetBytes());

        info.Text = "waiting for result";
        await Task.Delay(2000);

        var header = new byte[4];
        int read = loginSocket.Receive(header);
        while (read < header.Length) {
            read += loginSocket.Receive(header, read, header.Length - read, SocketFlags.None);
        }
        var packet = new byte[BitConverter.ToInt32(header)];
        read = loginSocket.Receive(packet);
        while (read < packet.Length) {
            read += loginSocket.Receive(packet, read, packet.Length - read, SocketFlags.None);
        }
        var result = LoginResult.FromBytes(packet);
        if (!result.IsSuccess) {
            info.Text = "wrong username / password";
            loginSocket.Shutdown(SocketShutdown.Both);
            loginSocket.Close();
            loginSocket.Dispose();
            loginSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        }
        return await Task.FromResult(result);
    }
    Task<bool> connectToService() {
        pack.Receiver = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        pack.Receiver.NoDelay = true;
        bool isConnected = false;
        try {
            pack.Receiver.Connect(new IPEndPoint(pack.Address, pack.Port));
            pack.Receiver.Send(BitConverter.GetBytes(true));
            isConnected = true;
        }
        catch {
            isConnected = false;
            pack.Receiver.Close();
            pack.Receiver.Dispose();
        }
        if (isConnected) {
            loggedIn.Text = "connected to service";
        }
        else {
            loggedIn.Text = "failed to connect";
        }
        return Task.FromResult(isConnected);
    }
    async void reconnect() {
        loggedIn.Text = "trying to connect";
        connect.IsEnabled = false;
        await Task.Delay(2000);
        
        var isConnected = await connectToService();
        if (isConnected) {
            loggedIn.Text = "connected to service";
            await Task.Delay(2000);
            InService?.Invoke(this);
        }
        else {
            loggedIn.Text = "failed to connect";
            await Task.Delay(2000);
            connect.IsEnabled = true;
        }
    }

    protected override Visual GetVisualChild(int index) => windowBorder;
    protected override int VisualChildrenCount => 1;
}
