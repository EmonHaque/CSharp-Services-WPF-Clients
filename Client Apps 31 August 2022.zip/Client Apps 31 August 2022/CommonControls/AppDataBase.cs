﻿public abstract class AppDataBase
{
    int byteCount = 0;
    protected bool isConnected;
    protected BlockingCollection<byte[]> messages;
    protected LoadingWindow window;
    protected Dispatcher patch;
    protected ServicePack service;
    
    protected abstract void initializeCollections();
    protected abstract void populateCollections();
    protected abstract void processMessage();

    public event Action<LoadingWindow> Received;

    public void SetLoadingWindow(LoadingWindow w, ServicePack s) {
        window = w;
        service = s;
        patch = Application.Current.Dispatcher;
        window.Activated += onActivated;
    }
    async void onActivated(object? sender, EventArgs e) {
        window.Text = "initializing";
        await Task.Delay(2000);
        initializeCollections();
        new Thread(getInitialLoad) { IsBackground = true }.Start();
    }
    void getInitialLoad() {
        patch.Invoke(() => { window.Text = "trying to connect"; });
        Thread.Sleep(250);
        populateCollections();

        window.Activated -= onActivated;
        patch.Invoke(() => { window.Text = "launching ..."; });
        Thread.Sleep(1000);
        patch.Invoke(() => Received?.Invoke(window));

        isConnected = true;
        messages = new BlockingCollection<byte[]>();
        new Thread(receiveBroadcast) { IsBackground = true }.Start();
        new Thread(processMessage) { IsBackground = true }.Start();
    }
    protected byte[] getPacket() {
        var header = new byte[4];
        int read = service.Sender.Receive(header);
        while (read < header.Length) {
            read += service.Sender.Receive(header, read, header.Length - read, SocketFlags.None);
        }
        var size = BitConverter.ToInt32(header);
        if (size == 0) return new byte[0];

        var packet = new byte[size];
        read = service.Sender.Receive(packet);
        while (read < packet.Length) {
            read += service.Sender.Receive(packet, read, packet.Length - read, SocketFlags.None);
        }
        byteCount += packet.Length;
        patch.Invoke(() => {
            window.Text = $"{byteCount.ToString("N0")} bytes received";
        });
        Thread.Sleep(250);
        return packet;
    }
    void receiveBroadcast() {
        var header = new byte[4];
        while (isConnected) {
            try {
                int read = service.Receiver.Receive(header);
                while (read < header.Length) {
                    read += service.Receiver.Receive(header, read, header.Length - read, SocketFlags.None);
                }
                var size = BitConverter.ToInt32(header);
                var packet = new byte[size];
                read = service.Receiver.Receive(packet);
                while (read < packet.Length) {
                    read += service.Receiver.Receive(packet, read, packet.Length - read, SocketFlags.None);
                }
                messages.Add(packet);
            }
            catch {
                isConnected = false;
                //show some message and new up socket and reconnect
            }
        }
    }
}
