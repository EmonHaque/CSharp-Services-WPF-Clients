﻿class App : Application
{
    [STAThread]
    static void Main(string[] args) => new App().Run();
    protected override void OnStartup(StartupEventArgs e) {
        if (!IsRunningAsAdministrator()) {
            var process = new ProcessStartInfo();
            process.FileName = AppDomain.CurrentDomain.BaseDirectory + "Installer.exe";
            process.UseShellExecute = true;
            process.Verb = "runas";
            Process.Start(process);
            App.Current.Shutdown();
        }
        else {
            Current.MainWindow = new MainWindow();
            Current.MainWindow.Show();
        }
    }
    bool IsRunningAsAdministrator() {
        var identity = WindowsIdentity.GetCurrent();
        var principal = new WindowsPrincipal(identity);
        return principal.IsInRole(WindowsBuiltInRole.Administrator);
    }
}
