﻿public class PopupDraggable : Popup
{
    Point oldPosition;
    bool isMouseDown;
    public PopupDraggable() {
        AllowsTransparency = true;
        Placement = PlacementMode.Mouse;
        HorizontalOffset = 20;
        VerticalOffset = 20;
    }
    protected override void OnClosed(EventArgs e) {
        HorizontalOffset = 20;
        VerticalOffset = 20;
    }
    protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e) {
        isMouseDown = true;
        oldPosition = e.GetPosition(null);
        CaptureMouse();
    }
    protected override void OnMouseMove(MouseEventArgs e) {
        if (!isMouseDown) return;
        var offset = e.GetPosition(null) - oldPosition;
        HorizontalOffset += offset.X;
        VerticalOffset += offset.Y;
    }
    protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e) {
        isMouseDown = false;
        ReleaseMouseCapture();
    }
}
