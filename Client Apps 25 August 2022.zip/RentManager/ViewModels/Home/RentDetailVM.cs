﻿class RentDetailVM : Notifiable
{
    int? selectedTenant;
    public int? SelectedTenant {
        get { return selectedTenant; }
        set {
            if (selectedTenant != value) {
                selectedTenant = value;
                SelectionChanged?.Invoke(selectedTenant);
            }
        }
    }
    public List<DepositDueRent> Data { get; set; }
    public static event Action<int?> SelectionChanged;
    public static event Action Loaded;

    public RentDetailVM() {
        RentVM.SelectionChanged += onSelectionChanged;
        Loaded?.Invoke();
    }
    
    void onSelectionChanged(int? id, List<DepositDueRent> list) {
        Data = list.Where(x => x.PlotId == id).ToList();
        OnPropertyChanged(nameof(Data));
    }
}
