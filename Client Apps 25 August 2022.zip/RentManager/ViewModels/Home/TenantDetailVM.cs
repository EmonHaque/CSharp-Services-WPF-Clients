﻿class TenantDetailVM : Notifiable
{
    bool isSelectedByUser;
    string query;
    public string Query {
        get { return query; }
        set {
            if (query != value) {
                query = value?.Trim().ToLower();
                Tenants.Refresh();
            }
        }
    }
    int? selectedTenant;
    public int? SelectedTenant {
        get { return selectedTenant; }
        set {
            if (selectedTenant != value) {
                selectedTenant = value;
                onTenatChanged(value);
            }
        }
    }
    bool state;
    public bool State {
        get { return state; }
        set {
            if (state != value) {
                state = value;
                Tenants.Refresh();
                if (isSelectedByUser) isSelectedByUser = false;
                else {
                    SelectedTenant = Tenants.CurrentItem == null ? null : ((Tenant)Tenants.CurrentItem).Id;
                    OnPropertyChanged(nameof(SelectedTenant));
                }
            }
        }
    }
    string status;
    public string Status {
        get { return status; }
        set { status = value; OnPropertyChanged(nameof(Status)); }
    }
    public List<RentPayment> Data { get; set; }
    public Action Refresh { get; set; }
    public bool IsRefreshvalid { get; set; }
    public ICollectionView Tenants { get; set; }
    public string Deposit { get; set; }

    public TenantDetailVM() {
        Tenants = new CollectionViewSource() { Source = AppData.tenants }.View;
        Tenants.Filter = filterTenants;
        RentDetailVM.SelectionChanged += setTenant; ;
        Refresh = () => onTenatChanged(SelectedTenant);
        State = true;
    }

    void setTenant(int? o) {
        if (!State) {
            isSelectedByUser = true;
            State = true;
            OnPropertyChanged(nameof(State));
        }
        SelectedTenant = o;
        OnPropertyChanged(nameof(SelectedTenant));
    }
    bool filterTenants(object o) {
        var tenant = (Tenant)o;
        switch (State) {
            case true:
                return string.IsNullOrWhiteSpace(Query) ? true && !tenant.HasLeft : tenant.Name.ToLower().Contains(Query) && !tenant.HasLeft;
            case false:
                return string.IsNullOrWhiteSpace(Query) ? true && tenant.HasLeft : tenant.Name.ToLower().Contains(Query) && tenant.HasLeft;
        }
    }
    async void onTenatChanged(int? id) {
        if (SelectedTenant == null) {
            Data = null;
            IsRefreshvalid = false;
            Deposit = null;
            OnPropertyChanged(nameof(IsRefreshvalid));
            OnPropertyChanged(nameof(Data));
            OnPropertyChanged(nameof(Deposit));
            return;
        }
        Status = "requesting data";
        await Task.Delay(250);
        var request = new RentManagerRequest() {
            UserId = App.service.UserId,
            Method = (int)Function.GetTenantDetail,
            Args = new object[] { id.Value }
        };
        var response = await App.service.GetResponse(request);
        Status = "received " + response.Packet.Length.ToString("N0") + " bytes";
        await Task.Delay(250);
        if (!response.IsSuccess) {
            Status = LocalConstants.DownMessage;
            return;
        }
        Data = await getEntries(response.Packet);

        IsRefreshvalid = true;
        OnPropertyChanged(nameof(Deposit));
        OnPropertyChanged(nameof(IsRefreshvalid));
        OnPropertyChanged(nameof(Data));
    }

    Task<List<RentPayment>> getEntries(byte[] packet) {
        var list = new List<RentPayment>();
        var span = new ReadOnlySpan<byte>(packet);
        Deposit = "Deposit " + BitConverter.ToInt32(span.Slice(0, 4)).ToString("N0");
        int read, start, index; ;
        read = start = 4;
        index = 0;
        while (read < span.Length) {
            var segments = new string[4];
            while (read < span.Length) {
                if (span[read] != 0) {
                    read++;
                    continue;
                }
                segments[index++] = Encoding.ASCII.GetString(span.Slice(start, read - start));
                start = ++read;
                if (index == segments.Length) break;
            }
            list.Add(new RentPayment() {
                Date = DateTime.ParseExact(segments[0], "yyyy-MM-dd", CultureInfo.CurrentCulture.DateTimeFormat),
                Plot = segments[1],
                Space = segments[2],
                Tenant = segments[3],
                Due = BitConverter.ToInt32(span.Slice(start, 4)),
                Cash = BitConverter.ToInt32(span.Slice(start + 4, 4)),
                Mobile = BitConverter.ToInt32(span.Slice(start + 8, 4)),
                Kind = BitConverter.ToInt32(span.Slice(start + 12, 4)),
                TotalPaid = BitConverter.ToInt32(span.Slice(start + 16, 4))
            });
            read += 20;
            start = read;
            index = 0;
        }
        return Task.FromResult(list);
    }
}
