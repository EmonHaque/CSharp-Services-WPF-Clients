﻿class EditView : ViewContainer
{
    override public string Icon => Icons.Edit;
    public EditView() {
        Children.Add(new EditPlot());
        Children.Add(new EditSpace());
        Children.Add(new EditTenant());
        Children.Add(new EditHead());
        Children.Add(new EditLease());
        Children.Add(new EditTransaction());
    }
}
