﻿class ReportDates : Notifiable
{
    public DateTime Start { get; set; }
    public DateTime End { get; set; }
    public DateTime? From { get; set; }
    public DateTime? To { get; set; }

    public ReportDates() {
        From = DateTime.Now;
        To = DateTime.Now;
    }
}
