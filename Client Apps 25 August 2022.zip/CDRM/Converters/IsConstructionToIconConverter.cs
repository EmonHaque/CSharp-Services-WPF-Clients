﻿class IsConstructionToIconConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) {
        var v = (byte)value;
        switch (v) {
            case 0: return Icons.Construction;
            case 1: return Icons.Development;
            case 2: return Icons.Repair;
            default: return Icons.Maintenance;
        }
    }
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) {
        throw new NotImplementedException();
    }
}
