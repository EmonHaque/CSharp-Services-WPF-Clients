﻿class SingleHeadwisePurchaseVM : SinglePurchasePayableBaseVM<Head>
{
    protected override string type => "Head";
    protected override ObservableCollection<Head> source => AppData.heads;
}
