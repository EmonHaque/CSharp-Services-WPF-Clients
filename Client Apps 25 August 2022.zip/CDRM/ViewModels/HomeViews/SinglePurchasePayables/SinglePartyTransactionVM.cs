﻿class SinglePartyTransactionVM : SinglePurchasePayableBaseVM<Party>
{
    protected override string type => "Party";
    protected override ObservableCollection<Party> source => AppData.parties;
}
