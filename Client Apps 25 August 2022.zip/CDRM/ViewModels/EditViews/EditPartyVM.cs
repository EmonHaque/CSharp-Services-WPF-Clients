﻿class EditPartyVM : EditBaseVM<Party>
{
    protected override CollectionViewSource cvs => new CollectionViewSource() {
        Source = AppData.parties,
        IsLiveSortingRequested = true,
        LiveSortingProperties = { nameof(IHaveName.Name) }
    };

    protected override Party clone() {
        return new Party() {
            Id = Selected.Id,
            Name = Selected.Name,
            Address = Selected.Address,
            Phone = Selected.Phone
        };
    }
    protected override async void update() {
        var request = new CDRMRequest() {
            UserId = App.service.UserId,
            Method = (int)Function.EditParty,
            Args = new object[] {
                new NetParty() {
                    Id = Edited.Id,
                    Name = Edited.Name,
                    Address = Edited.Address,
                    Phone = Edited.Phone
                }
            }
        };
        var response = await App.service.GetResponse(request);
        if (!response.IsSuccess) {
            InfoDialog.Activate("Party", LocalConstants.ServiceDown);
        }
    }
}

