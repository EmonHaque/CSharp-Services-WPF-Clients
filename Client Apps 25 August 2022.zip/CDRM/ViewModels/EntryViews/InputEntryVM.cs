﻿class InputEntryVM : Notifiable
{
    EntryInsert entry;
    public double Top { get; set; }
    public double Left { get; set; }
    public double Width { get; set; }
    public double Height { get; set; }

    string siteAddress;
    public string SiteAddress {
        get { return siteAddress; }
        set { siteAddress = value; OnPropertyChanged(nameof(SiteAddress)); }
    }
    string partyAddress;
    public string PartyAddress {
        get { return partyAddress; }
        set { partyAddress = value; OnPropertyChanged(nameof(PartyAddress)); }
    }
    string partyPhone;
    public string PartyPhone {
        get { return partyPhone; }
        set { partyPhone = value; OnPropertyChanged(nameof(partyPhone)); }
    }

    public byte TransactionType { get; set; }
    public EntryPurchaseSell PurchaseSell { get; set; }
    public EntryReceiptPayment ReceiptPayment { get; set; }
    public ObservableCollection<EntryReceiptPayment> ReceiptPayments { get; set; }
    public Action<EntryReceiptPayment> RemoveReceiptPayment { get; set; }
    public static event Action<EntryInsert> EntryRequested;
    public event Action CoordinateRequested;

    public InputEntryVM() {
        ReceiptPayments = new ObservableCollection<EntryReceiptPayment>();
        PurchaseSell = new EntryPurchaseSell() { Date = DateTime.Today };
        ReceiptPayment = new EntryReceiptPayment();
        RemoveReceiptPayment = removeReceiptPayment;
    }

    bool isMultipleRPValid() {
        var first = ReceiptPayments.First();
        var date = first.Date;
        var errors = new List<ValidationError>();

        if (PurchaseSell.Date is null) {
            errors.Add(new ValidationError() {
                Head = nameof(PurchaseSell.Date),
                Error = date.Value.ToString("dd MMMM yyyy") + " expected"
            });
        }
        else if (!(PurchaseSell.Date.Value == first.Date.Value)) {
            errors.Add(new ValidationError() {
                Head = nameof(PurchaseSell.Date),
                Error = date.Value.ToString("dd MMM yyyy") + " expected"
            });
        }
        var party = AppData.parties.First(x => x.Id == first.PartyId).Name;
        if (!PurchaseSell.Party.Equals(party, StringComparison.InvariantCultureIgnoreCase)) {
            errors.Add(new ValidationError() {
                Head = nameof(PurchaseSell.Party),
                Error = party + " expected"
            });
        }

        if (TransactionType == 0 || TransactionType == 1) {
            if (!first.IsPurchaseOrSell) {
                var type = "";
                switch (first.IsReceipt) {
                    case 0: type = "payment"; break;
                    default: type = "receipt"; break;
                }
                errors.Add(new ValidationError() {
                    Head = "Transaction",
                    Error = type + " entry expected"
                });
            }
            else if (TransactionType != first.IsReceipt) {
                var type = "";
                switch (first.IsReceipt) {
                    case 0: type = "purchase"; break;
                    default: type = "sell"; break;
                }
                errors.Add(new ValidationError() {
                    Head = "Transaction",
                    Error = type + " entry expected"
                });
            }
            if(first.IsConstruction != PurchaseSell.IsConstruction) {
                var type = "";
                switch (first.IsConstruction) {
                    case 0: type = "Construction"; break;
                    case 1: type = "Development"; break;
                    case 2: type = "Repair"; break;
                    default: type = "Maintenance"; break;
                }
                errors.Add(new ValidationError() {
                    Head = type,
                    Error = type.ToLower() + " entry expected"
                });
            }
            foreach (var e in ReceiptPayments) {
                if (e.IsCash == ReceiptPayment.IsCash) {
                    var medium = "";
                    switch (ReceiptPayment.IsCash) {
                        case 0: medium = "Cash"; break;
                        case 1: medium = "Mobile"; break;
                        default: medium = "Discount"; break;
                    }
                    errors.Add(new ValidationError() {
                        Head = medium,
                        Error = "only 1 " + medium.ToLower() + " entry expected"
                    });
                    break;
                }
            }
        }
        else {
            var tt = TransactionType - 2;
            if (first.IsPurchaseOrSell) {
                var type = "";
                switch (first.IsReceipt) {
                    case 0: type = "purchase"; break;
                    default: type = "sell"; break;
                }
                errors.Add(new ValidationError() {
                    Head = "Transaction",
                    Error = type + " entry expected"
                });
            }
            else if (tt != first.IsReceipt) {
                var type = "";
                switch (first.IsReceipt) {
                    case 0: type = "payment"; break;
                    default: type = "receipt"; break;
                }
                errors.Add(new ValidationError() {
                    Head = "Transaction",
                    Error = type + " entry expected"
                });
            }

            var head = AppData.heads.First(x => x.Id == first.HeadId).Name;
            if (head.Equals("Discount")) head = first.HeadForDiscount;
            if (string.IsNullOrWhiteSpace(ReceiptPayment.Head)) {
                errors.Add(new ValidationError() {
                    Head = nameof(ReceiptPayment.Head),
                    Error = head + " expected"
                });
            }
            else if (!ReceiptPayment.Head.Equals(head)) {
                errors.Add(new ValidationError() {
                    Head = nameof(ReceiptPayment.Head),
                    Error = head + " expected"
                });
            }
            else {
                foreach (var e in ReceiptPayments) {
                    if (e.IsCash == ReceiptPayment.IsCash) {
                        var medium = "";
                        switch (ReceiptPayment.IsCash) {
                            case 0: medium = "Cash"; break;
                            case 1: medium = "Mobile"; break;
                            default: medium = "Discount"; break;
                        }
                        errors.Add(new ValidationError() {
                            Head = medium,
                            Error = "only 1 " + medium.ToLower() + " entry expected"
                        });
                        break;
                    }
                }
            }
        }
        bool isValid = errors.Count == 0;
        if (!isValid) {
            CoordinateRequested?.Invoke();
            var errorDialog = new ErrorDialog(Left, Top, Width, Height, errors);
            errorDialog.ShowDialog();
        }
        return isValid;
    }
    public async void AddReceiptPayment() {
        if (ReceiptPayments.Count > 0) {
            if (!isMultipleRPValid()) return;
        }

        var entry = new EntryReceiptPayment() {
            Date = PurchaseSell.Date,
            Party = PurchaseSell.Party,
            Amount = ReceiptPayment.Amount,
            IsCash = ReceiptPayment.IsCash,
            IsPurchaseOrSell = TransactionType < 2,
            Narration = PurchaseSell.Narration
        };
        switch (TransactionType) {
            case 0: // Purchase
                entry.Head = entry.IsCash == 2 ? "Discount" : "Payable";
                entry.IsReceipt = 0;
                entry.IsConstruction = PurchaseSell.IsConstruction;
                break;
            case 1: // Sell
                entry.Head = entry.IsCash == 2 ? "Discount" : "Receivable";
                entry.IsReceipt = 1;
                entry.IsConstruction = PurchaseSell.IsConstruction;
                break;
            case 2: // Payment
                entry.Head = entry.IsCash == 2 ? "Discount" : ReceiptPayment.Head;
                entry.IsReceipt = 0;
                break;
            default: // Receipt
                entry.Head = entry.IsCash == 2 ? "Discount" : ReceiptPayment.Head;
                entry.IsReceipt = 1;
                break;
        }
        var validator = new ReceiptPaymentValidator(entry);
        if (!validator.IsValid()) {
            CoordinateRequested?.Invoke();
            var errorDialog = new ErrorDialog(Left, Top, Width, Height, validator.Errors);
            errorDialog.ShowDialog();
            return;
        }
        var request = new CDRMRequest() { UserId = App.service.UserId };
        Response response = null;

        if (!validator.DoesExist()) {
            CoordinateRequested?.Invoke();
            var confirmDialog = new ConfirmCreationDialog(Left, Top, Width, Height, validator.Errors);
            var result = confirmDialog.ShowDialog();
            if (!result.HasValue) return;
            if (!result.Value) return;

            bool isSuccess = await validator.Resolve(Left, Top, Width, Height);
            if (!isSuccess) {
                InfoDialog.Activate("Creation", LocalConstants.ServiceDown);
                return;
            }
        }
        if (entry.Head.Equals("Discount")) {
            entry.HeadForDiscount = ReceiptPayment.Head;
        }
        ReceiptPayments.Add(entry);

        PurchaseSell.Narration = "";
        var headName = ReceiptPayment.Head;
        ReceiptPayment = new EntryReceiptPayment() { IsCash = entry.IsCash };
        if (TransactionType == 2 || TransactionType == 3) {
            ReceiptPayment.Head = headName;
        }
        OnPropertyChanged(nameof(ReceiptPayment));
        PurchaseSell.OnPropertyChanged(nameof(PurchaseSell.Narration));
    }
    public void SetSiteAddress() {
        if (string.IsNullOrWhiteSpace(PurchaseSell.Site)) {
            SiteAddress = null;
            return;
        }
        var site = AppData.sites.FirstOrDefault(x => x.Name.Equals(PurchaseSell.Site, StringComparison.InvariantCultureIgnoreCase));
        if (site is null) {
            SiteAddress = null;
            return;
        }
        SiteAddress = site.Address;
    }
    public void SetPartyAddress() {
        if (string.IsNullOrWhiteSpace(PurchaseSell.Party)) {
            PartyAddress = PartyPhone = null;
            return;
        }
        var party = AppData.parties.FirstOrDefault(x => x.Name.Equals(PurchaseSell.Party, StringComparison.InvariantCultureIgnoreCase));
        if (party is null) {
            PartyAddress = PartyPhone = null;
            return;
        }
        PartyAddress = party.Address;
        PartyPhone = party.Phone;
    }
    public void AddEntry() {
        if (TransactionType == 0 /*Purchase*/ || TransactionType == 1 /*Sell*/) {
            addPurchaseSell();
        }
        else {
            entry = new EntryInsert() {
                Date = PurchaseSell.Date.Value.ToString("yyyy-MM-dd"),
                IsTopLevel = false
            };
            foreach (var item in ReceiptPayments) {
                entry.ReceiptPayments.Add(item);
            }
            EntryRequested?.Invoke(entry);
            ReceiptPayments.Clear();
        }
    }
    async void addPurchaseSell() {
        var validator = new PurchaseSellValidator(PurchaseSell);
        if (!validator.IsValid()) {
            CoordinateRequested?.Invoke();
            var errorDialog = new ErrorDialog(Left, Top, Width, Height, validator.Errors);
            errorDialog.ShowDialog();
            return;
        }

        entry = new EntryInsert() {
            Date = PurchaseSell.Date.Value.ToString("yyyy-MM-dd"),
            IsSell = TransactionType,
            IsConstruction = PurchaseSell.IsConstruction,
            Amount = int.Parse(PurchaseSell.Amount),
            IsTopLevel = true,
            Narration = PurchaseSell.Narration?.Trim()
        };
        var request = new CDRMRequest() { UserId = App.service.UserId };
        Response response = null;
        if (!validator.DoesExist()) {
            CoordinateRequested?.Invoke();
            var confirmDialog = new ConfirmCreationDialog(Left, Top, Width, Height, validator.Errors);
            var result = confirmDialog.ShowDialog();
            if (!result.HasValue) return;
            if (!result.Value) return;

            var isSuccess = await validator.Resolve(Left, Top, Width, Height);
            if (!isSuccess) {
                InfoDialog.Activate("Creation", LocalConstants.ServiceDown);
                return;
            }
        }
        foreach (var item in ReceiptPayments) {
            entry.ReceiptPayments.Add(item);
        }
        EntryRequested?.Invoke(entry);
        PurchaseSell = new EntryPurchaseSell() { 
            Date = DateTime.Today,
            IsConstruction = entry.IsConstruction,
            IsSell = entry.IsSell,
            Site = entry.Site,
            Party = entry.Party
        };
        OnPropertyChanged(nameof(PurchaseSell));
        ReceiptPayments.Clear();
    }
    void removeReceiptPayment(object o) {
        var e = (EntryReceiptPayment)o;
        ReceiptPayments.Remove(e);
    }
}
