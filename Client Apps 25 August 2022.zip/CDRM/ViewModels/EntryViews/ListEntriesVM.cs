﻿class ListEntriesVM : Notifiable
{
    List<EntryInsert> original;
    ObservableCollection<EntryInsert> entries;

    string status;
    public string Status {
        get { return status; }
        set { status = value; OnPropertyChanged(nameof(Status)); }
    }
    public bool CanUpdate { get; set; }
    public ICollectionView Entries { get; set; }
    public Action<EntryInsert> RemoveEntry { get; set; }

    public ListEntriesVM() {
        original = new List<EntryInsert>();
        entries = new ObservableCollection<EntryInsert>();
        Entries = new CollectionViewSource() {
            Source = entries,
            IsLiveGroupingRequested = true,
            LiveGroupingProperties = { nameof(EntryInsert.Site) }
        }.View;
        Entries.GroupDescriptions.Add(new PropertyGroupDescription(nameof(EntryInsert.Site)));
        RemoveEntry = onRemoveEntry;
        InputEntryVM.EntryRequested += onEntryRequest;
    }

    public async void Insert() {
        if (!CanUpdate) return;
        CanUpdate = false;
        OnPropertyChanged(nameof(CanUpdate));

        var list = new List<NetEntryInsert>();
        foreach (var e in original) {
            bool isPS = false;
            string narration = "";
            if (e.IsTopLevel) isPS = true;
            if (!string.IsNullOrWhiteSpace(e.Narration)) narration = e.Narration;
            list.Add(new NetEntryInsert() {
                IsPS = isPS,
                Narration = narration,
                IsCash = e.IsCash,
                IsSell = e.IsSell,
                IsConstruction = e.IsConstruction,
                IsReceipt = e.IsReceipt,
                Amount = e.Amount,
                SiteId = e.SiteId,
                HeadId = e.HeadId,
                PartyId = e.PartyId,
                SubHeadId = e.SubHeadId,
                UnitId = e.UnitId,
                Quantity = e.Quantity,
                Date = e.Date
            });
        }
        var request = new CDRMRequest() {
            UserId = App.service.UserId,
            Method = (int)Function.AddEntries,
            Args = new object[] { list }
        };
        var response = await App.service.GetResponse(request);
        if (!response.IsSuccess) {
            InfoDialog.Activate("Entries", LocalConstants.ServiceDown);
            CanUpdate = true;
            OnPropertyChanged(nameof(CanUpdate));
            return;
        }

        entries.Clear();
        original.Clear();
        CanUpdate = true;
        OnPropertyChanged(nameof(CanUpdate));
    }
    void onEntryRequest(EntryInsert e) {
        if (e.IsTopLevel) {
            entries.Add(e);
            original.Add(e);
            foreach (var item in e.ReceiptPayments) {
                var en = new EntryInsert() {
                    Date = e.Date,
                    SiteId = e.SiteId,
                    PartyId = e.PartyId,
                    HeadId = item.HeadId,
                    Party = item.Party,
                    Head = item.Head,
                    IsTopLevel = false,
                    Amount = int.Parse(item.Amount, NumberStyles.Number, CultureInfo.CurrentCulture.NumberFormat),
                    IsCash = item.IsCash,
                    IsReceipt = item.IsReceipt
                };
                if (e.IsSell == 0 || e.IsSell == 2) en.Site = "Payment";
                else en.Site = "Receipt";
                entries.Add(en);
                original.Add(en);
            }
        }
        else {
            foreach (var item in e.ReceiptPayments) {
                var en = new EntryInsert() {
                    Date = e.Date,
                    SiteId = e.SiteId,
                    Site = e.Site,
                    PartyId = item.PartyId,
                    HeadId = item.HeadId,
                    Party = item.Party,
                    Head = item.Head,
                    IsTopLevel = false,
                    Amount = int.Parse(item.Amount, NumberStyles.Number, CultureInfo.CurrentCulture.NumberFormat),
                    IsCash = item.IsCash,
                    IsReceipt = item.IsReceipt
                };
                entries.Add(en);
                original.Add(en);
            }
        }
        if (!CanUpdate) {
            CanUpdate = true;
            OnPropertyChanged(nameof(CanUpdate));
        }
    }
    void onRemoveEntry(object o) {
        var e = (EntryInsert)o;
        original.Remove(e);
        entries.Remove(e);
        if (entries.Count == 0) {
            CanUpdate = false;
            OnPropertyChanged(nameof(CanUpdate));
        }
    }
}

