﻿interface IHaveIcon
{
    string Icon { get; }
}

