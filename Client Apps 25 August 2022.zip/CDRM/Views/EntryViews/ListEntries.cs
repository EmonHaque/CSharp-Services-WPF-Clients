﻿class ListEntries : CardView
{
    public override string Header => "Entries";

    ListBox list;
    Separator separator;
    ActionButton add;
    TextBlock status;
    ListEntriesVM vm;

    public override void OnFirstSight() {
        base.OnFirstSight();
        vm = new ListEntriesVM();
        DataContext = vm;
        initializeUI();
        bind();
    }
    void initializeUI() {
        list = new ListBox() {
            ItemTemplate = new ListEntryTemplate(new Binding(nameof(vm.RemoveEntry)) { Source = vm }),
            GroupStyle = {
                new GroupStyle() {
                    ContainerStyle = new Style(typeof(GroupItem)) {
                        Setters = { new Setter(GroupItem.TemplateProperty, new ListEntryGroupTemplate())}
                    }
                }
            },
            Resources = {{
                    typeof(ScrollViewer),
                    new Style() {
                        Setters = {
                            new Setter(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled),
                            new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate(false))
                        }
                    }
                }
            }
        };
        list.SetValue(Grid.IsSharedSizeScopeProperty, true);
        list.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        list.SetValue(ScrollViewer.VerticalScrollBarVisibilityProperty, ScrollBarVisibility.Auto);

        separator = new Separator() {
            Background = Brushes.LightGray,
            Height = 0.5
        };
        status = new TextBlock() { VerticalAlignment = VerticalAlignment.Center };
        add = new ActionButton() {
            Margin = new Thickness(0, 5, 0, 0),
            Width = 16,
            Height = 16,
            HorizontalAlignment = HorizontalAlignment.Right,
            Icon = Icons.Add,
            ToolTip = "Insert",
            Command = vm.Insert
        };
        Grid.SetRow(separator, 1);
        Grid.SetRow(status, 2);
        Grid.SetRow(add, 2);
        var grid = new Grid() {
            RowDefinitions = {
                new RowDefinition(),
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(){Height = GridLength.Auto}
            },
            Children = { list, separator, status, add }
        };
        setContent(grid);
    }
    void bind() {
        status.SetBinding(TextBlock.TextProperty, new Binding(nameof(vm.Status)));
        add.SetBinding(ActionButton.IsEnabledProperty, new Binding(nameof(vm.CanUpdate)));
        list.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(vm.Entries)));
    }
}
