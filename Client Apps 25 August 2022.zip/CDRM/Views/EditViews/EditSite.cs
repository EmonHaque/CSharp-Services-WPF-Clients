﻿class EditSite : EditBase<Site>
{
    public override string Header => "Site";
    public override string Icon => Icons.Plot;

    EditSiteVM vm;
    EditSiteControl site;
    protected override IEdit<Site> viewModel => vm;
    protected override EditNameControl editElement => site;
    protected override void initialize() {
        vm = new EditSiteVM();
        site = new EditSiteControl();
    }
}
