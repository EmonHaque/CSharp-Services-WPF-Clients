﻿class LoadingWindow : Window
{
    Run loadText;
    Path arc;
    PointAnimationUsingPath pointAnim;
    BooleanAnimationUsingKeyFrames isLargeAnim;
    string text;
    public string Text {
        get { return text; }
        set { text = value; loadText.Text = value; }
    }

    public LoadingWindow() {
        Height = Width = 300;
        WindowStartupLocation = WindowStartupLocation.CenterScreen;
        WindowStyle = WindowStyle.None;
        ResizeMode = ResizeMode.NoResize;
        AllowsTransparency = true;
        ShowInTaskbar = false;
        Background = Brushes.Transparent;

        loadText = new Run() { Foreground = Brushes.Coral, FontSize = 16 };
        initializeContent();
        initializeAnimations();
        Loaded += animateArc;
        Unloaded += onUnloaded;
    }

    void onUnloaded(object sender, RoutedEventArgs e) {
        Loaded -= animateArc;
        Unloaded -= onUnloaded;
    }
    void initializeAnimations() {
        pointAnim = new PointAnimationUsingPath() {
            PathGeometry = PathGeometry.CreateFromGeometry(arc.Data),
            Duration = TimeSpan.FromSeconds(2),
            AccelerationRatio = 0.5,
            DecelerationRatio = 0.5,
            RepeatBehavior = RepeatBehavior.Forever
        };
        isLargeAnim = new BooleanAnimationUsingKeyFrames() {
            KeyFrames = {
                    new DiscreteBooleanKeyFrame(false, TimeSpan.FromSeconds(0)),
                    new DiscreteBooleanKeyFrame(true, TimeSpan.FromSeconds(1)),
                    new DiscreteBooleanKeyFrame(false, TimeSpan.FromSeconds(2))
                },
            RepeatBehavior = RepeatBehavior.Forever
        };
    }
    void animateArc(object sender, RoutedEventArgs e) {
        var segment = (ArcSegment)((PathGeometry)arc.Data).Figures[0].Segments[0];
        segment.BeginAnimation(ArcSegment.PointProperty, pointAnim);
        segment.BeginAnimation(ArcSegment.IsLargeArcProperty, isLargeAnim);
    }
    void initializeContent() {
        var ellipse = new Path() {
            HorizontalAlignment = HorizontalAlignment.Center,
            VerticalAlignment = VerticalAlignment.Center,
            Fill = new SolidColorBrush(Color.FromRgb(50, 50, 50)),
            Data = new EllipseGeometry() {
                Center = new Point(150, 150),
                RadiusX = 150,
                RadiusY = 150
            }
        };
        arc = new Path() {
            Stroke = Brushes.Coral,
            StrokeThickness = 5,
            Data = new PathGeometry() {
                Figures = {
                        new PathFigure() {
                            StartPoint = new Point(298, 150),
                            Segments = {
                                new ArcSegment() {
                                    IsLargeArc = true,
                                    Point = new Point(298, 149.9),
                                    Size = new Size(148,148),
                                    SweepDirection = SweepDirection.Clockwise
                                }
                            }
                        }
                    }
            }
        };
        var image = new Image() {
            Margin = new Thickness(0, 10, 0, 0),
            HorizontalAlignment = HorizontalAlignment.Center,
            VerticalAlignment = VerticalAlignment.Top,
            Width = 96,
            Height = 96,
        };
        using (var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("RentManager.Resources.LoadingIcon.png")) {
            image.Source = BitmapFrame.Create(stream, BitmapCreateOptions.None, BitmapCacheOption.OnLoad);
        }
        var text = new TextBlock() {
            Margin = new Thickness(0, 0, 0, 60),
            HorizontalAlignment = HorizontalAlignment.Center,
            VerticalAlignment = VerticalAlignment.Bottom,
            TextAlignment = TextAlignment.Center,
            
            Foreground = Brushes.Coral,
            Inlines = {
                    new Run(){Text = "Rent Manager", FontSize = 36, Foreground = Brushes.SkyBlue, FontWeight = FontWeights.Bold },
                    new LineBreak(),
                    loadText
                }
        };
        Content = new Grid() { Children = { ellipse, text, arc, image } };
    }
}
