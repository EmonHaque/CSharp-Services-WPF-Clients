﻿class RentVM : Notifiable
{
    List<DepositDueRent> list;
    byte state;
    public byte State {
        get { return state; }
        set {
            if (state != value) {
                state = value; 
                getData();
            }
        }
    }
    int? selected;
    public int? Selected {
        get { return selected; }
        set {
            if (selected != value) {
                selected = value;
                SelectionChanged?.Invoke(value, list);
            }
        }
    }
    string status;
    public string Status {
        get { return status; }
        set { status = value; OnPropertyChanged(nameof(Status)); }
    }
    public Action Refresh { get; set; }
    public List<PlotSummary> Summary { get; set; }
    public static event Action<int?, List<DepositDueRent>> SelectionChanged;

    public RentVM() {
        State = 0;
        getData();
        Refresh = getData;
        if (Summary.Count > 0) {
            Selected = Summary.First().Id;
        }
        RentDetailVM.Loaded += onLoaded;
    }

    void onLoaded() {
        SelectionChanged?.Invoke(Selected, list);
        RentDetailVM.Loaded -= onLoaded;
    }
    async void getData() {
        Summary = new List<PlotSummary>();
        if (State == 0) {
            Status = "";
            list = new List<DepositDueRent>();
            foreach (var plot in AppData.plots) {
                foreach (var item in AppData.leases) {
                    if (item.PlotId == plot.Id && !item.IsExpired) {
                        list.Add(new DepositDueRent() {
                            State = DepositDueRentState.Rent,
                            PlotId = item.PlotId,
                            SpaceId = item.SpaceId,
                            TenantId = item.TenantId,
                            Amount = item.FixedReceivables.Sum(x => x.Amount)
                        });
                    }
                }
                Summary.Add(new PlotSummary() {
                    Id = plot.Id,
                    Name = plot.Name,
                    Total = AppData.leases.Where(x => x.PlotId == plot.Id && !x.IsExpired).Select(x => x.FixedReceivables.Select(y => y.Amount).Sum()).Sum()
                });
            }
        }
        else {
            Status = "requesting data";
            await Task.Delay(250);
            var request = new RentManagerRequest() {
                UserId = App.service.UserId,
                Method = (int)Function.GetDepositDueRent,
                Args = new object[] { State }
            };

            var response = await App.service.GetResponse(request);
            Status = "received " + response.Packet.Length.ToString("N0") + " bytes";
            await Task.Delay(250);
            if (!response.IsSuccess) {
                return;
            }

            list = await getEntries(response.Packet);
            foreach (var plot in AppData.plots) {
                Summary.Add(new PlotSummary() {
                    Id = plot.Id,
                    Name = plot.Name,
                    Total = list.Where(x => x.PlotId == plot.Id).Sum(x => x.Amount)
                });
            }
        }
        OnPropertyChanged(nameof(Summary));

        int id = Selected is null ? 1 : Selected.Value;
        SelectionChanged?.Invoke(id, list);
    }
    Task<List<DepositDueRent>> getEntries(byte[] packet) {
        var list = new List<DepositDueRent>();
        var span = new ReadOnlySpan<byte>(packet);
        int read = 0;
        while (read < span.Length) {
            list.Add(new DepositDueRent() {
                State = (DepositDueRentState)span.Slice(read, 1)[0],
                PlotId = BitConverter.ToInt32(span.Slice(read + 1, 4)),
                SpaceId = BitConverter.ToInt32(span.Slice(read + 5, 4)),
                TenantId = BitConverter.ToInt32(span.Slice(read + 9, 4)),
                Amount = BitConverter.ToInt32(span.Slice(read + 13, 4))
            });
            read += 17;
        }
        return Task.FromResult(list);
    }
}
