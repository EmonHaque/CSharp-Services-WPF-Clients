﻿class EditTransactionVM : EditBase<Transaction>
{
    ObservableCollection<Transaction> transactions;
    ObservableCollection<Lease> plots, spaces;
    CollectionViewSource tenants, controlHeads, heads, editables;
    bool isEqual;
    DateTime? transactionDate;
    public DateTime? TransactionDate {
        get { return transactionDate; }
        set {
            if (transactionDate != value) {
                transactionDate = value;
                if (value == null) {
                    IsRefreshValid = false;
                    transactions.Clear();
                }
                else {
                    IsRefreshValid = true;
                    getTransactions();
                }
                OnPropertyChanged(nameof(IsRefreshValid));
            }
        }
    }
    string amount;
    public string Amount {
        get { return amount; }
        set {
            if (amount != value) {
                amount = value;
                OnPropertyChanged(nameof(Amount));
                validateAmount();
            }
        }
    }
    string filterName;
    public string FilterName {
        get { return filterName; }
        set {
            if (filterName != value) {
                filterName = value?.Trim().ToLower();
                Editables.Refresh();
            }
        }
    }
    string status;
    public string Status {
        get { return status; }
        set { status = value; OnPropertyChanged(nameof(Status)); }
    }

    public string TenantQuery { get; set; }
    public string PlotQuery { get; set; }
    public string SpaceQuery { get; set; }
    public string ControlQuery { get; set; }
    public string HeadQuery { get; set; }
    public string ErrorTenantId { get; set; }
    public string ErrorPlotId { get; set; }
    public string ErrorSpaceId { get; set; }
    public string ErrorControlId { get; set; }
    public string ErrorHeadId { get; set; }
    public string ErrorDate { get; set; }
    public string ErrorAmount { get; set; }
    public string ErrorNarration { get; set; }
    public bool IsValid { get; set; }
    public bool IsRefreshValid { get; set; }
    public ICollectionView Plots { get; set; }
    public ICollectionView Spaces { get; set; }
    public ICollectionView Tenants { get; set; }
    public ICollectionView ControlHeads { get; set; }
    public ICollectionView Heads { get; set; }
    public Action Delete { get; set; }
    public Action Refresh { get; set; }
    public Action<SelectQuery, string> FilterCommand { get; set; }

    public EditTransactionVM() : base() {
        transactions = new ObservableCollection<Transaction>();
        plots = new ObservableCollection<Lease>();
        spaces = new ObservableCollection<Lease>();
        tenants = new CollectionViewSource() { Source = AppData.tenants };
        heads = new CollectionViewSource() { Source = AppData.heads };
        controlHeads = new CollectionViewSource() { Source = AppData.controlHeads };
        editables = new CollectionViewSource() {
            Source = transactions,
            IsLiveFilteringRequested = true,
            IsLiveGroupingRequested = true,
            LiveFilteringProperties = { nameof(Transaction.Date) },
            LiveGroupingProperties = { nameof(Transaction.PlotId) }
        };
        ControlHeads = controlHeads.View;
        Tenants = tenants.View;
        Heads = heads.View;
        Editables = editables.View;

        Plots = CollectionViewSource.GetDefaultView(plots);
        Spaces = CollectionViewSource.GetDefaultView(spaces);
        Editables.GroupDescriptions.Add(new PropertyGroupDescription(nameof(Transaction.PlotId)));
        Editables.Filter = filterTransactions;

        Tenants.Filter = filterTenants;
        ControlHeads.Filter = filterControlHeads;
        Plots.Filter = filterPlots;
        Spaces.Filter = filterSpaces;
        Heads.Filter = filterHeads;
        TransactionDate = DateTime.Today;
        Refresh = getTransactions;
        Delete = delete;
        FilterCommand = filterCommand;

        ((App)Application.Current).appData.PlotEdited += onPlotNameChanged;
        ((App)Application.Current).appData.TenantEdited += onTenantNameChanged;
        ((App)Application.Current).appData.TransactionEdited += onTransactionEdited;
        ((App)Application.Current).appData.TransactionDeleted += onTransactionDeleted;
    }

    void onTransactionDeleted(NetTransaction t) {
        if (TransactionDate.HasValue) {
            if (!TransactionDate.Value.ToString("yyyy-MM-dd").Equals(t.Date)) return;
            var tr = transactions.FirstOrDefault(x => x.Id == t.Id);
            if(tr is not null) {
                transactions.Remove(tr);
            }
        }
    }

    void onTransactionEdited(NetTransaction t) {
        if (TransactionDate.HasValue) {
            if (!TransactionDate.Value.ToString("yyyy-MM-dd").Equals(t.Date)) return;
            var tr = transactions.FirstOrDefault(x => x.Id == t.Id);
            if (tr is not null) {
                tr.PlotId = t.PlotId;
                tr.SpaceId = t.SpaceId;
                tr.TenantId = t.TenantId;
                tr.ControlId = t.ControlId;
                tr.HeadId = t.HeadId;
                tr.IsCash = t.IsCash;
                tr.Amount = t.Amount;
                tr.Narration = t.Narration;
                tr.TenantName = AppData.tenants.First(x => x.Id == t.TenantId).Name;
            }
        }
    }
    void filterCommand(SelectQuery parameter, string query) {
        switch (parameter) {
            case SelectQuery.Plot: PlotQuery = query; Plots.Refresh(); break;
            case SelectQuery.Space: SpaceQuery = query; Spaces.Refresh(); break;
            case SelectQuery.Tenant: TenantQuery = query; Tenants.Refresh(); break;
            case SelectQuery.ControlHead: ControlQuery = query; ControlHeads.Refresh(); break;
            case SelectQuery.Head: HeadQuery = query; Heads.Refresh(); break;
        }
    }
    void onPlotNameChanged(Plot p) {
        if (transactions == null || transactions.Count == 0) return;
        foreach (var item in transactions) {
            if (item.PlotId == p.Id) {
                //item.PlotId = p.Id;
                //item.OnPropertyChanged(string.Empty);
                item.OnPropertyChanged(nameof(Transaction.PlotId));
            }
        }
    }
    void onTenantNameChanged(Tenant t) {
        if (transactions == null || transactions.Count == 0) return;
        foreach (var item in transactions) {
            if (item.TenantId == t.Id) {
                item.TenantName = t.Name;
                item.OnPropertyChanged(nameof(Transaction.TenantName));
            }
        }
    }

    async void getTransactions() {
        transactions.Clear();
        var request = new RentManagerRequest() {
            UserId = App.service.UserId,
            Method = (int)Function.GetTransactions,
            Args = new object[] { TransactionDate.Value.ToString("yyyy-MM-dd") }
        };
        Status = "requesting data";
        var response = await App.service.GetResponse(request);
        await Task.Delay(500);
        if (!response.IsSuccess) {
            InfoWindow.Activate("Service", "Couldn't connect to service, try restrating the Application");
            return;
        }
        if (response.Packet.Length == 0) {
            Status = "no data available";
            return;
        }
        Status = $"received {response.Packet.Length.ToString("N0")} bytes";
        await Task.Delay(500);
        await addTransactions(response.Packet);
    }
    Task addTransactions(byte[] packet) {
        int read = 0;
        int start = 0;
        var span = new ReadOnlySpan<byte>(packet);
        while (read < span.Length) {
            var transaction = new Transaction() {
                Id = BitConverter.ToInt32(span.Slice(start, 4)),
                PlotId = BitConverter.ToInt32(span.Slice(start + 4, 4)),
                SpaceId = BitConverter.ToInt32(span.Slice(start + 8, 4)),
                TenantId = BitConverter.ToInt32(span.Slice(start + 12, 4)),
                ControlId = BitConverter.ToInt32(span.Slice(start + 16, 4)),
                HeadId = BitConverter.ToInt32(span.Slice(start + 20, 4)),
                Amount = BitConverter.ToInt32(span.Slice(start + 24, 4)),
                IsCash = span.Slice(start + 28, 1)[0]
            };
            read += 29;
            start += 29;
            while (span[read] != 0) read++;
            var date = Encoding.ASCII.GetString(span.Slice(start, read - start));
            transaction.Date = DateTime.ParseExact(date, "yyyy-MM-dd", CultureInfo.CurrentCulture.DateTimeFormat);

            start = ++read;
            while (span[read] != 0) read++;
            transaction.Narration = Encoding.ASCII.GetString(span.Slice(start, read - start));
            transaction.TenantName = AppData.tenants.First(x => x.Id == transaction.TenantId).Name;
            transactions.Add(transaction);
            start = ++read;
        }
        return Task.CompletedTask;
    }
    void setPlotsAndSpaces() {
        plots.Clear();
        spaces.Clear();
        for (int i = 0; i < AppData.leases.Count; i++) {
            if (AppData.leases[i].TenantId == Edited.TenantId) {
                var lease = AppData.leases[i];
                bool containedInPlots = false;
                for (int j = 0; j < plots.Count; j++) {
                    if (plots[j].PlotId == lease.PlotId) {
                        containedInPlots = true;
                        break;
                    }
                }
                if (!containedInPlots) plots.Add(lease);
                spaces.Add(lease);
            }
        }
    }
    async void delete() {
        var message = AppData.controlHeads.First(x => x.Id == Selected.ControlId).Name + " : " +
                      AppData.heads.First(x => x.Id == Selected.HeadId).Name + " amounting " + Selected.Amount.ToString("N0") +
                      "\r\nfrom " + AppData.tenants.First(x => x.Id == Selected.TenantId).Name +
                      "\r\non " + Selected.Date.Value.ToString("dd MMMM, yyyy") + " will be deleted permanently";

        ConfirmDialog.Activate("Transaction", message);
        if (ConfirmDialog.IsOk) {
            var request = new RentManagerRequest() {
                UserId = App.service.UserId,
                Method = (int)Function.DeleteTransaction,
                Args = new object[] {
                    new NetTransaction() {
                        Id = Selected.Id,
                        PlotId = Selected.PlotId.Value,
                        SpaceId = Selected.SpaceId.Value,
                        TenantId = Selected.TenantId.Value,
                        ControlId = Selected.ControlId.Value,
                        HeadId = Selected.HeadId.Value,
                        Date = Selected.Date.Value.ToString("yyyy-MM-dd"),
                        Amount = Selected.Amount,
                        IsCash = Selected.IsCash,
                        Narration = Selected.Narration
                    }
                }
            };
            var response = await App.service.GetResponse(request); // real response will be handled by Receiver
            handleResponse(response, "Transaction");
        }
    }

    #region validation rules
    void validateTenantId() {
        setPlotsAndSpaces();
        ErrorTenantId = string.Empty;
        if (Edited.TenantId == null)
            ErrorTenantId = " is required";
        OnPropertyChanged(nameof(ErrorTenantId));
    }
    void validatePlotId() {
        ErrorPlotId = string.Empty;
        if (Edited.PlotId == null)
            ErrorPlotId = " is required";
        OnPropertyChanged(nameof(ErrorPlotId));
        Spaces.Refresh();
        Edited.SpaceId = (Spaces.CurrentItem as Lease)?.SpaceId;
    }
    void validateSpaceId() {
        ErrorSpaceId = string.Empty;
        if (Edited.SpaceId == null)
            ErrorSpaceId = " is required";
        OnPropertyChanged(nameof(ErrorSpaceId));
    }
    void validateControlId() {
        ErrorControlId = string.Empty;
        if (Edited.ControlId == null)
            ErrorControlId = " is required";
        OnPropertyChanged(nameof(ErrorControlId));
        Heads.Refresh();
        Edited.IsCash = Edited.ControlId == AppData.controlIdOfReceivable ? (byte)1 : Edited.IsCash;
        Edited.HeadId = (Heads.CurrentItem as Head)?.Id;
    }
    void validateHeadId() {
        ErrorHeadId = string.Empty;
        if (Edited.HeadId == null)
            ErrorHeadId = " is required";
        OnPropertyChanged(nameof(ErrorHeadId));
    }
    void validateDate() {
        ErrorDate = string.Empty;
        if (Edited.Date == null)
            ErrorDate = " is required";
        OnPropertyChanged(nameof(ErrorDate));
    }
    void validateAmount() {
        ErrorAmount = string.Empty;
        if (string.IsNullOrWhiteSpace(Amount))
            ErrorAmount = "Amount in required";
        else {
            int x;
            if (int.TryParse(Amount, out x)) {
                if (x > 0) {
                    Edited.Amount = x;
                    ErrorAmount = string.Empty;
                }
                else ErrorAmount = "Positive integers only";
            }
            else ErrorAmount = "Integer only";
        }
        OnPropertyChanged(nameof(ErrorAmount));
        checkValidity();
    }
    void validateNarration() {
        ErrorNarration = string.Empty;
        if (string.IsNullOrWhiteSpace(Edited.Narration))
            ErrorNarration = "Narration is required";
        OnPropertyChanged(nameof(ErrorNarration));
    }
    bool isBothEqual() {
        return
            Selected.TenantId == Edited.TenantId &&
            Selected.PlotId == Edited.PlotId &&
            Selected.SpaceId == Edited.SpaceId &&
            Selected.ControlId == Edited.ControlId &&
            Selected.HeadId == Edited.HeadId &&
            Nullable.Compare(Selected.Date, Edited.Date) == 0 &&
            Selected.Amount == Edited.Amount &&
            Selected.IsCash == Edited.IsCash &&
            string.Equals(Selected.Narration, Edited.Narration, StringComparison.OrdinalIgnoreCase);
    }
    void checkValidity() {
        isEqual = isBothEqual();
        IsValid =
            !isEqual &&
            ErrorTenantId == string.Empty &&
            ErrorPlotId == string.Empty &&
            ErrorSpaceId == string.Empty &&
            ErrorControlId == string.Empty &&
            ErrorHeadId == string.Empty &&
            ErrorDate == string.Empty &&
            ErrorAmount == string.Empty &&
            ErrorNarration == string.Empty;
        OnPropertyChanged(nameof(IsValid));
    }
    #endregion

    #region filters
    bool filterTenants(object o) {
        if (string.IsNullOrWhiteSpace(TenantQuery)) return true;
        return ((Tenant)o).Name.ToLower().Contains(TenantQuery);
    }
    bool filterPlots(object o) {
        if (string.IsNullOrWhiteSpace(PlotQuery)) return true;
        return ((Lease)o).PlotName.ToLower().Contains(PlotQuery);
    }
    bool filterSpaces(object o) {
        var lease = (Lease)o;
        var result = lease.PlotId == Edited.PlotId;
        if (string.IsNullOrWhiteSpace(SpaceQuery)) return result;
        return result && lease.SpaceName.ToLower().Contains(SpaceQuery);
    }
    bool filterControlHeads(object o) {
        if (string.IsNullOrWhiteSpace(ControlQuery)) return true;
        return ((ControlHead)o).Name.ToLower().Contains(ControlQuery);
    }
    bool filterHeads(object o) {
        if (Edited == null) return false;
        var head = (Head)o;
        var result = head.ControlId == Edited.ControlId;
        if (string.IsNullOrWhiteSpace(HeadQuery)) return result;
        return result && head.Name.ToLower().Contains(HeadQuery);
    }
    bool filterTransactions(object o) {
        var transaction = (Transaction)o;
        var result = transaction.Date == TransactionDate;
        if (string.IsNullOrWhiteSpace(FilterName)) return result;
        return result && transaction.TenantName.ToLower().Contains(FilterName);
    }
    #endregion

    #region base implementation
    protected override void setStatesOnClone() {
        setPlotsAndSpaces();
        Edited.PlotId = Selected.PlotId;
        Spaces.Refresh();
        Edited.SpaceId = Selected.SpaceId;
        Amount = Edited.Amount.ToString();
    }
    protected override Transaction clone() {
        return new Transaction() {
            Id = Selected.Id,
            PlotId = Selected.PlotId,
            SpaceId = Selected.SpaceId,
            TenantId = Selected.TenantId,
            ControlId = Selected.ControlId,
            HeadId = Selected.HeadId,
            Narration = Selected.Narration,
            IsCash = Selected.IsCash,
            Date = Selected.Date,
            Amount = Selected.Amount
        };
    }
    protected override void validate(object sender, PropertyChangedEventArgs e) {
        switch (e.PropertyName) {
            case nameof(Transaction.TenantId): validateTenantId(); break;
            case nameof(Transaction.PlotId): validatePlotId(); break;
            case nameof(Transaction.SpaceId): validateSpaceId(); break;
            case nameof(Transaction.ControlId): validateControlId(); break;
            case nameof(Transaction.HeadId): validateHeadId(); break;
            case nameof(Transaction.Date): validateDate(); break;
            case nameof(Transaction.Amount): validateAmount(); break;
            case nameof(Transaction.Narration): validateNarration(); break;
        }
        checkValidity();
    }
    protected override void setValidationProperties() {
        isEqual = true;
        IsValid = false;
        ErrorTenantId =
        ErrorPlotId =
        ErrorSpaceId =
        ErrorControlId =
        ErrorHeadId =
        ErrorDate =
        ErrorAmount =
        ErrorNarration = string.Empty;
        OnPropertyChanged(nameof(ErrorTenantId));
        OnPropertyChanged(nameof(ErrorPlotId));
        OnPropertyChanged(nameof(ErrorSpaceId));
        OnPropertyChanged(nameof(ErrorControlId));
        OnPropertyChanged(nameof(ErrorHeadId));
        OnPropertyChanged(nameof(ErrorDate));
        OnPropertyChanged(nameof(ErrorAmount));
        OnPropertyChanged(nameof(ErrorNarration));
        OnPropertyChanged(nameof(IsValid));
    }
    protected override async void save() {
        var request = new RentManagerRequest() {
            UserId = App.service.UserId,
            Method = (int)Function.EditTransaction,
            Args = new object[] {
                new NetTransaction() {
                    Id = Edited.Id,
                    PlotId = Edited.PlotId.Value,
                    SpaceId = Edited.SpaceId.Value,
                    TenantId = Edited.TenantId.Value,
                    ControlId = Edited.ControlId.Value,
                    HeadId = Edited.HeadId.Value,
                    Date = Edited.Date.Value.ToString("yyyy-MM-dd"),
                    Amount = Edited.Amount,
                    IsCash = Edited.IsCash,
                    Narration = Edited.Narration
                }
            }
        };
        var response = await App.service.GetResponse(request); // real response will be handled by Receiver
        handleResponse(response, "Transaction");
    }
    #endregion
}
