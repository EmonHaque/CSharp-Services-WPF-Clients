﻿class CurrentMonthTemplate : DataTemplate
{
    public CurrentMonthTemplate() {
        var grid = new FrameworkElementFactory(typeof(Grid));
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col3 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col4 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col5 = new FrameworkElementFactory(typeof(ColumnDefinition));

        var name = new FrameworkElementFactory(typeof(TextBlock));
        var date = new FrameworkElementFactory(typeof(TextBlock));
        var due = new FrameworkElementFactory(typeof(TextBlock));
        var lastDue = new FrameworkElementFactory(typeof(TextBlock));
        var payment = new FrameworkElementFactory(typeof(TextBlock));

        date.SetValue(Grid.ColumnProperty, 1);
        due.SetValue(Grid.ColumnProperty, 2);
        lastDue.SetValue(Grid.ColumnProperty, 3);
        payment.SetValue(Grid.ColumnProperty, 4);

        col2.SetValue(ColumnDefinition.WidthProperty, new GridLength(80d));
        col3.SetValue(ColumnDefinition.WidthProperty, new GridLength(70d));
        col4.SetValue(ColumnDefinition.WidthProperty, new GridLength(70d));
        col5.SetValue(ColumnDefinition.WidthProperty, new GridLength(70d));

        date.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Center);
        due.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
        lastDue.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);
        payment.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Right);

        date.SetBinding(TextBlock.TextProperty, new Binding(nameof(MonthlyBalance.Date)) { StringFormat = "dd MMM yyy" });
        name.SetBinding(TextBlock.TextProperty, new Binding(nameof(MonthlyBalance.Tenant)));
        due.SetBinding(TextBlock.TextProperty, new Binding(nameof(MonthlyBalance.Due)) { StringFormat = Constants.NumberFormat });
        lastDue.SetBinding(TextBlock.TextProperty, new Binding(nameof(MonthlyBalance.LastMonthDue)) { StringFormat = Constants.NumberFormat });
        payment.SetBinding(TextBlock.TextProperty, new Binding(nameof(MonthlyBalance.Payment)) { StringFormat = Constants.NumberFormat });

        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(col3);
        grid.AppendChild(col4);
        grid.AppendChild(col5);
        grid.AppendChild(date);
        grid.AppendChild(name);
        grid.AppendChild(due);
        grid.AppendChild(lastDue);
        grid.AppendChild(payment);
        VisualTree = grid;
    }
}
