﻿class BulkRentTransaction : CardView
{
    public override string Header => "Rent";
    MonthPicker month;
    CommandButton button;
    TextBlock text, count;
    Run selected, slash, total, excluded;
    ListBox leaseList;
    EditText search;
    BulkRentTransactionVM viewModel;

    public override void OnFirstSight() {
        base.OnFirstSight();
        viewModel = new BulkRentTransactionVM();
        DataContext = viewModel;
        initializeUI();
        bind();
        total.Text = leaseList.Items.Count.ToString("N0");
        leaseList.SelectionChanged += onSelectionChanged;
        ((ICollectionView)leaseList.ItemsSource).CollectionChanged += onCollectionChanged;
        Unloaded += onUnloaded;
    }
    void onCollectionChanged(object sender, NotifyCollectionChangedEventArgs e) {
        total.Text = leaseList.Items.Count.ToString("N0");
    }
    void onUnloaded(object sender, RoutedEventArgs e) {
        leaseList.SelectionChanged -= onSelectionChanged;
        ((ICollectionView)leaseList.ItemsSource).CollectionChanged -= onCollectionChanged;
        Unloaded -= onUnloaded;
    }
    void onSelectionChanged(object sender, SelectionChangedEventArgs e) {
        viewModel.ExcludedLeases = leaseList.SelectedItems.Cast<Lease>().ToList();
        selected.Text = viewModel.ExcludedLeases.Count.ToString("N0");
    }
    void initializeUI() {
        month = new MonthPicker() {
            Hint = "Month",
            MonthFormat = "MM/yyyy",
            IsRequired = true,
            Margin = new Thickness(5, 10, 5, 5)
        };
        search = new EditText() {
            Icon = Icons.Search,
            Hint = "Search",
            IsTrimBottomRequested = true
        };
        text = new TextBlock() {
            Text = "Select to exclude:",
            FontWeight = FontWeights.Bold
        };
        selected = new Run() { Text = "0" };
        slash = new Run() { Text = "/" };
        total = new Run();
        excluded = new Run() { Text = " excluded" };
        count = new TextBlock() {
            FontStyle = FontStyles.Italic,
            HorizontalAlignment = HorizontalAlignment.Right,
            Inlines = { selected, slash, total, excluded }
        };
        leaseList = new ListBox() {
            Margin = new Thickness(0, 5, 0, 5),
            BorderThickness = new Thickness(0, 1, 0, 1),
            Padding = new Thickness(0, 2, 0, 2),
            SelectionMode = SelectionMode.Extended,
            ItemTemplate = new LeaseTemplate(nameof(viewModel.FilterName), viewModel, false),
            ItemContainerStyle = new Style(typeof(ListBoxItem)) {
                Setters = {
                    new Setter(ListBoxItem.TemplateProperty, new ListBoxItemTemplate()),
                    new Setter(ListBoxItem.FocusVisualStyleProperty, null),
                    new Setter(ListBoxItem.ToolTipProperty, new LeaseTip())
                }
            },
            GroupStyle = {
                new GroupStyle() {
                    ContainerStyle = new Style(typeof(GroupItem)) {
                        Setters = {
                            new Setter(GroupItem.TemplateProperty, new GroupedLeaseTemplate(nameof(viewModel.FilterName), viewModel))
                        }
                    }
                }
            },
            Resources = {{
                    typeof(ScrollViewer),
                    new Style() {
                        Setters = {
                            new Setter(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled),
                            new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate(false)),
                        }
                    }
                }
            }
        };
        button = new CommandButton() {
            Width = 16,
            Height = 16,
            Icon = Icons.Add,
            Command = viewModel.PassEntries,
            HorizontalAlignment = HorizontalAlignment.Right
        };
        Grid.SetRow(search, 1);
        Grid.SetRow(text, 2);
        Grid.SetRow(count, 2);
        Grid.SetRow(leaseList, 3);
        Grid.SetRow(button, 4);
        var grid = new Grid() {
            Margin = new Thickness(0, 5, 0, 0),
            RowDefinitions = {
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(),
                    new RowDefinition(){ Height = GridLength.Auto }
                },
            Children = { month, search, text, count, leaseList, button }
        };
        setContent(grid);
    }
    void bind() {
        month.SetBinding(MonthPicker.SelectedDateProperty, new Binding(nameof(viewModel.Month)));
        month.SetBinding(MonthPicker.ErrorProperty, new Binding(nameof(viewModel.ErrorMonth)));
        leaseList.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(viewModel.Leases)));
        button.SetBinding(IsEnabledProperty, new Binding(nameof(viewModel.IsValid)));
        search.SetBinding(EditText.TextProperty, new Binding(nameof(viewModel.FilterName)) { Mode = BindingMode.OneWayToSource });
    }
}
