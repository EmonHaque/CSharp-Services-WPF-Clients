﻿class App : Application
{
    const string appExeName = "RentManager";
    const string appVersion = "1.0";
    public static ServicePack service;
    public AppData appData;

    [STAThread]
    static void Main(string[] args) {
#if DEBUG 
        new App().Run();
#else
        if (args.Length == 0) {
            var lArg = new LaunchArgs() {
                App = appExeName,
                Version = appVersion,
                Path = AppDomain.CurrentDomain.BaseDirectory
            };
            var launchArg = $"\"{lArg.App},{lArg.Version},{lArg.Path}\"";
            var launcherPath = System.IO.Path.GetFullPath(System.IO.Path.Combine(lArg.Path, @"..\"));
            Process.Start(launcherPath + "\\Launcher.exe", launchArg);
        }
        else new App().Run();
#endif        
    }
    protected override void OnStartup(StartupEventArgs e) {
        SetStyle();
        Constants.AppTitle = "Rent Manager";
        service = new ServicePack() {
            Address = IPAddress.Parse(Addresses.RentManagerAddress),
            Port = Addresses.RentManagerPort
        };
#if DEBUG
        service.Receiver = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        service.Sender = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        bool isConnected = false;
        try {
            service.Receiver.Connect(service.Address, service.Port);
            service.Receiver.Send(BitConverter.GetBytes(true));

            service.Sender.Connect(service.Address, service.Port);
            service.Sender.Send(BitConverter.GetBytes(false));

            var request = new RentManagerRequest() {
                UserId = service.UserId,
                Method = (int)Function.GetInitialData,
                Args = new object[] { "" }
            };
            var bytes = request.GetBytes();
            service.Sender.Send(bytes);
        }
        catch { isConnected = false; }

        var loading = new LoadingWindow();
        appData = new AppData(loading);
        appData.Received += onInitialLoadComplete;
        loading.Show();
#else
        var login = new LoginWindow(Constants.AppTitle, service);
        login.LoggedIn += onLoggedIn;
        login.Show();
#endif
    }

    void onLoggedIn(LoginWindow dow, Socket socket) {
        service.Signatory = socket;
        dow.LoggedIn -= onLoggedIn;
        dow.InService += onInService;
    }
    void onInService(LoginWindow dow) {
        dow.InService -= onInService;
        service.Sender = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        service.Sender.Connect(service.Address, service.Port);
        service.Sender.Send(BitConverter.GetBytes(false));
        var request = new RentManagerRequest() {
            UserId = service.UserId,
            Method = (int)Function.GetInitialData,
            Args = new object[] { "" }
        };
        service.Sender.Send(request.GetBytes());

        var loading = new LoadingWindow();
        appData = new AppData(loading);
        appData.Received += onInitialLoadComplete;
        loading.Show();
        dow.Close();
    }
    void onInitialLoadComplete(LoadingWindow dow) {
        appData.Received -= onInitialLoadComplete;
        new Converters();
        App.Current.MainWindow = new RootWindow() {
            Content = new RootPanel() {
                Children = {
                    new HomeView(),
                    new AddView(),
                    new EditView(),
                    new TransactionView(),
                    new ReportView()
                }
            }
        };
        App.Current.MainWindow.Show();
        dow.Close();
    }
    void SetStyle() {
        Current.Resources.Add(SystemParameters.VerticalScrollBarWidthKey, Constants.ScrollBarThickness);
        Current.Resources.Add(SystemParameters.HorizontalScrollBarHeightKey, Constants.ScrollBarThickness);

        Control.StyleProperty.OverrideMetadata(typeof(ScrollBar), new FrameworkPropertyMetadata() {
            DefaultValue = new Style() {
                Setters = { new Setter(ScrollBar.TemplateProperty, new VScrollTemplate()) },
                Triggers = {
                    new Trigger() {
                        Property = ScrollBar.OrientationProperty,
                        Value = Orientation.Horizontal,
                        Setters = { new Setter(ScrollBar.TemplateProperty, new HScrollTemplate()) }
                    }
                }
            }
        });
        ListBoxItem.StyleProperty.OverrideMetadata(typeof(ListBox), new FrameworkPropertyMetadata() {
            DefaultValue = new Style() {
                Setters = {
                    new Setter(ListBox.TemplateProperty, new ListBoxTemplate()),
                    new Setter(ListBox.BorderThicknessProperty, new Thickness(0)),
                    new Setter(ListBox.HorizontalContentAlignmentProperty, HorizontalAlignment.Stretch),
                    new Setter(ListBox.IsSynchronizedWithCurrentItemProperty, true),
                    new Setter(TextElement.ForegroundProperty, Brushes.LightGray)
                }
            }
        });
        ListBoxItem.StyleProperty.OverrideMetadata(typeof(ListBoxItem), new FrameworkPropertyMetadata() {
            DefaultValue = new Style() {
                Setters = {
                    new Setter(ListBoxItem.TemplateProperty, new ListBoxItemTemplate()),
                    new Setter(ListBoxItem.FocusVisualStyleProperty, null)
                }
            }
        });
        Separator.StyleProperty.OverrideMetadata(typeof(Separator), new FrameworkPropertyMetadata() {
            DefaultValue = new Style() {
                Setters = {
                    new Setter(Separator.BorderThicknessProperty, new Thickness(0.1))
                }
            }
        });
        ToolTip.StyleProperty.OverrideMetadata(typeof(ToolTip), new FrameworkPropertyMetadata() {
            DefaultValue = new Style() {
                Setters = {
                    new Setter(ToolTip.TemplateProperty, new ToolTipTemplate()),
                    new Setter(ToolTip.HorizontalOffsetProperty, 10d),
                    new Setter(ToolTip.VerticalOffsetProperty, 10d),
                }
            }
        });
        Control.StyleProperty.OverrideMetadata(typeof(Control), new FrameworkPropertyMetadata() {
            DefaultValue = new Style() {
                Setters = {
                    new Setter(MenuItem.BorderThicknessProperty, new Thickness(0)),
                    new Setter(MenuItem.PaddingProperty, new Thickness(0)),
                    new Setter(Control.BackgroundProperty, Constants.Background),
                    new Setter(Control.ForegroundProperty, Brushes.LightGray)
                }
            }
        });
    }
}
