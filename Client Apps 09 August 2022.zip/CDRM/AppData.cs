﻿class AppData
{
    int byteCount = 0;
    bool isConnected;
    BlockingCollection<byte[]> messages;
    LoadingWindow window;
    Dispatcher patch;
    ServicePack service;

    static Site theSite;
    static Party theParty;
    static Head theHead;
    static SubHead theSubHead;
    static Unit theUnit;
    static NoteType theNoteType;

    public static ObservableCollection<Site> sites = new();
    public static ObservableCollection<Party> parties = new();
    public static ObservableCollection<Head> heads = new();
    public static ObservableCollection<SubHead> subHeads = new();
    public static ObservableCollection<Unit> units = new();
    public static ObservableCollection<NoteType> noteTypes = new();

    public event Action<LoadingWindow> Received;
    public event Action<NetNote> NoteAdded, NoteEdited;
    public event Action<int> NoteDeleted;

    public AppData(LoadingWindow window, ServicePack service) {
        this.window = window;
        this.service = service;
        patch = App.Current.Dispatcher;
        window.Activated += onActivated;
    }
    
    async void onActivated(object? sender, EventArgs e) {
        window.Text = "initializing";
        await Task.Delay(2000);
        new Thread(populateCollections) { IsBackground = true }.Start();
    }
    void populateCollections() {
        patch.Invoke(() => { window.Text = "receiving packet"; });
        Thread.Sleep(250);

        ReadOnlySpan<byte> siteSpan, partySpan, headSpan, subHeadSpan, unitSpan, noteTypeSpan;
        try {
            siteSpan = new ReadOnlySpan<byte>(getPacket());
            partySpan = new ReadOnlySpan<byte>(getPacket());
            headSpan = new ReadOnlySpan<byte>(getPacket());
            subHeadSpan = new ReadOnlySpan<byte>(getPacket());
            unitSpan = new ReadOnlySpan<byte>(getPacket());
            noteTypeSpan = new ReadOnlySpan<byte>(getPacket());
        }
        catch {
            patch.Invoke(() => { window.Text = "service down"; });
            Thread.Sleep(2000);
            patch.Invoke(() => { window.Text = "quitting"; });
            Thread.Sleep(2000);
            patch.Invoke(() => {
                window.Close();
                App.Current.Shutdown();
            });
            return;
        }
        patch.Invoke(() => { window.Text = "here"; });
        int read, start;
        read = start = 0;

        patch.Invoke(() => { window.Text = "listing sites"; });
        Thread.Sleep(250);
        #region Site
        while (read < siteSpan.Length) {
            var id = BitConverter.ToInt32(siteSpan.Slice(start, 4));
            read += 4;
            start = read;
            while (siteSpan[read] != 0) read++;
            var name = Encoding.ASCII.GetString(siteSpan.Slice(start, read - start));

            start = ++read;
            while (siteSpan[read] != 0) read++;
            var address = Encoding.ASCII.GetString(siteSpan.Slice(start, read - start));

            patch.Invoke(() => {
                sites.Add(new Site() {
                    Id = id,
                    Name = name,
                    Address = address
                });
            });
            start = ++read;
        }
        #endregion

        read = start = 0;
        patch.Invoke(() => { window.Text = "listing parties"; });
        Thread.Sleep(250);
        #region Party
        while (read < partySpan.Length) {
            var id = BitConverter.ToInt32(partySpan.Slice(start, 4));
            read += 4;
            start = read;
            while (partySpan[read] != 0) read++;
            var name = Encoding.ASCII.GetString(partySpan.Slice(start, read - start));

            start = ++read;
            while (partySpan[read] != 0) read++;
            var address = Encoding.ASCII.GetString(partySpan.Slice(start, read - start));

            start = ++read;
            while (partySpan[read] != 0) read++;
            var phone = Encoding.ASCII.GetString(partySpan.Slice(start, read - start));

            patch.Invoke(() => {
                parties.Add(new Party() {
                    Id = id,
                    Name = name,
                    Address = address,
                    Phone = phone
                });
            });
            start = ++read;
        }
        #endregion

        read = start = 0;
        patch.Invoke(() => { window.Text = "listing heads"; });
        Thread.Sleep(250);
        #region Head
        while (read < headSpan.Length) {
            var id = BitConverter.ToInt32(headSpan.Slice(start, 4));
            read += 4;
            start = read;
            while (headSpan[read] != 0) read++;
            var name = Encoding.ASCII.GetString(headSpan.Slice(start, read - start));

            patch.Invoke(() => {
                heads.Add(new Head() {
                    Id = id,
                    Name = name
                });
            });
            start = ++read;
        }
        #endregion

        read = start = 0;
        patch.Invoke(() => { window.Text = "listing subheads"; });
        Thread.Sleep(250);
        #region SubHead
        while (read < subHeadSpan.Length) {
            var id = BitConverter.ToInt32(subHeadSpan.Slice(start, 4));
            read += 4;
            start = read;
            while (subHeadSpan[read] != 0) read++;
            var name = Encoding.ASCII.GetString(subHeadSpan.Slice(start, read - start));

            patch.Invoke(() => {
                subHeads.Add(new SubHead() {
                    Id = id,
                    Name = name
                });
            });
            start = ++read;
        }
        #endregion

        read = start = 0;
        patch.Invoke(() => { window.Text = "listing units"; });
        Thread.Sleep(250);
        #region Unit
        while (read < unitSpan.Length) {
            var id = BitConverter.ToInt32(unitSpan.Slice(start, 4));
            read += 4;
            start = read;
            while (unitSpan[read] != 0) read++;
            var name = Encoding.ASCII.GetString(unitSpan.Slice(start, read - start));

            patch.Invoke(() => {
                units.Add(new Unit() {
                    Id = id,
                    Name = name
                });
            });
            start = ++read;
        }
        #endregion

        read = start = 0;
        patch.Invoke(() => { window.Text = "listing note types"; });
        Thread.Sleep(250);
        #region NoteType
        while (read < noteTypeSpan.Length) {
            var id = BitConverter.ToInt32(noteTypeSpan.Slice(start, 4));
            read += 4;
            start = read;
            while (noteTypeSpan[read] != 0) read++;
            var name = Encoding.ASCII.GetString(noteTypeSpan.Slice(start, read - start));

            patch.Invoke(() => {
                noteTypes.Add(new NoteType() {
                    Id = id,
                    Name = name
                });
            });
            start = ++read;
        }
        #endregion

        window.Activated -= onActivated;
        patch.Invoke(() => { window.Text = "launching ..."; });
        Thread.Sleep(1000);
        patch.Invoke(() => Received?.Invoke(window));

        isConnected = true;
        messages = new BlockingCollection<byte[]>();
        new Thread(receiveBroadcast) { IsBackground = true }.Start();
        new Thread(processMessage) { IsBackground = true }.Start();
    }
    byte[] getPacket() {
        var header = new byte[4];
        int read = service.Sender.Receive(header);
        while (read < header.Length) {
            read += service.Sender.Receive(header, read, header.Length - read, SocketFlags.None);
        }
        var size = BitConverter.ToInt32(header);
        if (size == 0) return new byte[0];

        var packet = new byte[size];
        read = service.Sender.Receive(packet);
        while (read < packet.Length) {
            read += service.Sender.Receive(packet, read, packet.Length - read, SocketFlags.None);
        }
        byteCount += packet.Length;
        patch.Invoke(() => {
            window.Text = $"{byteCount.ToString("N0")} bytes received";
        });
        Thread.Sleep(250);
        return packet;
    }
    void receiveBroadcast() {
        var header = new byte[4];
        while (isConnected) {
            try {
                int read = service.Receiver.Receive(header);
                while (read < header.Length) {
                    read += service.Receiver.Receive(header, read, header.Length - read, SocketFlags.None);
                }
                var size = BitConverter.ToInt32(header);
                var packet = new byte[size];
                read = service.Receiver.Receive(packet);
                while (read < packet.Length) {
                    read += service.Receiver.Receive(packet, read, packet.Length - read, SocketFlags.None);
                }
                messages.Add(packet);
            }
            catch {
                isConnected = false;
                //show some message and new up socket and reconnect
            }
        }
    }
    void processMessage() {
        while (isConnected) {
            var packet = new ReadOnlySpan<byte>(messages.Take());
            var message = (Function)BitConverter.ToInt32(packet.Slice(0, 4));
            var slice = packet.Slice(4);
            switch (message) {
                case Function.AddSite: addSite(slice); break;
                case Function.AddParty: addParty(slice); break;
                case Function.AddHead: addHead(slice); break;
                case Function.AddSubHead: addSubHead(slice); break;
                case Function.AddUnit: addUnit(slice); break;
                case Function.AddNoteType: addNoteType(slice); break;
                case Function.AddNote: addNote(slice); break;

                case Function.EditSite: editSite(slice); break;
                case Function.EditParty: editParty(slice); break;
                case Function.EditHead: editHead(slice); break;
                case Function.EditSubHead: editSubHead(slice); break;
                case Function.EditUnit: editUnit(slice); break;
                case Function.EditNote: editNote(slice); break;
                case Function.DeleteNote: deleteNote(slice); break;
            }
        }
    }

    void addSite(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var nSite = NetSite.FromBytes(array.Slice(4));
        patch.Invoke(() => {
            sites.Add(new Site() {
                Id = nSite.Id,
                Name = nSite.Name,
                Address = nSite.Address
            });
        });
    }
    void addParty(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var nParty = NetParty.FromBytes(array.Slice(4));
        patch.Invoke(() => {
            parties.Add(new Party() {
                Id = nParty.Id,
                Name = nParty.Name,
                Address = nParty.Address,
                Phone = nParty.Phone
            });
        });
    }
    void addHead(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var nHead = NetHead.FromBytes(array.Slice(4));
        patch.Invoke(() => {
            heads.Add(new Head() {
                Id = nHead.Id,
                Name = nHead.Name
            });
        });
    }
    void addSubHead(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var nSubHead = NetSubHead.FromBytes(array.Slice(4));
        patch.Invoke(() => {
            subHeads.Add(new SubHead() {
                Id = nSubHead.Id,
                Name = nSubHead.Name
            });
        });
    }
    void addUnit(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var nUnit = NetUnit.FromBytes(array.Slice(4));
        patch.Invoke(() => {
            units.Add(new Unit() {
                Id = nUnit.Id,
                Name = nUnit.Name
            });
        });
    }
    void addNoteType(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var nType = NetNoteType.FromBytes(array.Slice(4));
        patch.Invoke(() => {
            var type = new NoteType() {
                Id = nType.Id,
                Name = nType.Name
            };
            noteTypes.Add(type);
        });
    }
    void addNote(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var nNote = NetNote.FromBytes(array.Slice(4));
        patch.Invoke(() => NoteAdded?.Invoke(nNote));
    }

    void editSite(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var nSite = NetSite.FromBytes(array.Slice(4));
        var site = sites.First(x => x.Id == nSite.Id);

        site.Name = nSite.Name;
        site.Address = nSite.Address;
        site.OnPropertyChanged(null);
    }
    void editParty(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var nParty = NetParty.FromBytes(array.Slice(4));
        var party = parties.First(x => x.Id == nParty.Id);

        party.Name = nParty.Name;
        party.Address = nParty.Address;
        party.Phone = nParty.Phone;
        party.OnPropertyChanged(null);
    }
    void editHead(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var nHead = NetHead.FromBytes(array.Slice(4));
        var head = heads.First(x => x.Id == nHead.Id);

        head.Name = nHead.Name;
        head.OnPropertyChanged(nameof(IHaveName.Name));
    }
    void editSubHead(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var nSubHead = NetHead.FromBytes(array.Slice(4));
        var subHead = subHeads.First(x => x.Id == nSubHead.Id);

        subHead.Name = nSubHead.Name;
        subHead.OnPropertyChanged(nameof(IHaveName.Name));
    }
    void editUnit(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var nUnit = NetUnit.FromBytes(array.Slice(4));
        var unit = units.First(x => x.Id == nUnit.Id);

        unit.Name = nUnit.Name;
        unit.OnPropertyChanged(nameof(IHaveName.Name));
    }
    void editNote(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var nNote = NetNote.FromBytes(array.Slice(4));
        patch.Invoke(() => NoteEdited?.Invoke(nNote));
    }
    
    void deleteNote(ReadOnlySpan<byte> array) {
        var userId = BitConverter.ToInt32(array.Slice(0, 4));
        var noteId = BitConverter.ToInt32(array.Slice(4));
        patch.Invoke(() => NoteDeleted?.Invoke(noteId));
    }

    public static bool HasSite(string name) {
        theSite = sites.FirstOrDefault(x => x.Name.Equals(name.Trim(), StringComparison.InvariantCultureIgnoreCase));
        return theSite is not null;
    }
    public static bool HasParty(string name) {
        theParty = parties.FirstOrDefault(x => x.Name.Equals(name.Trim(), StringComparison.InvariantCultureIgnoreCase));
        return theParty is not null;
    }
    public static bool HasHead(string name) {
        theHead = heads.FirstOrDefault(x => x.Name.Equals(name.Trim(), StringComparison.InvariantCultureIgnoreCase));
        return theHead is not null;
    }
    public static bool HasSubHead(string name) {
        theSubHead = subHeads.FirstOrDefault(x => x.Name.Equals(name.Trim(), StringComparison.InvariantCultureIgnoreCase));
        return theSubHead is not null;
    }
    public static bool HasUnit(string name) {
        theUnit = units.FirstOrDefault(x => x.Name.Equals(name.Trim(), StringComparison.InvariantCultureIgnoreCase));
        return theUnit is not null;
    }
    public static bool HasNoteTye(string name) {
        theNoteType = noteTypes.FirstOrDefault(x => x.Name.Equals(name.Trim(), StringComparison.InvariantCultureIgnoreCase));
        return theNoteType is not null;
    }
    public static Site GetSite() => theSite;
    public static Party GetParty() => theParty;
    public static Head GetHead() => theHead;
    public static SubHead GetSubHead() => theSubHead;
    public static Unit GetUnit() => theUnit;
    public static NoteType GetNoteType() => theNoteType;
}
