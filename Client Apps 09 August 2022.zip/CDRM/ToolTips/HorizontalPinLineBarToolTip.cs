﻿class HorizontalPinLineBarToolTip : ToolTip
{
    public HorizontalPinLineBarToolTip(KeyTrippleValueSeries s) {
        var purchase = new TextBlock() { Text = "Purchase" };
        var paid = new TextBlock() { Text = "Paid" };
        var due = new TextBlock() { Text = "Due" };
        var purchaseAmount = new TextBlock() { 
            Text = s.Value1.ToString(Constants.NumberFormat),
            HorizontalAlignment = HorizontalAlignment.Right
        };
        var paidAmount = new TextBlock() {
            Text = s.Value2.ToString(Constants.NumberFormat),
            HorizontalAlignment = HorizontalAlignment.Right
        };
        var dueAmount = new TextBlock() {
            Text = s.Value3.ToString(Constants.NumberFormat),
            HorizontalAlignment = HorizontalAlignment.Right
        };
        Grid.SetColumn(purchaseAmount, 1);
        Grid.SetColumn(paidAmount, 1);
        Grid.SetColumn(dueAmount, 1);
        Grid.SetRow(paid, 1);
        Grid.SetRow(paidAmount, 1);
        Grid.SetRow(due, 2);
        Grid.SetRow(dueAmount, 2);
        Content = new Grid() {
            RowDefinitions = {
                new RowDefinition(),
                new RowDefinition(),
                new RowDefinition()
            },
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){Width = new GridLength(Constants.AmountColumnWidth)}
            },
            Children = {purchase, purchaseAmount, paid, paidAmount, due, dueAmount },
            Resources = {
                {
                    typeof(TextBlock),
                    new Style(typeof(TextBlock)) {
                        Setters = {
                            new Setter(TextBlock.ForegroundProperty, Brushes.LightGray),
                            new Setter(TextBlock.MarginProperty, new Thickness(5,2.5,5,2.5))
                        }
                    }
                }
            }
        };
    }
}
