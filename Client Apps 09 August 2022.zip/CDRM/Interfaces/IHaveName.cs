﻿interface IHaveName
{
    int Id { get; set; }
    string Name { get; set; }
}
