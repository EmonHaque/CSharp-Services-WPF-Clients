﻿class EditEntryControl : Grid
{
    public static double Top { get; set; }
    public static double Left { get; set; }
    public new static double Width { get; set; }
    public new static double Height { get; set; }

    ActionButton edit, cancel, save;
    EditReceiptPayment receiptPayment;
    EditPurchaseSell purchaseSell;

    public Action SaveAction { get; set; }

    #region DependencyProperties
    public static readonly DependencyProperty IsOnEditProperty;
    public static readonly DependencyProperty SelectedProperty;
    public static readonly DependencyProperty EditedProperty;
    static EditEntryControl() {
        IsOnEditProperty = DependencyProperty.Register("IsOnEdit", typeof(bool), typeof(EditEntryControl),
            new PropertyMetadata() {
                DefaultValue = false,
                PropertyChangedCallback = (d, e) => {
                    var o = (EditEntryControl)d;
                    if ((bool)e.NewValue) {
                        if (o.Selected is EntryPurchaseSellText) {
                            o.receiptPayment.Visibility = Visibility.Hidden;
                            o.purchaseSell.Visibility = Visibility.Visible;
                            o.purchaseSell.DataContext = o.Edited;
                        }
                        else {
                            o.purchaseSell.Visibility = Visibility.Hidden;
                            o.receiptPayment.Visibility = Visibility.Visible;
                            o.receiptPayment.DataContext = o.Edited;
                        }
                        o.cancel.Visibility = o.save.Visibility = Visibility.Visible;
                        o.edit.Visibility = Visibility.Hidden;
                    }
                    else {
                        if (o.Selected is EntryPurchaseSellText) {
                            o.receiptPayment.Visibility = Visibility.Hidden;
                            o.purchaseSell.Visibility = Visibility.Visible;
                            o.purchaseSell.DataContext = o.Selected;
                        }
                        else {
                            o.purchaseSell.Visibility = Visibility.Hidden;
                            o.receiptPayment.Visibility = Visibility.Visible;
                            o.receiptPayment.DataContext = o.Selected;
                        }
                        o.cancel.Visibility = o.save.Visibility = Visibility.Hidden;
                        o.edit.Visibility = Visibility.Visible;
                    }
                }
            });
        SelectedProperty = DependencyProperty.Register("Selected", typeof(IHaveTitle), typeof(EditEntryControl),
            new PropertyMetadata() {
                DefaultValue = null,
                PropertyChangedCallback = (d, e) => {
                    var o = (EditEntryControl)d;
                    if (o.IsOnEdit) {
                        o.IsOnEdit = false;
                        return;
                    }

                    if (e.NewValue is null) {
                        o.purchaseSell.Visibility = Visibility.Hidden;
                        o.receiptPayment.Visibility = Visibility.Hidden;
                        o.edit.Visibility = o.cancel.Visibility = o.save.Visibility = Visibility.Hidden;
                        return;
                    }
                    if (e.NewValue is EntryPurchaseSellText) {
                        o.receiptPayment.Visibility = Visibility.Hidden;
                        o.purchaseSell.Visibility = Visibility.Visible;
                        o.purchaseSell.DataContext = e.NewValue;
                    }
                    else {
                        o.purchaseSell.Visibility = Visibility.Hidden;
                        o.receiptPayment.Visibility = Visibility.Visible;
                        o.receiptPayment.DataContext = e.NewValue;
                    }
                    o.edit.Visibility = Visibility.Visible;
                }
            });

        EditedProperty = DependencyProperty.Register("Edited", typeof(IHaveTitle), typeof(EditEntryControl));
    }
    public bool IsOnEdit {
        get { return (bool)GetValue(IsOnEditProperty); }
        set { SetValue(IsOnEditProperty, value); }
    }
    public IHaveTitle Selected {
        get { return (IHaveTitle)GetValue(SelectedProperty); }
        set { SetValue(SelectedProperty, value); }
    }
    public IHaveTitle Edited {
        get { return (IHaveTitle)GetValue(EditedProperty); }
        set { SetValue(EditedProperty, value); }
    }
    #endregion

    public EditEntryControl() {
        Margin = new Thickness(0, 5, 0, 0);
        RowDefinitions.Add(new RowDefinition());
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });

        receiptPayment = new EditReceiptPayment();
        purchaseSell = new EditPurchaseSell();
        Children.Add(receiptPayment);
        Children.Add(purchaseSell);
        addButtons();

        purchaseSell.Visibility = Visibility.Hidden;
        receiptPayment.Visibility = Visibility.Hidden;

        receiptPayment.SetBinding(EditReceiptPayment.IsEnabledProperty, new Binding(nameof(IsOnEdit)) { Source = this });
        purchaseSell.SetBinding(EditPurchaseSell.IsEnabledProperty, new Binding(nameof(IsOnEdit)) { Source = this });
        
    }
    
    void addButtons() {
        edit = new ActionButton() {
            ToolTip = "Edit",
            Icon = Icons.Pencil,
            Margin = new Thickness(5, 5, 0, 0),
            Visibility = Visibility.Hidden,
            HorizontalAlignment = HorizontalAlignment.Left,
            Command = setEdit
        };
        cancel = new ActionButton() {
            ToolTip = "Cancel",
            Icon = Icons.Close,
            Visibility = Visibility.Hidden,
            Margin = new Thickness(5, 5, 0, 0),
            HorizontalAlignment = HorizontalAlignment.Left,
            Command = cancelEdit
        };
        save = new ActionButton() {
            Margin = new Thickness(0, 5, 5, 0),
            ToolTip = "Save",
            Icon = Icons.Checked,
            Visibility = Visibility.Hidden,
            HorizontalAlignment = HorizontalAlignment.Right,
            Command = saveEdit
        };
        SetRow(edit, 1);
        SetRow(cancel, 1);
        SetRow(save, 1);
        Children.Add(edit);
        Children.Add(cancel);
        Children.Add(save);
    }
    void setEdit() => IsOnEdit = true;
    void cancelEdit() => IsOnEdit = false;
    async void saveEdit() {
        var request = new CDRMRequest() { UserId = App.service.UserId };
        Response response = null;

        if (Edited is EntryPurchaseSellText) {
            var entry = (EntryPurchaseSellText)Edited;
            var validator = new PurchaseSellValidator(entry);
            if (!validator.IsValid()) {
                updatePosition();
                var errorDialog = new ErrorDialog(Left, Top, Width, Height, validator.Errors);
                errorDialog.ShowDialog();
                return;
            }
            if (validator.IsEqual((EntryPurchaseSellText)Selected)) return;
            if (!validator.DoesExist()) {
                updatePosition();
                var confirmDialog = new ConfirmCreationDialog(Left, Top, Width, Height, validator.Errors);
                var result = confirmDialog.ShowDialog();
                if (!result.HasValue) return;
                if (!result.Value) return;

                foreach (var e in validator.Errors) {
                    switch (e.Head) {
                        case nameof(entry.Site): {
                                var dialog = new CreateSiteDialog(Left, Top, Width, Height, entry.Site);
                                dialog.ShowDialog();
                                var site = new NetSite() {
                                    Name = entry.Site.Trim(),
                                    Address = dialog.GetAddress().Trim()
                                };
                                request.Method = (int)Function.AddSite;
                                request.Args = new object[] { site };
                                response = await App.service.GetResponse(request);
                                AppData.HasSite(entry.Site);
                            }
                            break;
                        case nameof(entry.Party): {
                                var dialog = new CreatePartyDialog(Left, Top, Width, Height, entry.Party);
                                dialog.ShowDialog();
                                var (address, phone) = dialog.GetAddressAndPhone();
                                var party = new NetParty() {
                                    Name = entry.Party.Trim(),
                                    Address = address.Trim(),
                                    Phone = phone?.Trim()
                                };
                                request.Method = (int)Function.AddParty;
                                request.Args = new object[] { party };
                                response = await App.service.GetResponse(request);
                                AppData.HasParty(entry.Party);
                            }
                            break;
                        case nameof(entry.Head): {
                                request.Method = (int)Function.AddHead;
                                request.Args = new object[] { new NetHead() { Name = entry.Head.Trim() } };
                                response = await App.service.GetResponse(request);
                                AppData.HasHead(entry.Head);
                            }
                            break;
                        case nameof(entry.SubHead): {
                                request.Method = (int)Function.AddSubHead;
                                request.Args = new object[] { new NetSubHead() { Name = entry.SubHead.Trim() } };
                                response = await App.service.GetResponse(request);
                                AppData.HasSubHead(entry.SubHead);
                            }
                            break;
                        case nameof(entry.Unit): {
                                request.Method = (int)Function.AddUnit;
                                request.Args = new object[] { new NetUnit() { Name = entry.Unit.Trim() } };
                                response = await App.service.GetResponse(request);
                                AppData.HasUnit(entry.Unit);
                            }
                            break;
                    }
                }
            }
        }
        else {
            var entry = (EntryReceiptPaymentText)Edited;
            var validator = new ReceiptPaymentValidator(entry);
            if (!validator.IsValid()) {
                updatePosition();
                var errorDialog = new ErrorDialog(Left, Top, Width, Height, validator.Errors);
                errorDialog.ShowDialog();
                return;
            }
            if (validator.IsEqual((EntryReceiptPaymentText)Selected)) return;

            if (!validator.DoesExist()) {
                updatePosition();
                var confirmDialog = new ConfirmCreationDialog(Left, Top, Width, Height, validator.Errors);
                var result = confirmDialog.ShowDialog();
                if (!result.HasValue) return;
                if (!result.Value) return;

                foreach (var e in validator.Errors) {
                    switch (e.Head) {
                        case "Head": {
                                request.Method = (int)Function.AddHead;
                                request.Args = new object[] { new NetHead() { Name = entry.Head.Trim() } };
                                response = await App.service.GetResponse(request);
                                AppData.HasHead(e.Head);
                            } break;
                        case "Party": {
                                var dialog = new CreatePartyDialog(Left, Top, Width, Height, entry.Party);
                                dialog.ShowDialog();
                                var (address, phone) = dialog.GetAddressAndPhone();
                                var party = new NetParty() {
                                    Name = entry.Party.Trim(),
                                    Address = address.Trim(),
                                    Phone = phone?.Trim()
                                };
                                AppData.HasParty(entry.Party);
                            }break;
                    }
                }
            }
        }
        SaveAction.Invoke();
        IsOnEdit = false;
    }
    void updatePosition() {
        var dpi = VisualTreeHelper.GetDpi(this);
        var position = PointToScreen(TranslatePoint(new Point(0,0), this));

        position.X /= dpi.DpiScaleX;
        position.Y /= dpi.DpiScaleY;

        Left = position.X - 7;
        Top = position.Y - 5;
        Width = ActualWidth + 14;
        Height = ActualHeight + 10;
    }
}

