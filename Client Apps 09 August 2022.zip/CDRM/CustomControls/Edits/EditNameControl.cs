﻿class EditNameControl : Grid
{
    double top, left;
    TextBlock name;
    TextBox editName;
    StackPanel buttonStack;
    ActionButton edit, cancel, save;
    protected Type objectType;
    protected StackPanel normalControls, editableControls;
    protected List<ValidationError> errors;
    public Action SaveAction { get; set; }

    public EditNameControl() {
        Background = Brushes.Transparent;
        Margin = new Thickness(0, 0, 10, 0);
        addButtons();
        addNormalControls();
        addEditableControls();
        Children.Add(new StackPanel() {
            VerticalAlignment = VerticalAlignment.Center,
            Children = { edit, buttonStack, normalControls, editableControls }
        });
        bind();
    }

    void updateTopLeft() {
        var dpi = VisualTreeHelper.GetDpi(this);
        var position = PointToScreen(TranslatePoint(new Point(0, 0), this));

        position.X /= dpi.DpiScaleX;
        position.Y /= dpi.DpiScaleY;
        left = position.X;
        top = position.Y;
    }
    void setEdit() {
        if (Selected is null) return;
        IsOnEdit = true;
        edit.Visibility = Visibility.Collapsed;
        normalControls.Visibility = Visibility.Collapsed;
        buttonStack.Visibility = Visibility.Visible;
        editableControls.Visibility = Visibility.Visible;
    }
    void cancelEdit() {
        IsOnEdit = false;
        edit.Visibility = Visibility.Visible;
        normalControls.Visibility = Visibility.Visible;
        buttonStack.Visibility = Visibility.Collapsed;
        editableControls.Visibility = Visibility.Collapsed;
    }
    void saveEdit() {
        if (isValid()) {
            SaveAction?.Invoke();
            IsOnEdit = false;
        }
        else {
            updateTopLeft();
            var errorDialog = new ErrorDialog(left, top, ActualWidth + Margin.Right, ActualHeight, errors);
            errorDialog.ShowDialog();
        }
    }
    void addButtons() {
        edit = new ActionButton() {
            ToolTip = "Edit",
            Icon = Icons.Pencil,
            HorizontalAlignment = HorizontalAlignment.Right,
            Visibility = Visibility.Hidden,
            Command = setEdit
        };
        cancel = new ActionButton() {
            ToolTip = "Cancel",
            Icon = Icons.Close,
            HorizontalAlignment = HorizontalAlignment.Right,
            Command = cancelEdit
        };
        save = new ActionButton() {
            Margin = new Thickness(0, 0, 5, 0),
            ToolTip = "Save",
            Icon = Icons.Checked,
            HorizontalAlignment = HorizontalAlignment.Right,
            Command = saveEdit
        };
        buttonStack = new StackPanel() {
            Visibility = Visibility.Collapsed,
            Orientation = Orientation.Horizontal,
            HorizontalAlignment = HorizontalAlignment.Right,
            Children = { save, cancel }
        };
    }
    bool isValid() {
        addErrors();
        return errors.Count == 0;
    }

    protected virtual void addErrors() {
        objectType = Edited.GetType();
        var name = objectType.GetProperty(nameof(IHaveName.Name)).GetValue(Edited, null).ToString();
        errors = new List<ValidationError>();
        if (string.IsNullOrWhiteSpace(name)) {
            errors.Add(new ValidationError() {
                Head = nameof(IHaveName.Name),
                Error = "cannot be empty"
            });
        }
    }
    protected virtual void addNormalControls() {
        name = new TextBlock() {
            HorizontalAlignment = HorizontalAlignment.Center,
            TextAlignment = TextAlignment.Center,
            TextWrapping = TextWrapping.Wrap
        };

        normalControls = new StackPanel() {
            Children = { name }
        };
    }
    protected virtual void addEditableControls() {
        editName = new TextBox();
        editableControls = new StackPanel() {
            Children = { editName },
            Visibility = Visibility.Collapsed,
            Resources = {
                {
                   typeof(TextBox),
                   new Style(typeof(TextBox)) {
                       Setters = {
                           new Setter(TextBox.MarginProperty, new Thickness(0, 0, 0, 5)),
                           new Setter(TextBox.BorderThicknessProperty, new Thickness(0, 0, 0, Constants.BottomLineThickness)),
                           new Setter(TextBox.BorderBrushProperty, Brushes.LightGray),
                           new Setter(TextBox.ForegroundProperty, Brushes.LightGray),
                           new Setter(TextBox.TextAlignmentProperty, TextAlignment.Center),
                           new Setter(TextBox.CaretBrushProperty, Brushes.White)
                       }
                   }
                }
            }
        };
    }
    protected virtual void bind() {
        normalControls.SetBinding(DataContextProperty, new Binding(nameof(Selected)) { Source = this });
        editableControls.SetBinding(DataContextProperty, new Binding(nameof(Edited)) { Source = this });

        name.SetBinding(TextBlock.TextProperty, new Binding(nameof(IHaveName.Name)));
        editName.SetBinding(TextBox.TextProperty, new Binding(nameof(IHaveName.Name)) {
            UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged
        });
    }
   
    protected override void OnMouseEnter(MouseEventArgs e) {
        base.OnMouseEnter(e);
        if (!IsOnEdit) edit.Visibility = Visibility.Visible;
    }
    protected override void OnMouseLeave(MouseEventArgs e) {
        base.OnMouseLeave(e);
        if (!IsOnEdit) edit.Visibility = Visibility.Hidden;
    }

    #region DependencyProperties
    public static readonly DependencyProperty EditedProperty;
    public static readonly DependencyProperty SelectedProperty;
    public static readonly DependencyProperty IsOnEditProperty;

    static EditNameControl() {
        SelectedProperty = DependencyProperty.Register("Selected", typeof(object), typeof(EditNameControl));
        EditedProperty = DependencyProperty.Register("Edited", typeof(object), typeof(EditNameControl));
        IsOnEditProperty = DependencyProperty.Register("IsOnEdit", typeof(bool), typeof(EditNameControl), new PropertyMetadata() {
            DefaultValue = false,
            PropertyChangedCallback = (d, e) => {
                var o = (EditNameControl)d;
                if ((bool)e.NewValue) o.setEdit();
                else o.cancelEdit();
            }
        });
    }

    public bool IsOnEdit {
        get { return (bool)GetValue(IsOnEditProperty); }
        set { SetValue(IsOnEditProperty, value); }
    }
    public object Selected {
        get { return (object)GetValue(SelectedProperty); }
        set { SetValue(SelectedProperty, value); }
    }
    public object Edited {
        get { return (object)GetValue(EditedProperty); }
        set { SetValue(EditedProperty, value); }
    }
    #endregion
}
