﻿class EditPurchaseSell : Grid
{
    DayPicker date;
    SuggestBox site, party, head, subHead, unit;
    TextBlock partyAddressBlock, partyPhoneBlock, siteAddressBlock;
    Run partyAddress, partyPhone, siteAddress;
    EditText amount, quantity, narration;
    MultiState isConstruction, isPurchase;

    public EditPurchaseSell() {
        date = new DayPicker() {
            Hint = "Date",
            DateFormat = "dd/MM/yyyy"
        };
        isPurchase = new MultiState() {
            Icons = new string[] { Icons.Purchase, Icons.Sell },
            Texts = new string[] { "Purchase", "Sell" },
            IsIconInfront = true,
            Margin = new Thickness(5, 5, 0, 0),
            VerticalAlignment = VerticalAlignment.Center
        };
        isConstruction = new MultiState() {
            Icons = new string[] { Icons.Construction, Icons.Development, Icons.Repair, Icons.Maintenance },
            Texts = new string[] { "Construction", "Development", "Repair", "Maintenance" },
            IsIconInfront = true,
            Margin = new Thickness(5, 5, 5, 0),
            VerticalAlignment = VerticalAlignment.Center
        };
        amount = new EditText() {
            Icon = Icons.Amount,
            Hint = "Amount"
        };
        Grid.SetColumn(isPurchase, 1);
        Grid.SetColumn(isConstruction, 2);
        Grid.SetColumn(amount, 3);
        var dateDueGrid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(){ Width = new GridLength(2, GridUnitType.Star)},
                new ColumnDefinition(),
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = new GridLength(1.55, GridUnitType.Star)}
            },
            Children = { date, isPurchase, isConstruction, amount }
        };
        site = new SuggestBox() {
            IsRequired = true,
            Icon = Icons.Plot,
            Hint = "Site",
            Source = AppData.sites
        };
        party = new SuggestBox() {
            IsRequired = true,
            Icon = Icons.Tenant,
            Hint = "Party",
            Source = AppData.parties
        };
        partyAddress = new Run();
        partyPhone = new Run();
        partyAddressBlock = new TextBlock() {
            Margin = new Thickness(5, 5, 0, 5),
            Inlines = { "Address: ", partyAddress }
        };
        partyPhoneBlock = new TextBlock() {
            Margin = new Thickness(5, 5, 0, 10),
            Inlines = { "Phone: ", partyPhone }
        };
        siteAddress = new Run();
        siteAddressBlock = new TextBlock() {
            Margin = new Thickness(5, 5, 0, 10),
            Inlines = { "Address: ", siteAddress }
        };
        Grid.SetRow(partyAddressBlock, 1);
        Grid.SetRow(partyPhoneBlock, 2);
        Grid.SetRow(site, 3);
        Grid.SetRow(siteAddressBlock, 4);
        var partySiteGrid = new Grid() {
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto },
                new RowDefinition(){Height = GridLength.Auto },
                new RowDefinition(){Height = GridLength.Auto },
                new RowDefinition(){Height = GridLength.Auto },
                new RowDefinition(){Height = GridLength.Auto }
            },
            Children = { party, partyAddressBlock, partyPhoneBlock, site, siteAddressBlock }
        };
        head = new SuggestBox() {
            IsRequired = true,
            Icon = Icons.ControlHead,
            Hint = "Head",
            Source = AppData.heads
        };
        subHead = new SuggestBox() {
            Icon = Icons.Head,
            Hint = "Subhead",
            Source = AppData.subHeads
        };
        quantity = new EditText() {
            Icon = Icons.Amount,
            Hint = "Quantity"
        };
        unit = new SuggestBox() {
            Icon = Icons.Accounts,
            Hint = "Unit",
            Source = AppData.units
        };
        Grid.SetColumn(subHead, 1);
        Grid.SetRow(quantity, 1);
        Grid.SetRow(unit, 1);
        Grid.SetColumn(unit, 1);
        var headQuantityGrid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition()
            },
            RowDefinitions = {

                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(){Height = GridLength.Auto}
            },
            Children = { head, subHead, quantity, unit }
        };
        narration = new EditText() {
            Margin = new Thickness(0, 15, 0, 0),
            IsMultiline = true,
            Icon = Icons.Description,
            Hint = "Narration"
        };

        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
        RowDefinitions.Add(new RowDefinition());

        SetRow(partySiteGrid, 1);
        SetRow(headQuantityGrid, 2);
        SetRow(narration, 3);

        Children.Add(dateDueGrid);
        Children.Add(partySiteGrid);
        Children.Add(headQuantityGrid);
        Children.Add(narration);

        bind();
    }

    void bind() {
        date.SetBinding(DayPicker.SelectedDateProperty, new Binding(nameof(EntryPurchaseSellText.Date)) );
        site.SetBinding(SuggestBox.TextProperty, new Binding(nameof(EntryPurchaseSellText.Site)) );
        party.SetBinding(SuggestBox.TextProperty, new Binding(nameof(EntryPurchaseSellText.Party)));
        head.SetBinding(SuggestBox.TextProperty, new Binding(nameof(EntryPurchaseSellText.Head)));
        subHead.SetBinding(SuggestBox.TextProperty, new Binding(nameof(EntryPurchaseSellText.SubHead)) );
        unit.SetBinding(SuggestBox.TextProperty, new Binding(nameof(EntryPurchaseSellText.Unit)) );
        quantity.SetBinding(EditText.TextProperty, new Binding(nameof(EntryPurchaseSellText.Quantity)));
        amount.SetBinding(EditText.TextProperty, new Binding(nameof(EntryPurchaseSellText.Amount)) );
        narration.SetBinding(EditText.TextProperty, new Binding(nameof(EntryPurchaseSellText.Narration)) );
        isPurchase.SetBinding(MultiState.StateProperty, new Binding(nameof(EntryPurchaseSellText.IsSell)));
        isConstruction.SetBinding(MultiState.StateProperty, new Binding(nameof(EntryPurchaseSellText.IsConstruction)));
    }
}
