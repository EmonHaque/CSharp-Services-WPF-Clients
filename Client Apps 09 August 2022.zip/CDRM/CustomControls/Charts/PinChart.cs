﻿class PinChart : Panel
{
    int max, itemCount;
    int numSteps = 6;
    Size bottomLabelDesired, sideLabelDesired;

    TextBlock date, purchase, noInfoBlock;
    StackPanel singleEntry;

    public PinChart() {
        LayoutTransform = new ScaleTransform() { ScaleY = -1 };
        date = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Center };
        purchase = new TextBlock() { HorizontalAlignment = HorizontalAlignment.Center };
        singleEntry = new StackPanel() {
            Background = Brushes.Green,
            Children = { date, purchase },
            LayoutTransform = new ScaleTransform() { ScaleY = -1 }
        };

        noInfoBlock = new TextBlock() {
            TextAlignment = TextAlignment.Center,
            FontSize = 18,
            FontWeight = FontWeights.Bold,
            Foreground = Brushes.Gray,
            Inlines = {
                    new Run(){ Text = "No data"},
                    new LineBreak(),
                    new Run(){ Text = "available" }
                },
            LayoutTransform = new ScaleTransform() { ScaleY = -1 }
        };
    }
    void addLabel(string date) {
        var label = new TextBlock() {
            Tag = "Label",
            Text = date,
            IsHitTestVisible = false,
            TextAlignment = TextAlignment.Right,
            Padding = new Thickness(0, 0, 5, 0),
            RenderTransform = new TransformGroup() {
                Children = {
                            new ScaleTransform() { ScaleY = -1 },
                            new RotateTransform() { Angle = 90 }
                        }
            }
        };
        Children.Add(label);
        label.Measure(new Size(double.PositiveInfinity, double.PositiveInfinity));
        if (label.DesiredSize.Width > bottomLabelDesired.Width)
            bottomLabelDesired = label.DesiredSize;
        //label.Loaded += animateLabels;
    }
    void addSideLables() {
        var x1Label = new TextBlock() {
            Tag = "x1Label",
            Text = "Purchase / Payable",
            FontWeight = FontWeights.Bold,
            Foreground = Brushes.Gray,
            Padding = new Thickness(0, 0, 0, 5),
            RenderTransform = new RotateTransform(90),
            LayoutTransform = new ScaleTransform() { ScaleY = -1 },
            TextAlignment = TextAlignment.Center

        };
        Children.Add(x1Label);
        x1Label.Measure(new Size(double.PositiveInfinity, double.PositiveInfinity));
        sideLabelDesired.Width = x1Label.DesiredSize.Width;
        sideLabelDesired.Height = x1Label.DesiredSize.Height;
    }
    void addLine() {
        var line = new Line() {
            StrokeThickness = 0.25,
            Stroke = Brushes.LightGray,
            StrokeDashCap = PenLineCap.Flat,
            StrokeDashArray = new DoubleCollection(new List<double> { 10, 5 }),
            IsHitTestVisible = false
        };
        Children.Add(line);
        SetZIndex(line, 1);
        //line.Loaded += animateLines;
    }
    void addTick(double value) {
        var tick = new TextBlock() {
            Tag = "Tick",
            Text = value.ToString("N0"),
            HorizontalAlignment = HorizontalAlignment.Left,
            RenderTransform = new TransformGroup() {
                Children = {
                    new ScaleTransform() { ScaleY = - 1 },
                    new TranslateTransform()
                }
            },
            IsHitTestVisible = false
        };
        Children.Add(tick);
        //tick.Loaded += animateTicks;
    }
    void generateChart(List<KeyValueSeries> list) {
        itemCount = list.Count;
        if (itemCount == 0) {
            Children.Add(noInfoBlock);
            return;
        }
        if (itemCount == 1) {
            var entry = list[0];
            date.Text = entry.Key;
            purchase.Text = "Purchase: " + entry.Value.ToString("N0");
            Children.Add(singleEntry);
            return;
        }
        bottomLabelDesired = new Size(0, 0);
        max = 0;
        foreach (var entry in list) {
            Pin pin = new(entry);
            Children.Add(pin);
            SetZIndex(pin, 3);
            addLabel(entry.Key);
            if (entry.Value > max) max = entry.Value;
        }

        double step = max / (numSteps - 1);
        var current = 0d;
        for (int i = 0; i < numSteps; i++) {
            addLine();
            addTick(current);
            current += step;
        }
        addSideLables();
    }
    protected override Size ArrangeOverride(Size finalSize) {
        if (itemCount == 0) {
            noInfoBlock.Measure(finalSize);
            var center = new Point(finalSize.Width / 2, finalSize.Height / 2);
            var point = new Point(center.X - noInfoBlock.DesiredSize.Width / 2, center.Y - noInfoBlock.DesiredSize.Height / 2);
            noInfoBlock.Arrange(new Rect(point, noInfoBlock.DesiredSize));
            return finalSize;
        }
        if (itemCount == 1) {
            singleEntry.Measure(finalSize);
            var center = new Point(finalSize.Width / 2, finalSize.Height / 2);
            var point = new Point(center.X - singleEntry.DesiredSize.Width / 2, center.Y - singleEntry.DesiredSize.Height / 2);
            singleEntry.Arrange(new Rect(point, singleEntry.DesiredSize));
            return finalSize;
        }
        if (finalSize.Width < 20 || finalSize.Height == 0) return finalSize;

        var x1Tick = new TextBlock() { Text = max.ToString("N0") };
        x1Tick.Measure(finalSize);
        var labelHeight = bottomLabelDesired.Width;

        var bars = Children.OfType<Pin>().Count();
        var leftSpace = x1Tick.DesiredSize.Width + sideLabelDesired.Height;
        var pinWidth = (finalSize.Width - leftSpace) / bars;

        var availableHeight = finalSize.Height - labelHeight - x1Tick.DesiredSize.Height;
        var lineSpace = availableHeight / (numSteps - 1);
        var barSpace = leftSpace;
        var labelSpace = leftSpace + pinWidth / 2 - bottomLabelDesired.Height / 2;
        var y = labelHeight;
        var pinTickY = labelHeight;
        var availableWidth = finalSize.Width - leftSpace - pinWidth;

        if (availableWidth < 5 || availableHeight < 5) return finalSize;

        foreach (UIElement item in Children) {
            if (item is Pin) {
                var rect = (Pin)item;
                rect.upperBound = max;
                rect.Measure(new Size(pinWidth, availableHeight));
                rect.Arrange(new Rect(new Point(barSpace, labelHeight), rect.DesiredSize));
                barSpace += pinWidth;
            }

            else if (item is Line) {
                var line = (Line)item;
                line.X1 = sideLabelDesired.Height;
                line.X2 = finalSize.Width;
                line.Y1 = line.Y2 = y;
                item.Measure(finalSize);
                item.Arrange(new Rect(item.DesiredSize));
                y += lineSpace;
            }
            else if (item is TextBlock) {
                var block = (TextBlock)item;
                if (string.Equals(block.Tag.ToString(), "Tick")) {
                    block.Measure(finalSize);
                    block.Arrange(new Rect(new Point(sideLabelDesired.Height, pinTickY + block.DesiredSize.Height), block.DesiredSize));
                    pinTickY += lineSpace;
                }
                else if (string.Equals(block.Tag.ToString(), "x1Label")) {
                    block.Width = availableHeight;
                    block.Measure(finalSize);
                    block.Arrange(new Rect(new Point(block.DesiredSize.Height, labelHeight), block.DesiredSize));
                }
                else if (string.Equals(block.Tag.ToString(), "Label")) {
                    block.Width = bottomLabelDesired.Width;
                    block.Measure(finalSize);
                    block.Arrange(new Rect(new Point(labelSpace, 0), block.DesiredSize));
                    labelSpace += pinWidth;
                }
            }
        }

        return finalSize;
    }

    public IEnumerable ItemsSource {
        get { return (IEnumerable)GetValue(ItemsSourceProperty); }
        set { SetValue(ItemsSourceProperty, value); }
    }
    public static readonly DependencyProperty ItemsSourceProperty =
        DependencyProperty.Register("ItemsSource", typeof(IEnumerable), typeof(PinChart), new FrameworkPropertyMetadata() {
            DefaultValue = null,
            PropertyChangedCallback = onSourceChanged,
            AffectsArrange = true
        });

    static void onSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
        var o = d as PinChart;
        o.Children.Clear();
        if (e.NewValue is null) return;
        var list = (((IEnumerable<object>)e.NewValue).Cast<KeyValueSeries>()).ToList();
        o.generateChart(list);
    }
}
