﻿class PinLineBarChart : Panel
{
    double x1Max, x2Max;
    int numSteps = 6;
    int itemCount;
    Size bottomLabelDesired, sideLabelDesired;
    TextBlock date, purchase, payment, outstanding, noInfoBlock;
    StackPanel singleEntry;

    public PinLineBarChart() {
        LayoutTransform = new ScaleTransform() { ScaleY = -1 };
        date = new TextBlock();
        purchase = new TextBlock();
        payment = new TextBlock();
        outstanding = new TextBlock();
        singleEntry = new StackPanel() {
            Children = { date, purchase, payment, outstanding },
            LayoutTransform = new ScaleTransform() { ScaleY = -1 }
        };

        noInfoBlock = new TextBlock() {
            TextAlignment = TextAlignment.Center,
            FontSize = 18,
            FontWeight = FontWeights.Bold,
            Foreground = Brushes.Gray,
            Inlines = {
                    new Run(){ Text = "No data"},
                    new LineBreak(),
                    new Run(){ Text = "available" }
                },
            LayoutTransform = new ScaleTransform() { ScaleY = -1 }
        };
    }
    
    void addLabel(string date) {
        var label = new TextBlock() {
            Tag = "Label",
            Text = date,
            IsHitTestVisible = false,
            TextAlignment = TextAlignment.Right,
            Padding = new Thickness(0, 0, 5, 0),
            RenderTransform = new TransformGroup() {
                Children = {
                    new ScaleTransform() { ScaleY = -1 },
                    new RotateTransform() { Angle = 90 }
                }
            }
        };
        Children.Add(label);
        label.Measure(new Size(double.PositiveInfinity, double.PositiveInfinity));
        if (label.DesiredSize.Width > bottomLabelDesired.Width)
            bottomLabelDesired = label.DesiredSize;
        //label.Loaded += animateLabels;
    }
    void addSideLables() {
        var x1Label = new TextBlock() {
            Tag = "x1Label",
            Text = "Purchase & Payments",
            FontWeight = FontWeights.Bold,
            Foreground = Brushes.Gray,
            Padding = new Thickness(0, 0, 0, 5),
            RenderTransform = new RotateTransform(90),
            LayoutTransform = new ScaleTransform() { ScaleY = -1 },
            TextAlignment = TextAlignment.Center

        };
        var x2Label = new TextBlock() {
            Tag = "x2Label",
            Text = "Outstanding",
            FontWeight = FontWeights.Bold,
            Foreground = Brushes.Gray,
            Padding = new Thickness(0, 0, 0, 5),
            RenderTransform = new RotateTransform(-90),
            LayoutTransform = new ScaleTransform() { ScaleY = -1 },
            TextAlignment = TextAlignment.Center
        };
        Children.Add(x1Label);
        Children.Add(x2Label);
        x1Label.Measure(new Size(double.PositiveInfinity, double.PositiveInfinity));
        x2Label.Measure(new Size(double.PositiveInfinity, double.PositiveInfinity));
        sideLabelDesired.Width = x1Label.DesiredSize.Width > x2Label.DesiredSize.Width ? x1Label.DesiredSize.Width : x2Label.DesiredSize.Width;
        sideLabelDesired.Height = x1Label.DesiredSize.Height > x2Label.DesiredSize.Height ? x1Label.DesiredSize.Height : x2Label.DesiredSize.Height;
    }
    void addLine() {
        var line = new Line() {
            StrokeThickness = 0.25,
            Stroke = Brushes.LightGray,
            StrokeDashCap = PenLineCap.Flat,
            StrokeDashArray = new DoubleCollection(new List<double> { 10, 5 }),
            IsHitTestVisible = false
        };
        Children.Add(line);
        SetZIndex(line, 1);
        //line.Loaded += animateLines;
    }
    void addX1Tick(double value) {
        var tick = new TextBlock() {
            Tag = "x1Tick",
            Text = value.ToString("N0"),
            HorizontalAlignment = HorizontalAlignment.Left,
            RenderTransform = new TransformGroup() {
                Children = {
                    new ScaleTransform() { ScaleY = - 1 },
                    new TranslateTransform()
                }
            },
            IsHitTestVisible = false
        };
        Children.Add(tick);
        //tick.Loaded += animateTicks;
    }
    void addX2Tick(double value) {
        var tick = new TextBlock() {
            Tag = "x2Tick",
            Text = value.ToString("N0"),
            HorizontalAlignment = HorizontalAlignment.Right,
            RenderTransform = new TransformGroup() {
                Children = {
                    new ScaleTransform() { ScaleY = - 1 },
                    new TranslateTransform()
                }
            },
            IsHitTestVisible = false
        };
        Children.Add(tick);
        //tick.Loaded += animateTicks;
    }
    void generateChart(List<KeyTrippleValueSeries> list) {
        itemCount = list.Count;
        if (itemCount == 0) {
            Children.Add(noInfoBlock);
            return;
        }
        if (itemCount == 1) {
            var entry = list[0];
            date.Text = entry.Key;
            purchase.Text = "Purchase: " + entry.Value1.ToString("N0");
            payment.Text = "Payment: " + entry.Value2.ToString("N0");
            outstanding.Text = "Outstanding: " + entry.Value3.ToString("N0");
            Children.Add(singleEntry);
            return;
        }
        bottomLabelDesired = new Size(0, 0);
        x1Max = 0;
        var payments = new List<int>();
        foreach (var entry in list) {
            PinBar pinBar = new(entry);
            Children.Add(pinBar);
            SetZIndex(pinBar, 3);
            addLabel(entry.Key);
            payments.Add(entry.Value2);

            if (entry.Value1 > x1Max) x1Max = entry.Value1;
            if (entry.Value2 > x1Max) x1Max = entry.Value2;
            if (entry.Value3 > x2Max) x2Max = entry.Value3;
        }
        var path = new LineStream(payments);
        Children.Add(path);
        SetZIndex(path, 2);

        var pinCurrent = 0d;
        var barCurrent = 0d;

        double pinStep = x1Max / (numSteps - 1);
        double barStep = x2Max / (numSteps - 1);

        for (int i = 0; i < numSteps; i++) {
            addLine();
            addX1Tick(pinCurrent);
            addX2Tick(barCurrent);
            pinCurrent += pinStep;
            barCurrent += barStep;
        }
        addSideLables();
    }
    protected override Size ArrangeOverride(Size finalSize) {
        if (itemCount == 0) {
            noInfoBlock.Measure(finalSize);
            var center = new Point(finalSize.Width / 2, finalSize.Height / 2);
            var point = new Point(center.X - noInfoBlock.DesiredSize.Width / 2, center.Y - noInfoBlock.DesiredSize.Height / 2);
            noInfoBlock.Arrange(new Rect(point, noInfoBlock.DesiredSize));
            return finalSize;
        }
        if (itemCount == 1) {
            singleEntry.Measure(finalSize);
            var center = new Point(finalSize.Width / 2, finalSize.Height / 2);
            var point = new Point(center.X - singleEntry.DesiredSize.Width / 2, center.Y - singleEntry.DesiredSize.Height / 2);
            singleEntry.Arrange(new Rect(point, singleEntry.DesiredSize));
            return finalSize;
        }
        if (finalSize.Width < 20 || finalSize.Height == 0) return finalSize;

        var bars = Children.OfType<PinBar>().Count();
        var x1Tick = new TextBlock() { Text = x1Max.ToString("N0") };
        var x2Tick = new TextBlock() { Text = x2Max.ToString("N0") };
        x1Tick.Measure(finalSize);
        x2Tick.Measure(finalSize);
        var labelHeight = bottomLabelDesired.Width;
        var x1TickSpace = x1Tick.DesiredSize.Width + sideLabelDesired.Height;
        var x2TickSpace = x2Tick.DesiredSize.Width + sideLabelDesired.Height;
        var pinWidth = (finalSize.Width - x1TickSpace - x2TickSpace) / bars;

        var availableHeight = finalSize.Height - labelHeight - x1Tick.DesiredSize.Height /*- infoPanel.DesiredSize.Height*/;
        var lineSpace = availableHeight / (numSteps - 1);
        var barSpace = x1TickSpace;
        var labelSpace = x1TickSpace + pinWidth / 2 - bottomLabelDesired.Height / 2;
        var y = labelHeight;
        var pinTickY = labelHeight;
        var barTickY = labelHeight;
        var availableWidth = finalSize.Width - x1Tick.DesiredSize.Width - x2Tick.DesiredSize.Width - pinWidth - 2 * sideLabelDesired.Height;


        if (availableWidth < 5 || availableHeight < 5) return finalSize;
        foreach (UIElement item in Children) {
            if (item is PinBar) {
                var rect = (PinBar)item;
                rect.pinUpperBound = x1Max;
                rect.barUpperBound = x2Max;
                rect.Measure(new Size(pinWidth, availableHeight));
                rect.Arrange(new Rect(new Point(barSpace, labelHeight), rect.DesiredSize));
                barSpace += pinWidth;
            }
            else if (item is LineStream) {
                var path = (LineStream)item;
                path.SetParameters(availableWidth, availableHeight, 0d, x1Max, pinWidth);
                path.Arrange(new Rect(new Point(x1Tick.DesiredSize.Width + pinWidth / 2 + sideLabelDesired.Height, labelHeight), path.DesiredSize));
            }
            else if (item is Line) {
                var line = (Line)item;
                line.X1 = sideLabelDesired.Height;
                line.X2 = finalSize.Width - sideLabelDesired.Height;
                line.Y1 = line.Y2 = y;
                item.Measure(finalSize);
                item.Arrange(new Rect(item.DesiredSize));
                y += lineSpace;
            }
            else if (item is TextBlock) {
                var block = (TextBlock)item;
                if (string.Equals(block.Tag.ToString(), "x1Tick")) {
                    block.Measure(finalSize);
                    block.Arrange(new Rect(new Point(sideLabelDesired.Height, pinTickY + block.DesiredSize.Height), block.DesiredSize));
                    pinTickY += lineSpace;
                }
                else if (string.Equals(block.Tag.ToString(), "x2Tick")) {
                    block.Measure(finalSize);
                    block.Arrange(new Rect(new Point(finalSize.Width - block.DesiredSize.Width - sideLabelDesired.Height, barTickY + block.DesiredSize.Height), block.DesiredSize));
                    barTickY += lineSpace;
                }
                else if (string.Equals(block.Tag.ToString(), "Label")) {
                    block.Width = bottomLabelDesired.Width;
                    block.Measure(finalSize);
                    block.Arrange(new Rect(new Point(labelSpace, 0), block.DesiredSize));
                    labelSpace += pinWidth;
                }
                else if (string.Equals(block.Tag.ToString(), "x1Label")) {
                    block.Width = availableHeight;
                    block.Measure(finalSize);
                    block.Arrange(new Rect(new Point(block.DesiredSize.Height, labelHeight), block.DesiredSize));
                }
                else if (string.Equals(block.Tag.ToString(), "x2Label")) {
                    block.Width = availableHeight;
                    block.Measure(finalSize);
                    block.Arrange(new Rect(new Point(finalSize.Width - block.DesiredSize.Height, labelHeight + availableHeight), block.DesiredSize));
                }
            }
        }

        return finalSize;
    }

    public IEnumerable ItemsSource {
        get { return (IEnumerable)GetValue(ItemsSourceProperty); }
        set { SetValue(ItemsSourceProperty, value); }
    }
    public static readonly DependencyProperty ItemsSourceProperty =
        DependencyProperty.Register("ItemsSource", typeof(IEnumerable), typeof(PinLineBarChart), new FrameworkPropertyMetadata() {
            DefaultValue = null,
            PropertyChangedCallback = onSourceChanged,
            AffectsArrange = true
        });

    static void onSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
        var o = d as PinLineBarChart;
        o.Children.Clear();
        if (e.NewValue is null) return;
        var list = (((IEnumerable<object>)e.NewValue).Cast<KeyTrippleValueSeries>()).ToList();
        o.generateChart(list);
    }
}
