﻿class EditHeadVM : EditBaseVM<Head>
{
    protected override CollectionViewSource cvs => new CollectionViewSource() {
        Source = AppData.heads,
        IsLiveSortingRequested = true,
        LiveSortingProperties = { nameof(IHaveName.Name) }
    };

    protected override Head clone() {
        return new Head() {
            Id = Selected.Id,
            Name = Selected.Name
        };
    }
    protected override async void update() {
        var request = new CDRMRequest() {
            UserId = App.service.UserId,
            Method = (int)Function.EditHead,
            Args = new object[] {
                new NetHead() {
                    Id = Edited.Id,
                    Name = Edited.Name
                }
            }
        };
        var response = await App.service.GetResponse(request);
    }
}
