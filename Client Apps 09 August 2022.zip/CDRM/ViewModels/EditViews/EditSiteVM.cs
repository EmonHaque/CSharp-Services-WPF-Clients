﻿class EditSiteVM : EditBaseVM<Site>
{
    protected override CollectionViewSource cvs => new CollectionViewSource() {
        Source = AppData.sites,
        IsLiveSortingRequested = true,
        LiveSortingProperties = { nameof(IHaveName.Name) }
    };

    protected override Site clone() {
        return new Site() {
            Id = Selected.Id,
            Name = Selected.Name,
            Address = Selected.Address
        };
    }
    protected override async void update() {
        var request = new CDRMRequest() {
            UserId = App.service.UserId,
            Method = (int)Function.EditSite,
            Args = new object[] { 
                new NetSite() {
                    Id = Edited.Id,
                    Name = Edited.Name,
                    Address = Edited.Address
                }
            }
        };
        var response = await App.service.GetResponse(request);
    }
}
