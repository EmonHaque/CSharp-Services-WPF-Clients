﻿class NotesVM : Notifiable
{
    public double Top { get; set; }
    public double Left { get; set; }
    public double Width { get; set; }
    public double Height { get; set; }

    ObservableCollection<EntryNoteText> reportables;
    string query;
    public string Query {
        get { return query; }
        set { query = value; Reportables.Refresh(); }
    }
    EntryNoteText selected;
    public EntryNoteText Selected {
        get { return selected; }
        set {
            selected = value;
            if (IsOnEdit) {
                IsOnEdit = false;
                OnPropertyChanged(nameof(IsOnEdit));
            }
        }
    }
    public EntryNoteText Edited { get; set; }
    public bool IsOnEdit { get; set; }
    public ICollectionView Reportables { get; set; }
    public event Action CoordinateRequested;

    public NotesVM() {
        reportables = new ObservableCollection<EntryNoteText>();
        Reportables = new CollectionViewSource() {
            Source = reportables,
            IsLiveGroupingRequested = true,
            LiveGroupingProperties = { nameof(EntryNoteText.Site), nameof(EntryNoteText.NoteType) },
            GroupDescriptions = {
                new PropertyGroupDescription(nameof(EntryNoteText.Site)),
                new PropertyGroupDescription(nameof(EntryNoteText.NoteType))
            }
        }.View;
        Reportables.Filter = filter;
        getNotes();

        ((App)Application.Current).appData.NoteAdded += onNoteAdded;
        ((App)Application.Current).appData.NoteEdited += onNoteEdited;
        ((App)Application.Current).appData.NoteDeleted += onNoteDeleted;
    }

    void onNoteAdded(NetNote n) {
        reportables.Add(new EntryNoteText() {
            Id = n.Id,
            Date = DateTime.ParseExact(n.Date, "yyyy-MM-dd", CultureInfo.CurrentCulture.DateTimeFormat),
            Entry = n.Entry,
            NoteType = AppData.noteTypes.First(x => x.Id == n.NoteTypeId).Name,
            Site = AppData.sites.First(x => x.Id == n.SiteId).Name
        });
    }
    void onNoteEdited(NetNote n) {
        var note = reportables.FirstOrDefault(x => x.Id == n.Id);
        if (note is not null) { // will it ever be null?
            note.Date = DateTime.ParseExact(n.Date, "yyyy-MM-dd", CultureInfo.CurrentCulture.DateTimeFormat);
            note.Entry = n.Entry;
            note.NoteType = AppData.noteTypes.First(x => x.Id == n.NoteTypeId).Name;
            note.Site = AppData.sites.First(x => x.Id == n.SiteId).Name;
            note.OnPropertyChanged(null);
        }
    }
    void onNoteDeleted(int id) {
        var note = reportables.FirstOrDefault(x => x.Id == id);
        if (note is not null) { // will it ever be null?
            reportables.Remove(note);
        }
    }

    public void Refresh() => getNotes();
    public async void Delete() {
        if (Selected is null) return;
        var request = new CDRMRequest() {
            UserId = App.service.UserId,
            Method = (int)Function.DeleteNote,
            Args = new object[] { Selected.Id }
        };
        var response = await App.service.GetResponse(request);
    }
    public void Edit() {
        if (Selected is null) return;
        Edited = new EntryNoteText() {
            Id = Selected.Id,
            Date = Selected.Date,
            NoteType = Selected.NoteType,
            Site = Selected.Site,
            Entry = Selected.Entry
        };
        IsOnEdit = true;
        OnPropertyChanged(nameof(IsOnEdit));
        OnPropertyChanged(nameof(Edited));
    }
    public void Cancel() {
        IsOnEdit = false;
        OnPropertyChanged(nameof(IsOnEdit));
    }
    public async void Save() {
        if (Selected is null) return;
        var validator = new NoteValidator(Edited);
        if (!validator.IsValid()) {
            CoordinateRequested?.Invoke();
            var errorDialog = new ErrorDialog(Left, Top, Width, Height, validator.Errors);
            errorDialog.ShowDialog();
            return;
        }
        if (validator.IsEqual(Selected)) return;

        var note = new NetNote() {
            Id = Edited.Id,
            Date = Edited.Date.Value.ToString("yyyy-MM-dd"),
            Entry = Edited.Entry
        };
        var request = new CDRMRequest() { UserId = App.service.UserId };
        Response response = null;

        if (!validator.DoesExist()) {
            CoordinateRequested?.Invoke();
            var confirmDialog = new ConfirmCreationDialog(Left, Top, Width, Height, validator.Errors);
            var result = confirmDialog.ShowDialog();
            if (!result.HasValue) return;
            if (!result.Value) return;

            foreach (var e in validator.Errors) {
                switch (e.Head) {
                    case nameof(Edited.Site): {
                            var dialog = new CreateSiteDialog(Left, Top, Width, Height, Edited.Site);
                            dialog.ShowDialog();
                            var site = new Site() {
                                Name = Edited.Site.Trim(),
                                Address = dialog.GetAddress().Trim()
                            };
                            request.Method = (int)Function.AddSite;
                            request.Args = new object[] { site };
                            response = await App.service.GetResponse(request);
                            note.SiteId = BitConverter.ToInt32(response.Packet.Skip(1).ToArray());
                        }
                        break;
                    case nameof(Edited.NoteType): {
                            var noteType = new NetNoteType() { Name = Edited.NoteType.Trim() };
                            request.Method = (int)Function.AddNoteType;
                            request.Args = new object[] { noteType };
                            response = await App.service.GetResponse(request);
                            note.NoteTypeId = BitConverter.ToInt32(response.Packet.Skip(1).ToArray());
                        }
                        break;
                }
            }
        }

        if(note.SiteId == 0) note.SiteId = AppData.GetSite().Id;
        if(note.NoteTypeId == 0) note.NoteTypeId = AppData.GetNoteType().Id;

        request.Method = (int)Function.EditNote;
        request.Args = new object[] { note };
        await App.service.GetResponse(request);

        IsOnEdit = false;
    }

    bool filter(object o) {
        if (string.IsNullOrWhiteSpace(Query)) return true;
        return ((EntryNoteText)o).Entry.Contains(Query, StringComparison.InvariantCultureIgnoreCase);
    }
    Task addNotes(byte[] packet) {
        reportables.Clear();
        var bytes = new ReadOnlySpan<byte>(packet);
        int read, start, index;
        start = read = index = 0;
        var segments = new string[4];
        while (read < bytes.Length) {
            int id = BitConverter.ToInt32(bytes.Slice(start, 4));
            read += 4;
            start = read;
            while (read < bytes.Length) {
                if (bytes[read] != 0) {
                    read++;
                    continue;
                }
                segments[index++] = Encoding.ASCII.GetString(bytes.Slice(start, read - start));
                start = ++read;
                if (index == segments.Length) break;
            }
            reportables.Add(new EntryNoteText() {
                Id = id,
                Date = DateTime.ParseExact(segments[0], "yyyy-MM-dd", CultureInfo.CurrentCulture.DateTimeFormat),
                NoteType = segments[1],
                Site = segments[2],
                Entry = segments[3]
            });
            index = 0;
        }
        return Task.CompletedTask;
    }
    async void getNotes() {
        var request = new CDRMRequest() {
            UserId = App.service.UserId,
            Method = (int)Function.GetNotes
        };
        var response = await App.service.GetResponse(request);
        await addNotes(response.Packet);
    }
}
