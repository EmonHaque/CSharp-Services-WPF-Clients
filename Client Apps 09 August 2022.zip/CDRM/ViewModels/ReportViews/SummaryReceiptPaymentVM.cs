﻿class SummaryReceiptPaymentVM : Notifiable
{
    DateTime from, to;
    Type sumType;
    PropertyInfo primaryProperty, secondaryProperty;
    Predicate<SumReceiptPayment> queryCondition;
    Func<SumReceiptPayment, ReceiptPayment, bool> sumCondition;
    List<ReceiptPayment> entries;
    ObservableCollection<SumReceiptPayment> reportables;
    string query;
    public string Query {
        get { return query; }
        set { query = value; Reportables.Refresh(); }
    }
    public int TotalPayment { get; set; }
    public int TotalReceipt { get; set; }
    public int TotalGroup { get; set; }
    public byte Group { get; set; }
    public ICollectionView Reportables { get; set; }
    public event Action CoordinateRequested;

    public SummaryReceiptPaymentVM() {
        entries = new List<ReceiptPayment>();
        reportables = new ObservableCollection<SumReceiptPayment>();
        from = to = DateTime.Today;
        sumType = typeof(ReceiptPayment);
        Reportables = CollectionViewSource.GetDefaultView(reportables);
        Reportables.GroupDescriptions.Add(new PropertyGroupDescription(nameof(SumReceiptPayment.PrimaryGroup)));
        Reportables.Filter = filter;
        Reportables.CollectionChanged += onCollectionChanged;
        SummaryPurchaseSellVM.Refreshed += onRefreshed;
    }

    public void Refresh() {
        //if (!SummaryReceiptPayment.IsHidden) {
        //    CoordinateRequested?.Invoke();
        //    BusyWindow.Activate(SummaryReceiptPayment.Left, SummaryReceiptPayment.Top, SummaryReceiptPayment.Width,
        //    SummaryReceiptPayment.Height, "Refreshing");
        //}
        getEntries();
        setCondition();
        makeSummary();
        //if(!SummaryReceiptPayment.IsHidden) BusyWindow.Terminate();
    }
    public void SortParticulars() => sort(nameof(SumReceiptPayment.PrimaryGroup), nameof(SumReceiptPayment.SecondaryGroup));
    public void SortPayments() => sort(nameof(SumReceiptPayment.Payment), nameof(SumReceiptPayment.TotalPayment));
    public void SortReceipts() => sort(nameof(SumReceiptPayment.Receipt), nameof(SumReceiptPayment.TotalReceipt));

    bool filter(object o) {
        if (string.IsNullOrWhiteSpace(Query)) return true;
        return queryCondition.Invoke((SumReceiptPayment)o);
    }
    ListSortDirection getDirection(string primaryProperty) {
        var direction = primaryProperty.Equals(nameof(SumReceiptPayment.PrimaryGroup)) ?
            ListSortDirection.Ascending :
            ListSortDirection.Descending;
        var description = Reportables.SortDescriptions.FirstOrDefault(x => x.PropertyName.Equals(primaryProperty));
        if (description.PropertyName is not null) {
            direction = description.Direction == ListSortDirection.Descending ?
                ListSortDirection.Ascending :
                ListSortDirection.Descending;
        }
        return direction;
    }
    void sort(string directionalProperty, string property) {
        if (Reportables.IsEmpty) return;
        var direction = getDirection(directionalProperty);
        using (Reportables.DeferRefresh()) {
            Reportables.SortDescriptions.Clear();
            if (directionalProperty.Equals(nameof(SumReceiptPayment.PrimaryGroup))) {
                Reportables.SortDescriptions.Add(new SortDescription(directionalProperty, direction));
                Reportables.SortDescriptions.Add(new SortDescription(property, direction));
            }
            else {
                Reportables.SortDescriptions.Add(new SortDescription(property, direction));
                Reportables.SortDescriptions.Add(new SortDescription(directionalProperty, direction));
            }
        }
    }
    void setCondition() {
        var month = sumType.GetProperty(nameof(ReceiptPayment.Month));
        var party = sumType.GetProperty(nameof(ReceiptPayment.Party));
        switch (Group) {
            case 0: // Month
                primaryProperty = month;
                secondaryProperty = party;
                sumCondition = (s, d) => s.PrimaryGroup.Equals(d.Month) && s.SecondaryGroup.Equals(d.Party);
                queryCondition = x => x.SecondaryGroup.Contains(Query, StringComparison.InvariantCultureIgnoreCase);
                break;
            default: // Party
                primaryProperty = party;
                secondaryProperty = month;
                sumCondition = (s, d) => s.PrimaryGroup.Equals(d.Party) && s.SecondaryGroup.Equals(d.Month);
                queryCondition = x => x.PrimaryGroup.Contains(Query, StringComparison.InvariantCultureIgnoreCase);
                break;
        }
    }
    void onRefreshed(ReportDates d) {
        from = d.From.Value;
        to = d.To.Value;
        Refresh();
    }
    void onCollectionChanged(object? sender, NotifyCollectionChangedEventArgs e) {
        TotalPayment = TotalReceipt = 0;
        foreach (SumReceiptPayment s in Reportables) {
            TotalPayment += s.Payment;
            TotalReceipt += s.Receipt;
        }
        TotalGroup = Reportables.Groups.Count;
        OnPropertyChanged(nameof(TotalPayment));
        OnPropertyChanged(nameof(TotalReceipt));
        OnPropertyChanged(nameof(TotalGroup));
    }
    void makeSummary() {
        List<SumReceiptPayment> sums = new();
        SumReceiptPayment group = null;
        foreach (var e in entries) {
            group = sums.FirstOrDefault(x => sumCondition.Invoke(x, e));
            if (group is null) {
                group = new SumReceiptPayment() {
                    PrimaryGroup = primaryProperty.GetValue(e, null).ToString(),
                    SecondaryGroup = secondaryProperty.GetValue(e, null).ToString(),
                    Payment = e.Payment,
                    Receipt = e.Receipt,
                    Count = 1,
                    Entries = new List<RPToolTipEntry>()
                };
                sums.Add(group);
            }
            else {
                group.Receipt += e.Receipt;
                group.Payment += e.Payment;
                group.Count++;
            }
            group.Entries.Add(new RPToolTipEntry() {
                Date = e.Date,
                Payment = e.Payment,
                Receipt = e.Receipt,
                IsCash = e.IsCash,
                Head = e.Head
            });
        }
        foreach (var item in sums) {
            int currentReceipt = 0;
            int currentPayment = 0;
            var groups = sums.Where(x => x.PrimaryGroup.Equals(item.PrimaryGroup)).ToList();
            if(groups.Count > 0) {
                foreach (var g in groups) {
                    currentPayment += g.Payment;
                    currentReceipt += g.Receipt;
                }
                item.TotalReceipt = currentReceipt;
                item.TotalPayment = currentPayment;
            }
            else {
                item.TotalReceipt = item.Receipt;
                item.TotalPayment = item.Payment;
            }
        }
        using (Reportables.DeferRefresh()) {
            Reportables.CollectionChanged -= onCollectionChanged;
            Reportables.Filter = null;
            reportables.Clear();
        }
        TotalReceipt = TotalPayment = 0;
        foreach (var item in sums) {
            TotalPayment += item.Payment;
            TotalReceipt += item.Receipt;
            reportables.Add(item);
        }
        Reportables.Filter = filter;
        Reportables.CollectionChanged += onCollectionChanged;
        TotalGroup = Reportables.Groups.Count;

        OnPropertyChanged(nameof(TotalPayment));
        OnPropertyChanged(nameof(TotalReceipt));
        OnPropertyChanged(nameof(TotalGroup));
    }
    Task addEntries(byte[] packet) {
        var bytes = new ReadOnlySpan<byte>(packet);
        int read, start, index;
        start = read = index = 0;
        var segments = new string[5];

        while (read < bytes.Length) {
            var payment = BitConverter.ToInt32(bytes.Slice(start, 4));
            var receipt = BitConverter.ToInt32(bytes.Slice(start + 4, 4));
            var isCash = bytes.Slice(start + 8, 1)[0];
            read += 9;
            start += 9;
            while (read < bytes.Length) {
                if (bytes[read] != 0) {
                    read++;
                    continue;
                }
                segments[index++] = Encoding.ASCII.GetString(bytes.Slice(start, read - start));
                if (index == segments.Length) break;
                start = ++read;
            }
            entries.Add(new ReceiptPayment() {
                Payment = payment,
                Receipt = receipt,
                IsCash = isCash,
                Date = DateTime.ParseExact(segments[0], "yyyy-MM-dd", CultureInfo.CurrentCulture.DateTimeFormat),
                Party = segments[1],
                Head = segments[2],
                Narration = segments[3],
                Month = segments[4]
            });
            index = 0;
            start = ++read;
        }
        return Task.CompletedTask;
    }
    async void getEntries() {
        entries.Clear();
        var request = new CDRMRequest() {
            UserId = App.service.UserId,
            Method = (int)Function.GetReceiptPayment,
            Args = new object[] {
                from.ToString("yyyy-MM-dd"),
                to.ToString("yyyy-MM-dd")
            }
        };
        var response = await App.service.GetResponse(request);
        if (!response.IsSuccess) {
            //message
            return;
        }
        await addEntries(response.Packet);
    }
}
