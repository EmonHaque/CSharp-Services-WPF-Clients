﻿public enum CalendarState
{
    Day,
    Month,
    Year
}
