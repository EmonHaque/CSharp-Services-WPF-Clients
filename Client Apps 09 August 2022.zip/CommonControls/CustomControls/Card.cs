﻿public class Card : Border
{
    Grid container, headerContainer;
    TextBlock headerBlock;
    Separator divider;
    UIElement content;
    StackPanel tools;
    public UIElement Content {
        get { return content; }
        set {
            content = value;
            Grid.SetRow(value, 1);
            container.Children.Add(value);
        }
    }
    string header;
    public string Header {
        get { return header; }
        set {
            header = value;
            if (!string.IsNullOrWhiteSpace(value)) {
                headerBlock.Text = value;
                headerContainer.Visibility = Visibility.Visible;
            }
        }
    }

    public Card() {
        initializeHeader();
        container = new Grid() {
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition()
            },
            Children = { headerContainer }
        };
        Margin = new Thickness(Constants.CardMargin);
        Padding = new Thickness(5);
        CornerRadius = new CornerRadius(5);
        Background = Constants.Background;
        Child = container;
    }
    
    void initializeHeader() {
        headerBlock = new TextBlock() { FontSize = 16 };
        tools = new StackPanel() { Orientation = Orientation.Horizontal };
        divider = new Separator() {
            Margin = new Thickness(0, 0, 0, 5),
            Height = 0.5,
            Background = Brushes.LightGray
        };
        Grid.SetColumn(tools, 1);
        Grid.SetRow(divider, 1);
        Grid.SetColumnSpan(divider, 2);
        headerContainer = new Grid() {
            Visibility = Visibility.Collapsed,
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = GridLength.Auto }
            },
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto }
            },
            Children = { headerBlock, tools, divider }
        };
    }
    public void AddActions(ActionButton action) {
        tools.Children.Add(action);
    }
    public void AddActions(UIElement[] actions) {
        foreach (var action in actions) {
            tools.Children.Add(action);
        }
    }
    protected override Size MeasureOverride(Size constraint) {
        var width = constraint.Width - Padding.Left - Padding.Right;
        var height = constraint.Height - Padding.Top - Padding.Bottom;
        container.Width = width > 0 ? width : 0;
        container.Height = height > 0 ? height : 0;
        return constraint;
    }
}