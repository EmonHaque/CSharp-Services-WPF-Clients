﻿public class DependencyButton<T> : Border
{
    protected SolidColorBrush brush;
    protected ColorAnimation anim;
    protected Color normalColor, highlightColor, downColor;
    public DependencyButton() {
        Focusable = true;
        normalColor = Colors.CornflowerBlue;
        highlightColor = Colors.Coral;
        downColor = Colors.Red;
        brush = new SolidColorBrush(normalColor);

        Background = Brushes.Transparent;
        Child = new Path() {
            Fill = brush,
            Stretch = Stretch.Uniform
        };
        anim = new ColorAnimation() {
            Duration = TimeSpan.FromSeconds(0.5),
            EasingFunction = new CubicEase() { EasingMode = EasingMode.EaseInOut }
        };
        FocusVisualStyle = null;
    }
    protected void animateBrush(Color color) {
        anim.To = color;
        brush.BeginAnimation(SolidColorBrush.ColorProperty, anim);
    }
    protected override void OnMouseEnter(MouseEventArgs e) => animateBrush(highlightColor);
    protected override void OnMouseLeave(MouseEventArgs e) => animateBrush(normalColor);
    protected override void OnMouseUp(MouseButtonEventArgs e) => Command.Invoke(Parameter);
    protected override void OnMouseDown(MouseButtonEventArgs e) => animateBrush(downColor);

    public Action<T> Command {
        get { return (Action<T>)GetValue(CommandProperty); }
        set { SetValue(CommandProperty, value); }
    }
    public T Parameter {
        get { return (T)GetValue(ParameterProperty); }
        set { SetValue(ParameterProperty, value); }
    }
    public string Icon {
        get { return (string)GetValue(IconProperty); }
        set { SetValue(IconProperty, value); }
    }
    public static readonly DependencyProperty CommandProperty =
        DependencyProperty.Register("Command", typeof(Action<T>), typeof(DependencyButton<T>), new PropertyMetadata(null));

    public static readonly DependencyProperty ParameterProperty =
        DependencyProperty.Register("Parameter", typeof(T), typeof(DependencyButton<T>), new PropertyMetadata(null));

    public static readonly DependencyProperty IconProperty =
        DependencyProperty.Register("Icon", typeof(string), typeof(DependencyButton<T>), new PropertyMetadata(null, onIconChanged));

    static void onIconChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
        var o = d as DependencyButton<T>;
        ((Path)o.Child).Data = Geometry.Parse(e.NewValue.ToString());
    }
}
