#include "List.h"

void addToList(List* list, void* item) {
	((void**)list->data)[list->count++] = item;
	if (list->capacity == list->count) {
		list->capacity *= 2;
		list->data = realloc(list->data, list->capacity * POINTER_SIZE);
	}
}
void removeFromList(List* list, void* item) {
	int index = 0;
	void** li = list->data;
	for (size_t i = 0; i < list->count; i++) {
		if (li[i] == item) {
			index = i;
			break;
		}
	}
	//free(item);
	list->count--;
	for (size_t i = index; i < list->count; i++) {
		li[i] = li[i + 1];
	}
	//if((list->capacity - list->count) > 500) resize
}
