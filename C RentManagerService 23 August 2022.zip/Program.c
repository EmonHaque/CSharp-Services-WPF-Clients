#pragma comment (lib, "Ws2_32.lib")
#pragma comment (lib, "sqlite3.lib")
#include "Program.h"

#pragma region variables
wchar_t SERVICE_NAME[10];
SERVICE_STATUS g_ServiceStatus = { 0 };
SERVICE_STATUS_HANDLE g_StatusHandle = NULL;
HANDLE g_ServiceStopEvent = INVALID_HANDLE_VALUE;
SOCKET server;
CRITICAL_SECTION criticalSender, criticalReceiver;
byte isRunning;
List receivers, senders;
BlockingQueue requests;
HANDLE serviceThread, acceptClientThread, broadcastThread;
#pragma endregion

int main() {
#ifdef _DEBUG
	Initialize();
	g_ServiceStopEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	serviceThread = CreateThread(NULL, 0, ServiceWorker, NULL, 0, NULL);
	WaitForSingleObject(serviceThread, INFINITE);
#else
	SERVICE_TABLE_ENTRY entry[] = {
		{SERVICE_NAME, (LPSERVICE_MAIN_FUNCTION)ServiceMain},
		{NULL, NULL}
	};
	StartServiceCtrlDispatcher(entry);
#endif
	return 0;
}
void ServiceMain(ulong argc, ulong* argv) {
	OnStarting();
	Initialize();
	// Create a service stop event to wait on later
	g_ServiceStopEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	OnStarted();
	// Start a thread that will perform the main task of the service
	serviceThread = CreateThread(NULL, 0, ServiceWorker, NULL, 0, NULL);
	// Wait until our worker thread exits signaling that the service needs to stop
	WaitForSingleObject(serviceThread, INFINITE);
	//Perform any cleanup tasks
	CloseHandle(g_ServiceStopEvent);
	onStopped();
}
void ServiceCtrlHandler(ulong code) {
	switch (code) {
		case SERVICE_CONTROL_STOP:
			if (g_ServiceStatus.dwCurrentState != SERVICE_RUNNING)
				break;
			//Perform tasks necessary to stop the service here
			Cleanup();
			OnStopping();
			// This will signal the worker thread to start shutting down
			SetEvent(g_ServiceStopEvent);
			break;
	}
}
ulong ServiceWorker(void* p) {
	//  Periodically check if the service has been requested to stop
	while (WaitForSingleObject(g_ServiceStopEvent, 0) != WAIT_OBJECT_0)
		//Perform main service function here
		AcceptClient();

	return 0;
}
ulong EnqueueRequest(void* p) {
	SOCKET client = p;
	byte isConnected = 1;
	char header[4];
	int packetSize, read, newRead;

	while (isConnected) {
		read = recv(client, header, 4, 0);
		if (read < 0) {
			isConnected = 0;
			break;
		}
		while (read < 4) {
			newRead = recv(client, &header[read], 4 - read, 0);
			if (newRead < 0) {
				isConnected = 0;
				break;
			}
			read += newRead;
		}
		memcpy(&packetSize, header, 4);
		Request* r = malloc(REQUEST_SIZE);
		r->sender = client;
		r->length = packetSize;
		r->packet = malloc(packetSize);
		read = newRead = 0;
		while (read < packetSize) {
			newRead = recv(client, r->packet, packetSize - read, 0);
			if (newRead < 0) {
				isConnected = 0;
				break;
			}
			read += newRead;
		}
		memcpy(&r->userId, &r->packet[0], 4);
		memcpy(&r->function, &r->packet[4], 4);
		putIn(&requests, r);
	}
	EnterCriticalSection(&criticalSender);
	Sender** list = senders.data;
	Sender* s = 0;
	for (size_t i = 0; i < senders.count; i++) {
		if (list[i]->socket == client) {
			s = list[i];
			break;
		}
	}
	closesocket(client);
	CloseHandle(s->thread);
	removeFromList(&senders, s);
	free(s);
	LeaveCriticalSection(&criticalSender);
	return 0;
}
void OnStarting() {
	// Register our service control handler with the SCM
	g_StatusHandle = RegisterServiceCtrlHandler(SERVICE_NAME, ServiceCtrlHandler);
	// Tell the service controller we are starting
	ZeroMemory(&g_ServiceStatus, sizeof(g_ServiceStatus));
	g_ServiceStatus.dwServiceType = SERVICE_WIN32_OWN_PROCESS;
	g_ServiceStatus.dwControlsAccepted = 0;
	g_ServiceStatus.dwCurrentState = SERVICE_START_PENDING;
	g_ServiceStatus.dwWin32ExitCode = 0;
	g_ServiceStatus.dwServiceSpecificExitCode = 0;
	g_ServiceStatus.dwCheckPoint = 0;
	SetServiceStatus(g_StatusHandle, &g_ServiceStatus);
}
void OnStarted() {
	// Tell the service controller we are started
	g_ServiceStatus.dwControlsAccepted = SERVICE_ACCEPT_STOP;
	g_ServiceStatus.dwCurrentState = SERVICE_RUNNING;
	g_ServiceStatus.dwWin32ExitCode = 0;
	g_ServiceStatus.dwCheckPoint = 0;
	SetServiceStatus(g_StatusHandle, &g_ServiceStatus);
}
void OnStopping() {
	g_ServiceStatus.dwControlsAccepted = 0;
	g_ServiceStatus.dwCurrentState = SERVICE_STOP_PENDING;
	g_ServiceStatus.dwWin32ExitCode = 0;
	g_ServiceStatus.dwCheckPoint = 4;
	SetServiceStatus(g_StatusHandle, &g_ServiceStatus);
}
void onStopped() {
	// Tell the service controller we are stopped
	g_ServiceStatus.dwControlsAccepted = 0;
	g_ServiceStatus.dwCurrentState = SERVICE_STOPPED;
	g_ServiceStatus.dwWin32ExitCode = 0;
	g_ServiceStatus.dwCheckPoint = 3;
	SetServiceStatus(g_StatusHandle, &g_ServiceStatus);
}
void Initialize() {
	WSADATA w;
	WSAStartup(MAKEWORD(2, 2), &w);
	SOCKADDR_IN address = { AF_INET, htons(5557) };
	InetPton(AF_INET, L"127.0.0.1", &address.sin_addr.s_addr);
	server = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	bind(server, &address, sizeof(address));
	listen(server, SOMAXCONN);
	isRunning = 1;

	receivers.capacity = senders.capacity = 5;
	receivers.count = senders.count = 0;
	receivers.data = malloc(receivers.capacity * SENDER_SIZE);
	senders.data = malloc(senders.capacity * SENDER_SIZE);

	requests.count = 0;
	requests.capacity = 5;
	requests.data = malloc(requests.capacity * POINTER_SIZE);
	requests.manualResetEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	InitializeCriticalSection(&requests.section);

	InitializeCriticalSection(&criticalSender);
	InitializeCriticalSection(&criticalReceiver);

	initializeDatabase();
	initializeDispatcher();
	initializeBroadcaster();
}
void AcceptClient() {
	while (isRunning) {
		SOCKADDR_IN from;
		int length = sizeof(from);
		SOCKET client = accept(server, &from, &length);
		char ipv4[INET_ADDRSTRLEN];
		inet_ntop(AF_INET, &(from.sin_addr), ipv4, INET_ADDRSTRLEN);
		BOOL b = TRUE;
		setsockopt(client, IPPROTO_TCP, TCP_NODELAY, &b, sizeof(BOOL));

		byte isReceiver;
		int read = recv(client, &isReceiver, 1, 0);
		if (isReceiver) {
			EnterCriticalSection(&criticalReceiver);
			addToList(&receivers, client);
			LeaveCriticalSection(&criticalReceiver);
		}
		else {
			EnterCriticalSection(&criticalSender);
			HANDLE requestThread = CreateThread(NULL, 0, EnqueueRequest, client, 0, NULL);
			Sender* s = malloc(SENDER_SIZE);
			s->socket = client;
			s->thread = requestThread;
			addToList(&senders, s);
			LeaveCriticalSection(&criticalSender);
		}
	}
}
void Cleanup() {
	isRunning = 0;
	closesocket(server);
	WSACleanup();
}