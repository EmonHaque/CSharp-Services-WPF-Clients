#pragma once
#include <winsock2.h>
#include <ws2tcpip.h>
#include <tchar.h>
#include "Database.h"
#include "Dispatcher.h"
#include "Broadcaster.h"

extern wchar_t SERVICE_NAME[10];
extern SERVICE_STATUS g_ServiceStatus;
extern SERVICE_STATUS_HANDLE g_StatusHandle;
extern HANDLE g_ServiceStopEvent;

extern SOCKET server;
extern byte isRunning;
extern List receivers, senders;
extern CRITICAL_SECTION criticalSender, criticalReceiver;
extern BlockingQueue requests;
extern HANDLE serviceThread, acceptClientThread;

void ServiceMain(ulong, ulong*);
void ServiceCtrlHandler(ulong);
ulong ServiceWorker(void*);
ulong EnqueueRequest(void*);

void OnStarting();
void Initialize();
void OnStarted();
void AcceptClient();
void Cleanup();
void OnStopping();
void onStopped();