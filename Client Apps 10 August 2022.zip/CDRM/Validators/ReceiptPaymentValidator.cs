﻿class ReceiptPaymentValidator
{
    EntryReceiptPaymentText entry;
    public List<ValidationError> Errors { get; set; }

    public ReceiptPaymentValidator() { }
    public ReceiptPaymentValidator(EntryReceiptPaymentText entry) {
        this.entry = entry;
    }

    public bool DoesExist() {
        if (!AppData.HasParty(entry.Party)) {
            Errors.Add(new ValidationError() {
                Head = "Party",
                Error = Constants.DoesntExist
            });
        }
        if (!AppData.HasHead(entry.Head)) {
            Errors.Add(new ValidationError() {
                Head = "Head",
                Error = Constants.DoesntExist
            });
        }
        return Errors.Count == 0;
    }
    public bool IsEqual(EntryReceiptPaymentText e) {
        if (e.IsReceipt != entry.IsReceipt) {
            if (e.IsReceipt == 0) entry.Title = "Receipt";
            else entry.Title = "Payment";
            return false;
        }
        if (e.Date != entry.Date) return false;
        if (e.IsCash != entry.IsCash) return false;
        if (!e.Head.Equals(entry.Head, StringComparison.InvariantCultureIgnoreCase)) return false;
        if (!e.Party.Equals(entry.Party, StringComparison.InvariantCultureIgnoreCase)) return false;
        if (!e.Narration.Equals(entry.Narration, StringComparison.InvariantCultureIgnoreCase)) return false;

        int originalAmount, editedAmount;
        int.TryParse(e.Amount, NumberStyles.Number, CultureInfo.CurrentCulture.NumberFormat, out originalAmount);
        int.TryParse(entry.Amount, NumberStyles.Number, CultureInfo.CurrentCulture.NumberFormat, out editedAmount);
        if (originalAmount != editedAmount) return false;

        return true;
    }
    public bool IsValid() {
        Errors = new List<ValidationError>();
        if (entry.Date is null) {
            Errors.Add(new ValidationError() {
                Head = nameof(entry.Date),
                Error = Constants.CannotBeEmpty
            });
        }
        if (string.IsNullOrWhiteSpace(entry.Party)) {
            Errors.Add(new ValidationError() {
                Head = nameof(entry.Party),
                Error = Constants.CannotBeEmpty
            });
        }
        if (string.IsNullOrWhiteSpace(entry.Head)) {
            Errors.Add(new ValidationError() {
                Head = nameof(entry.Head),
                Error = Constants.CannotBeEmpty
            });
        }

        if (string.IsNullOrWhiteSpace(entry.Amount)) {
            Errors.Add(new ValidationError() {
                Head = nameof(entry.Amount),
                Error = Constants.CannotBeEmpty
            });
        }
        else {
            int x;
            if (!int.TryParse(entry.Amount, NumberStyles.Number, CultureInfo.CurrentCulture.NumberFormat, out x)) {
                Errors.Add(new ValidationError() {
                    Head = nameof(entry.Amount),
                    Error = Constants.IsntValid
                });
            }
            else if (x <= 0) {
                Errors.Add(new ValidationError() {
                    Head = nameof(entry.Amount),
                    Error = Constants.MustBePositive
                });
            }
        }
        return Errors.Count == 0;
    }
}
