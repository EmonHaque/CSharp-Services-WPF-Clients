﻿class EditEntryGroupHeaderSelector : DataTemplateSelector
{
    public override DataTemplate SelectTemplate(object item, DependencyObject container) {
        if (item is EntryPurchaseSellText) return new PurchaseSellGroupTemplate();
        else return new ReceiptPaymentGroupTemplate();
    }
}
