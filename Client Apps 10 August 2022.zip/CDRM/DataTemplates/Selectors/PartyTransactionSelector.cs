﻿class PartyTransactionSelector : DataTemplateSelector
{
    public override DataTemplate SelectTemplate(object item, DependencyObject container) {
        var party = (SumPartyTransaction)item;
        if (party.IsSettled) return new PartyTransactionTemplate();
        else return new PartyBalanceTemplate();
    }
}
