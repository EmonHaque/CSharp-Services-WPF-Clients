﻿class CreateSiteDialog : Window
{
    EditText name, address;
    TextBlock info;
    ActionButton button;

    public CreateSiteDialog(double left, double top, double width, double height, string name) {
        Top = top;
        Left = left;
        Width = width;
        Height = height;
        Owner = App.Current.MainWindow;
        ShowInTaskbar = false;
        AllowsTransparency = true;
        WindowStyle = WindowStyle.None;
        ResizeMode = ResizeMode.NoResize;
        Background = new SolidColorBrush(Color.FromArgb(127, 0, 0, 0));
        WindowChrome.SetWindowChrome(this, new WindowChrome() {
            GlassFrameThickness = new Thickness(0),
            CornerRadius = new CornerRadius(7),
            ResizeBorderThickness = new Thickness(0),
            CaptionHeight = 0
        });

        initializeContent(name);
    }

    void initializeContent(string name) {
        var header = new TextBlock() {
            Margin = new Thickness(0, 0, 0, 10),
            FontSize = 18,
            Text = "Provide Address of the Site"
        };
        this.name = new EditText() {
            Hint = "Name",
            Icon = Icons.Plot,
            Text = name,
            IsEnabled = false
        };
        address = new EditText() {
            Hint = "Address",
            Icon = Icons.Address
        };
        info = new TextBlock() {
            Foreground = Brushes.Coral,
            HorizontalAlignment = HorizontalAlignment.Center
        };
        button = new ActionButton() {
            HorizontalAlignment = HorizontalAlignment.Right,
            ToolTip = "Ok",
            Width = 24,
            Height = 24,
            Margin = new Thickness(5, 10, 0, 0),
            Icon = Icons.Ok,
            Command = validate
        };
        Content = new Border() {
            CornerRadius = new CornerRadius(7),
            Padding = new Thickness(10),
            Background = Constants.Background,
            Width = this.Width * .8,
            HorizontalAlignment = HorizontalAlignment.Center,
            VerticalAlignment = VerticalAlignment.Center,
            Child = new StackPanel() {
                Children = { header, this.name, address, info, button }
            }
        };
    }
    void validate() {
        if (string.IsNullOrWhiteSpace(address.Text)) {
            info.Text = "provide Address";
            return;
        }
        DialogResult = true;
        Close();
    }
    public string GetAddress() => address.Text;
}
