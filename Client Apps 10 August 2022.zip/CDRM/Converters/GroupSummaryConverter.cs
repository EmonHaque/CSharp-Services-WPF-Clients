﻿class GroupSummaryConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) {
        int purchase, sell;
        purchase = sell = 0;
        var items = (ReadOnlyObservableCollection<object>)value;
        foreach (IPurchaseSell e in items) {
            purchase += e.Purchase;
            sell += e.Sell;
        }
        return new Tuple<int, int>(purchase, sell);
    }
    public object ConvertBack(object value, Type targetTypes, object parameter, CultureInfo culture) {
        throw new NotImplementedException();
    }
}
