﻿class App : ClientApp
{
    public AppData appData = new();
    protected override string appTitle => "CDRM";
    protected override IPAddress address => IPAddress.Parse(Addresses.CDRMAddress);
    protected override int port => Addresses.CDRMPort;
    protected override Request initRequest => new CDRMRequest() {
        UserId = service.UserId,
        Method = (int)Function.GetInitialData,
        Args = new object[] { "" }
    };
    protected override ImageSource image => null;
    protected override AppDataBase baseData => appData;

    const string appExeName = "CDRM";
    const string appVersion = "1.0";

    [STAThread]
    static void Main(string[] args) {
#if DEBUG 
        new App().Run();
#else
        if (args.Length == 0) {
            var lArg = new LaunchArgs() {
                App = appExeName,
                Version = appVersion,
                Path = AppDomain.CurrentDomain.BaseDirectory
            };
            var launchArg = $"\"{lArg.App},{lArg.Version},{lArg.Path}\"";
            var launcherPath = System.IO.Path.GetFullPath(System.IO.Path.Combine(lArg.Path, @"..\"));
            Process.Start(launcherPath + "\\Launcher.exe", launchArg);
        }
        else new App().Run();
#endif        
    }
    
    protected override void SetResourceAndShowWindow() {
        new Converters();
        Current.MainWindow = new RootWindow() {
            Content = new RootPanel() {
                Children = {
                    new HomeView(),
                    new EntryView(),
                    new EditView(),
                    new ReportView()
                }
            }
        };
        Current.MainWindow.Show();
    }
}

