﻿class ReportParty : CardView
{
    public override string Header => "Party";
    public override string Icon => Icons.Tenant;

    SelectItem items;
    DayPicker startDate, endDate;
    EditText query;
    CommandButton refresh, exportCSV, print;
    Ledger report;
    TextBlock title;
    ReportPartyVM vm;

    public override void OnFirstSight() {
        base.OnFirstSight();
        vm = new ReportPartyVM();
        DataContext = vm;
        initializeUI();
        bind();
    }
    void initializeUI() {
        items = new SelectItem() {
            Hint = Header,
            Icon = Icon,
            IsRequired = true,
            DisplayPath = nameof(IHaveName.Name),
            SelectedValuePath = "Id"
        };
        startDate = new DayPicker() {
            Hint = "from",
            DateFormat = "dd/MM/yyyy",
            IsRequired = true,
            MinWidth = 200
        };
        endDate = new DayPicker() {
            Hint = "to",
            DateFormat = "dd/MM/yyyy",
            IsRequired = true,
            MinWidth = 200
        };
        refresh = new CommandButton() {
            Icon = Icons.Refresh,
            VerticalAlignment = VerticalAlignment.Center,
            Command = vm.RefreshReport
        };
        exportCSV = new CommandButton() {
            Icon = Icons.CSV,
            Margin = new Thickness(5, 0, 5, 0),
            Command = vm.ExportCSV
        };
        print = new CommandButton() {
            Icon = Icons.Print,
            Command = vm.PrintReport
        };
        report = new Ledger();

        title = new TextBlock() {
            FontSize = 14,
            Margin = new Thickness(5, 0, 0, 0),
            VerticalAlignment = VerticalAlignment.Center
        };
        query = new EditText() {
            Hint = "Search",
            Icon = Icons.Search,
            IsTrimBottomRequested = true
        };
        Grid.SetColumn(query, 1);
        Grid.SetColumn(exportCSV, 2);
        Grid.SetColumn(print, 3);
        var titleGrid = new Grid() {
            ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = GridLength.Auto },
                    new ColumnDefinition(){ Width = GridLength.Auto }
                },
            Children = { title, query, exportCSV, print }
        };

        Grid.SetColumn(startDate, 1);
        Grid.SetColumn(endDate, 2);
        Grid.SetColumn(refresh, 3);
        Grid.SetRow(titleGrid, 1);
        Grid.SetColumnSpan(titleGrid, 4);
        Grid.SetRow(report, 2);
        Grid.SetColumnSpan(report, 4);
        var grid = new Grid() {
            RowDefinitions = {
                    new RowDefinition(){ Height = new GridLength(48) },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(),
                },
            ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(){ Width = GridLength.Auto },
                    new ColumnDefinition(){ Width = GridLength.Auto },
                    new ColumnDefinition(){ Width = GridLength.Auto }
                },
            Children = { items, startDate, endDate, refresh, titleGrid, report }
        };
        setContent(grid);
    }
    void bind() {
        items.SetBinding(SelectItem.SelectedvalueProperty, new Binding(nameof(vm.Id)));
        items.SetBinding(SelectItem.ItemsSourceProperty, new Binding(nameof(vm.SelectionView)));
        items.SetBinding(SelectItem.QueryProperty, new Binding(nameof(vm.PartyQuery)) { Mode = BindingMode.OneWayToSource });

        report.SetBinding(Ledger.ItemsSourceProperty, new Binding(nameof(vm.Reportables)));
        report.SetBinding(Ledger.SummaryProperty, new Binding(nameof(vm.Summary)));

        startDate.SetBinding(DayPicker.StartDateProperty, new Binding($"{nameof(vm.Dates)}.{nameof(ReportDates.Start)}"));
        startDate.SetBinding(DayPicker.EndDateProperty, new Binding($"{nameof(vm.Dates)}.{nameof(ReportDates.End)}"));
        startDate.SetBinding(DayPicker.SelectedDateProperty, new Binding($"{nameof(vm.Dates)}.{nameof(ReportDates.From)}"));

        endDate.SetBinding(DayPicker.StartDateProperty, new Binding($"{nameof(vm.Dates)}.{nameof(ReportDates.Start)}"));
        endDate.SetBinding(DayPicker.EndDateProperty, new Binding($"{nameof(vm.Dates)}.{nameof(ReportDates.End)}"));
        endDate.SetBinding(DayPicker.SelectedDateProperty, new Binding($"{nameof(vm.Dates)}.{nameof(ReportDates.To)}"));

        var binding = new Binding(nameof(vm.IsPrintOrExportValid));
        print.SetBinding(CommandButton.IsEnabledProperty, binding);
        exportCSV.SetBinding(CommandButton.IsEnabledProperty, binding);
        refresh.SetBinding(CommandButton.IsEnabledProperty, new Binding(nameof(vm.IsRefreshValid)));

        title.SetBinding(TextBlock.TextProperty, new Binding($"{nameof(vm.Header)}"));
        query.SetBinding(EditText.TextProperty, new Binding(nameof(vm.ReportQuery)) { Mode = BindingMode.OneWayToSource });
    }
}
