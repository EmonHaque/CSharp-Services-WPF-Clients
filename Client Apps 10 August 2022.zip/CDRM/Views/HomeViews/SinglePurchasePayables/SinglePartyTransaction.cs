﻿class SinglePartyTransaction : SinglePurchasePayables<Party>
{
    public override string Icon => Icons.Tenant;

    SinglePartyTransactionVM viewModel;
    PinLineBarChart pbc;
    protected override SinglePurchasePayableBaseVM<Party> vm => viewModel;
    protected override string hint => "Party";
    protected override void initialize() {
        viewModel = new SinglePartyTransactionVM();
        pbc = new PinLineBarChart();
    }
}
