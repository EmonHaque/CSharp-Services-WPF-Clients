﻿class SingleSitewisePurchaseVM : SinglePurchasePayableBaseVM<Site>
{
    protected override string type => "Site";
    protected override ObservableCollection<Site> source => AppData.sites;
}
