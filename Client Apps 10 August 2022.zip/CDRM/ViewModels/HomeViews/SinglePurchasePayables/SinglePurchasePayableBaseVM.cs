﻿abstract class SinglePurchasePayableBaseVM<T> : Notifiable where T : IHaveName
{
    CollectionViewSource selectionSource;
    protected int maxDataPoints = 15;
    protected int count, purchase, paid;
    string query;
    public string Query {
        get { return query; }
        set { query = value; SelectionView?.Refresh(); }
    }
    int? id;
    public int? Id {
        get { return id; }
        set { id = value; getEntries(); }
    }
    public byte State { get; set; }
    public string Total { get; set; }
    public ICollectionView SelectionView { get; }
    public object Data { get; set; }
    protected abstract ObservableCollection<T> source { get; }
    protected abstract string type { get; }

    public SinglePurchasePayableBaseVM() {
        selectionSource = new CollectionViewSource() { Source = source };
        SelectionView = selectionSource.View;
        SelectionView.Filter = filter;
    }

    public void Refresh() => getEntries();

    bool filter(object o) {
        if (string.IsNullOrWhiteSpace(Query)) return true;
        return ((T)o).Name.Contains(Query, StringComparison.InvariantCultureIgnoreCase);
    }
    async void getEntries() {
        int count;
        count = purchase = paid = 0;
        if (Id is null) {
            OnPropertyChanged(nameof(Data));
            OnPropertyChanged(nameof(Total));
            return;
        }
        var request = new CDRMRequest() {
            UserId = App.service.UserId,
            Method = type.Equals("Party") ? (int)Function.GetSinglePartyTransaction : (int)Function.GetSingleHeadOrSitewisePurchase,
            Args = new object[] {
                State,
                Id.Value,
                maxDataPoints,
                type,
            }
        };
        var response = await App.service.GetResponse(request);
        if (!response.IsSuccess) {
            //message
            return;
        }
        object data = type.Equals("Party") ?
            await getKeyTrippleValues(response.Packet) :
            await getKeyValues(response.Packet);

        Data = data;
      
        OnPropertyChanged(nameof(Total));
        OnPropertyChanged(nameof(Data));
    }

    Task<List<KeyValueSeries>> getKeyValues(byte[] packet) {
        var list = new List<KeyValueSeries>();
        var span = new ReadOnlySpan<byte>(packet);
        int read = 0;
        int start = 0;
        count = purchase = 0;
        while (read < span.Length) {
            while (span[read] != 0) read++;
            var series = new KeyValueSeries() {
                Key = Encoding.ASCII.GetString(span.Slice(start, read - start)),
                Value = BitConverter.ToInt32(span.Slice(read + 1, 4))
            };
            list.Add(series);
            count++;
            purchase += series.Value;
            read += 5;
            start = read;

        }
        Total = @"Purchase: " + purchase.ToString("N0") + " in " + count.ToString() + (State == 0 ? " days" : " months");
        return Task.FromResult(list);
    }
    Task<List<KeyTrippleValueSeries>> getKeyTrippleValues(byte[] packet) {
        var list = new List<KeyTrippleValueSeries>();
        var span = new ReadOnlySpan<byte>(packet);
        int read = 0;
        int start = 0;
        count = purchase = paid = 0;
        while (read < span.Length) {
            while (span[read] != 0) read++;
            var series = new KeyTrippleValueSeries() {
                Key = Encoding.ASCII.GetString(span.Slice(start, read - start)),
                Value1 = BitConverter.ToInt32(span.Slice(read + 1, 4)),
                Value2 = BitConverter.ToInt32(span.Slice(read + 5, 4)),
                Value3 = BitConverter.ToInt32(span.Slice(read + 9, 4)),
            };
            list.Add(series);
            count++;
            purchase += series.Value1;
            paid += series.Value2;

            read += 13;
            start = read;
        }
        Total = @"Purchase: " + purchase.ToString("N0") + ", paid " + paid.ToString("N0") + " in " +
                    count.ToString() + (State == 0 ? " days" : " months");
        return Task.FromResult(list);
    }
}
