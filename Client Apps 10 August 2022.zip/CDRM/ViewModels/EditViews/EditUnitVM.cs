﻿class EditUnitVM : EditBaseVM<Unit>
{
    protected override CollectionViewSource cvs => new CollectionViewSource() {
        Source = AppData.units,
        IsLiveSortingRequested = true,
        LiveSortingProperties = { nameof(IHaveName.Name) }
    };

    protected override Unit clone() {
        return new Unit() {
            Id = Selected.Id,
            Name = Selected.Name
        };
    }
    protected override async void update() {
        var request = new CDRMRequest() {
            UserId = App.service.UserId,
            Method = (int)Function.EditUnit,
            Args = new object[] {
                new NetUnit() {
                    Id = Edited.Id,
                    Name = Edited.Name
                }
            }
        };
        var response = await App.service.GetResponse(request);
    }

}

