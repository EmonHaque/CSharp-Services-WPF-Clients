﻿class EditEntryVM : Notifiable
{
    DateTime? date;
    public DateTime? Date {
        get { return date; }
        set {
            date = value;
            GetEntries();
            IsRefreshValid = value is not null;
            OnPropertyChanged(nameof(IsRefreshValid));
        }
    }
    string query;
    public string Query {
        get { return query; }
        set { query = value?.Trim(); Entries.Refresh(); }
    }
    bool isOnEdit;
    public bool IsOnEdit {
        get { return isOnEdit; }
        set { isOnEdit = value; if (value) clone(); }
    }

    public IHaveTitle Selected { get; set; }
    public IHaveTitle Edited { get; set; }
    ObservableCollection<IHaveTitle> entries;
    CollectionViewSource entrieSource;
    public ICollectionView Entries { get; set; }
    public bool IsRefreshValid { get; set; }
    public event Action CoordinateRequested;

    public EditEntryVM() {
        entries = new ObservableCollection<IHaveTitle>();
        entrieSource = new CollectionViewSource() {
            Source = entries,
            GroupDescriptions = {
                new PropertyGroupDescription(nameof(IHaveTitle.Title))
            },
            IsLiveFilteringRequested = true,
            IsLiveGroupingRequested = true,
            LiveFilteringProperties = { nameof(IHaveTitle.Date) },
            LiveGroupingProperties = { nameof(IHaveTitle.Title) }
        };
        Entries = entrieSource.View;
        Entries.Filter = filter;
    }

    bool filter(object o) {
        if (string.IsNullOrWhiteSpace(Query)) return ((IHaveTitle)o).Date == Date;
        var e = (IHaveTitle)o;
        return e.Date == Date &&
            e.Party.Contains(Query, StringComparison.CurrentCultureIgnoreCase);
    }
    void clone() {
        if (Selected is EntryPurchaseSellText) {
            var e = (EntryPurchaseSellText)Selected;
            Edited = new EntryPurchaseSellText() {
                Title = e.Title,
                Id = e.Id,
                Date = e.Date,
                IsSell = e.IsSell,
                IsConstruction = e.IsConstruction,
                Party = e.Party,
                Site = e.Site,
                Amount = e.Amount,
                Head = e.Head,
                SubHead = e.SubHead,
                Quantity = e.Quantity,
                Unit = e.Unit,
                Narration = e.Narration
            };
        }
        else {
            var e = (EntryReceiptPaymentText)Selected;
            Edited = new EntryReceiptPaymentText() {
                Title = e.Title,
                Id = e.Id,
                Date = e.Date,
                IsCash = e.IsCash,
                IsReceipt = e.IsReceipt,
                Party = e.Party,
                Head = e.Head,
                Amount = e.Amount,
                Narration = e.Narration
            };
        }
        OnPropertyChanged(nameof(Edited));
    }
    void updateSelectedPurchaseSell(EntryPurchaseSellText e) {
        var s = (EntryPurchaseSellText)Selected;
        s.Id = e.Id;
        s.Date = e.Date;
        s.Amount = e.Amount;
        s.IsSell = e.IsSell;
        s.IsConstruction = e.IsConstruction;
        s.Site = e.Site;
        s.Party = e.Party;
        s.Head = e.Head;
        s.SubHead = e.SubHead;
        s.Unit = e.Unit;
        s.Quantity = e.Quantity;
        s.Narration = e.Narration;
        s.Title = e.Title;
        s.OnPropertyChanged(null);
    }
    void updateSelectedReceiptPayment(EntryReceiptPaymentText e) {
        var s = (EntryReceiptPaymentText)Selected;
        s.Id = e.Id;
        s.Head = e.Head;
        s.Party = e.Party;
        s.Amount = e.Amount;
        s.IsReceipt = e.IsReceipt;
        s.IsCash = e.IsCash;
        s.Date = e.Date;
        s.Narration = e.Narration;
        s.Title = e.Title;
        s.OnPropertyChanged(null);
    }
    public async void Update() {
        if (Edited is null) return;
        CoordinateRequested?.Invoke();

        var request = new CDRMRequest() { UserId = App.service.UserId };
        Response response = null;
        //BusyWindow.Activate(EditEntryControl.Left, EditEntryControl.Top, EditEntryControl.Width, EditEntryControl.Height, "Updating");
        if (Edited is EntryPurchaseSellText) {
            var e = (EntryPurchaseSellText)Edited;
            var entry = new NetPurchaseSell() {
                Id = e.Id,
                Date = e.Date.Value.ToString("yyyy-MM-dd"),
                IsSell = e.IsSell,
                IsConstruction = e.IsConstruction,
                SiteId = e.SiteId,
                PartyId = e.PartyId,
                HeadId = e.HeadId,
                Amount = int.Parse(e.Amount, NumberStyles.Number, CultureInfo.CurrentCulture.NumberFormat),
                Narration = e.Narration?.Trim()
            };
            if (!string.IsNullOrWhiteSpace(e.SubHead)) entry.SubHeadId = e.SubHeadId;
            if (!string.IsNullOrWhiteSpace(e.Quantity)) {
                entry.Quantity = double.Parse(e.Quantity);
                entry.UnitId = e.UnitId;
            }
            request.Method = (int)Function.EditPurchaseSell;
            request.Args = new object[] { entry };
            response = await App.service.GetResponse(request);
            //AppData.UpdatePurchaseSell(entry);
            e.Amount = entry.Amount.ToString("N0");
            updateSelectedPurchaseSell(e);
        }
        else {
            var e = (EntryReceiptPaymentText)Edited;
            var entry = new NetEntryReceiptPayment() {
                Id = e.Id,
                Date = e.Date.Value.ToString("yyyy-MM-dd"),
                IsCash = e.IsCash,
                IsReceipt = e.IsReceipt,
                PartyId = e.PartyId,
                HeadId = e.HeadId,
                Amount = int.Parse(e.Amount, NumberStyles.Number, CultureInfo.CurrentCulture.NumberFormat),
                Narration = e.Narration?.Trim()
            };
            request.Method = (int)Function.EditReceiptPayment;
            request.Args = new object[] { entry };
            response = await App.service.GetResponse(request);
            //AppData.UpdateReceiptPayment(entry);
            e.Amount = entry.Amount.ToString("N0");
            updateSelectedReceiptPayment(e);
        }
        //BusyWindow.Terminate();
    }
    public async void Delete() {
        if (Selected is null) return;
        CoordinateRequested?.Invoke();
        var request = new CDRMRequest() { 
            UserId = App.service.UserId,
            Args = new object[] { Selected.Id }
        };
        //BusyWindow.Activate(EditEntryControl.Left, EditEntryControl.Top, EditEntryControl.Width, EditEntryControl.Height, "Deleting");
        if (Selected is EntryPurchaseSellText) {
            request.Method = (int)Function.DeletePurchaseSell;
        }
        else {
            request.Method = (int)Function.DeleteReceiptPayment;
        }
        var response = await App.service.GetResponse(request);
        entries.Remove(Selected);
        //BusyWindow.Terminate();
    }
    public async void GetEntries() {
        if (Date is null) return;
        CoordinateRequested?.Invoke();

        var request = new CDRMRequest() {
            UserId = App.service.UserId,
            Method = (int)Function.GetPurchaseSellByDate,
            Args = new object[] { Date.Value.ToString("yyyy-MM-dd") }
        };
        var response = await App.service.GetResponse(request);
        if (!response.IsSuccess) {
            //message
            return;
        }
        var psPacket = response.Packet;

        request.Method = (int)Function.GetReceiptPaymentByDate;
        response = await App.service.GetResponse(request);

        var rpPacket = response.Packet;

        entries.Clear();
        await addPurchaseSell(psPacket);
        await addReceiptPayment(rpPacket);
    }

    Task addPurchaseSell(byte[] packet) {
        var span = new ReadOnlySpan<byte>(packet);
        int start, read, index;
        start = read = index = 0;
        var segments = new string[9];
        while (read < span.Length) {
            int id = BitConverter.ToInt32(span.Slice(start, 4));
            byte isSell = span.Slice(start + 4, 1)[0];
            byte isConstruction = span.Slice(start + 5, 1)[0];
            start += 6;
            read += 6;
            while (read < span.Length) {
                if (span[read] != 0) {
                    read++;
                    continue;
                }
                segments[index++] = Encoding.ASCII.GetString(span.Slice(start, read - start));
                if (index == segments.Length) break;
                start = ++read;
            }
            var e = new EntryPurchaseSellText() {
                Id = id,
                IsSell = isSell,
                IsConstruction = isConstruction,
                Date = DateTime.ParseExact(segments[0], "yyyy-MM-dd", CultureInfo.CurrentCulture.DateTimeFormat),            
                Site = segments[1],
                Party = segments[2],
                Head = segments[3],
                SubHead = segments[4],
                Unit = segments[5],
                Amount = segments[6],
                Quantity = segments[7],
                Narration = segments[8]
            };
            e.Title = e.IsSell == 0 ? "Purchase" : "Sell";
            entries.Add(e);
            start = ++read;
            index = 0;
        }
        return Task.CompletedTask;
    }
    Task addReceiptPayment(byte[] packet) {
        var span = new ReadOnlySpan<byte>(packet);
        int start, read, index;
        start = read = index = 0;
        var segments = new string[5];

        while (read < span.Length) {
            int id = BitConverter.ToInt32(span.Slice(start, 4));
            byte isCash = span.Slice(start + 4, 1)[0];
            byte isReceipt = span.Slice(start + 5, 1)[0];

            start += 6;
            read += 6;
            while (read < span.Length) {
                if (span[read] != 0) {
                    read++;
                    continue;
                }
                segments[index++] = Encoding.ASCII.GetString(span.Slice(start, read - start));
                if (index == segments.Length) break;
                start = ++read;
            }
            var e = new EntryReceiptPaymentText() {
                Id = id,
                IsCash = isCash,
                IsReceipt = isReceipt,
                Date = DateTime.ParseExact(segments[0], "yyyy-MM-dd", CultureInfo.CurrentCulture.DateTimeFormat),
                Amount = segments[1],
                Party = segments[2],
                Head = segments[3],
                Narration = segments[4]
            };
            e.Title = e.IsReceipt == 0 ? "Payment" : "Receipt";
            entries.Add(e);
            start = ++read;
            index = 0;
        }
        return Task.CompletedTask;
    }
}
