﻿class EditSubHeadVM : EditBaseVM<SubHead>
{
    protected override CollectionViewSource cvs => new CollectionViewSource() {
        Source = AppData.subHeads,
        IsLiveSortingRequested = true,
        LiveSortingProperties = { nameof(IHaveName.Name) }
    };

    protected override SubHead clone() {
        return new SubHead() {
            Id = Selected.Id,
            Name = Selected.Name
        };
    }
    protected override async void update() {
        var request = new CDRMRequest() {
            UserId = App.service.UserId,
            Method = (int)Function.EditSubHead,
            Args = new object[] {
                new NetSubHead() {
                    Id = Edited.Id,
                    Name = Edited.Name
                }
            }
        };
        var response = await App.service.GetResponse(request);
    }
}
