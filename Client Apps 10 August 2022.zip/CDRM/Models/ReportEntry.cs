﻿class ReportEntry
{
    public DateTime Date { get; set; }
    public string Particulars { get; set; }
    public int ReceivablePayment { get; set; }
    public int PayableReceipt { get; set; }
    public int NetPayable { get; set; }
}
