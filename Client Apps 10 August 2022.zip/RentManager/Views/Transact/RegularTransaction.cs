﻿class RegularTransaction : TransactionBase
{
    public override string Header => "Regular";
    public override string Icon => Icons.RegularTransaction;

    RegularTransactionVM vm = new();
    protected override TransactionBaseVM viewModel => vm;
    protected override string plotSelectedValuePath => nameof(Lease.PlotId);
    protected override string plotDisplayMemberPath => nameof(Lease.PlotName);

    protected override void setSpace() {
        space.SelectedValuePath = nameof(Lease.SpaceId);
        space.ItemTemplate = new TransactionSpaceTemplate(nameof(viewModel.SpaceQuery), viewModel);
    }
}
