﻿class App : ClientApp
{
    public AppData appData = new();
    protected override IPAddress address => IPAddress.Parse(Addresses.RentManagerAddress);
    protected override int port => Addresses.RentManagerPort;
    protected override Request initRequest => new RentManagerRequest() {
        UserId = service.UserId,
        Method = (int)Function.GetInitialData,
        Args = new object[] { "" }
    };
    protected override ImageSource image {
        get {
            var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("RentManager.Resources.LoadingIcon.png");
            var source = BitmapFrame.Create(stream, BitmapCreateOptions.None, BitmapCacheOption.OnLoad);
            stream.Close();
            stream.Dispose();
            return source;
        }
    }
    protected override AppDataBase baseData => appData;
    protected override string appTitle => "Rent Manager";

    const string appExeName = "RentManager";
    const string appVersion = "1.0";

    [STAThread]
    static void Main(string[] args)  {
#if DEBUG
        new App().Run();
#else
        if (args.Length == 0) {
            var lArg = new LaunchArgs() {
                App = appExeName,
                Version = appVersion,
                Path = AppDomain.CurrentDomain.BaseDirectory
            };
            var launchArg = $"\"{lArg.App},{lArg.Version},{lArg.Path}\"";
            var launcherPath = System.IO.Path.GetFullPath(System.IO.Path.Combine(lArg.Path, @"..\"));
            Process.Start(launcherPath + "\\Launcher.exe", launchArg);
        }
        else  new App().Run();
#endif
    }
    
    protected override void SetResourceAndShowWindow() {
        new Converters();
        Current.MainWindow = new RootWindow() {
            Content = new RootPanel() {
                Children = {
                        new HomeView(),
                        new AddView(),
                        new EditView(),
                        new TransactionView(),
                        new ReportView()
                    }
            }
        };
        Current.MainWindow.Show();
    }
}
